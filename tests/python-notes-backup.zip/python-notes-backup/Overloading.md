MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/typing.html#typing.overload
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-03
***

Exemple : 
```python
import typing


# Décrit la forme 1
@typing.overload
def fn(*, key: str, value: int):
    pass

# Décrit la forme 2
@typing.overload
def fn(*, strict: bool):
    pass

# Implémentation concrète
def fn(**kwargs):
    print(kwargs)


# OK
fn(key='abc', value=100)
fn(strict=True)

# invalide
fn(x=1)

```
