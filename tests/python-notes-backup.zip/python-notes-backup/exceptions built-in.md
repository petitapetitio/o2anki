MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-05
***

***
TARGET DECK: Python
FILE TAGS: exceptions

START
Basic
Quand est-ce qu'une `AttributeError` est levée ?
Back: Lorsqu'une référence à un attribut ou une assignation échoue. Par exemple : 
```python
class A:
    __slots__ = ["a"]

A().a      # AttributeError : tentative d'accès à un attribut non défini
A().a = 0  # OK
A().x = 0  # AttributeError : tentative d'assignation non autorisée
```
<!--ID: 1730827063521-->
END

- STARTI [Basic] exceptions : quand est-ce qu'une `AssertionError` est levée ? Back:  Lorsqu'une assertion est fausse. Ex : `assert False`. (cf : [[instruction assert]]) <!--ID: 1730827063527--> ENDI
- STARTI [Basic] exceptions : quand est-ce qu'une `IndexError` est levée ? Back:  Lorsque l'indice utilisé dans une [[sélection (subscription)]] est en dehors des limites de la séquence. Ex : `[0, 1, 2][100]`<!--ID: 1730827063529--> ENDI
- STARTI [Basic] exceptions : quelle est la plus petite classe commune de `IndexError` et `KeyError` ? Back:  `LookupError`. <!--ID: 1730827063533--> ENDI
- STARTI [Basic] exceptions : quand est-ce qu'une `KeyError` est levée ? Back:  Lorsqu'un clé requêtée sur un mapping n'existe pas. Ex : `{}['x']` <!--ID: 1730827063537--> ENDI
- STARTI [Basic] quand est-ce qu'une `NameError` est levée ? Back:  Lorsqu'un nom est référencé mais n'existe dans aucun espace de nom accessible. Ex : le programme d'une seule ligne `print(x)` <!--ID: 1730827063540--> ENDI
- STARTI [Basic] quand lever une `NotImplementedError` ? Back:  <br>1) quand une méthode doit être implémentée dans la classe fille. <br>2) quand une fonctionnalité n'est pas encore implémentée<!--ID: 1730827063542--> ENDI
- STARTI [Basic] quand est-ce qu'une `OSError` est levée ? Back:  Lors d'une erreur système (fichier, réseau, permissions...). Ex: `FileNotFoundError`. <!--ID: 1730827063544--> ENDI
- STARTI [Basic] quand est-ce qu'une `RecursionError` est levée ? Back:  Lorsque la profondeur de récursivité maximale est atteinte.<br>Ex : une fonction qui s'appelle sans condition d'arrêt. <br>RQ : la profondeur maximale est donnée par `sys.getrecursionlimit()` <!--ID: 1730827063547--> ENDI
- STARTI [Basic] quand est-ce qu'une `RuntimeError` est levée ? Back:  Lorsqu'une erreur qui n'a pas d'exception spécifique survient à l'exécution. C'est le type d'erreur à hériter pour les exceptions customs. <!--ID: 1730827063550--> ENDI
- STARTI [Basic] quand est-ce qu'une `SystemError` est levée ? Back:  Lorsque l'interpréteur Python ou un module d'extension détecte une erreur interne. Note : à reporter aux mainteneurs avec le message d'erreur et la version de Python. <!--ID: 1730827063552--> ENDI
- STARTI [Basic] quand est-ce qu'une `TypeError` est levée ? Back: Lorsqu'une opération est appliquée à un mauvais type. Ex : `[][0.5]`, `len(42)` <!--ID: 1730827063554--> ENDI


START
Basic
Quand est-ce qu'une `UnboundLocalError` est levée ?
Back: 
Lorsqu'une variable locale est référencée avant d'être assignée. Par exemple : 
```python
def f():
    print(x)  # UnboundLocalError
    x = 1
```
RQ : si l'on commente la ligne `x = 1` on obtient alors une `NameError` de base.
<!--ID: 1730827063524-->
END

START
Basic
Qu'affiche `f()`?
```python
x = 1
def f():
    print(x)
    x = 2
```
Back:
`UnboundLocalError` car x est déterminé comme local.
<!--ID: 1732776513894-->
END

- STARTI [Basic] exceptions : quelle est le lien entre `UnboundLocalError` et `NameError` ? Back: `UnboundLocalError` est une `NameError` particulière. <!--ID: 1730827063556--> ENDI
- STARTI [Basic] exceptions : quand est-ce qu'une `UnicodeError` est levée ? Back:  Lors d'erreurs d'encodage/décodage entre `str` et `bytes`. Ex : `'café'.encode('ascii')` <!--ID: 1730827063560--> ENDI
- STARTI [Basic] quand est-ce qu'une `ValueError` est levée ? Back:  Lorsqu'une opération est appliquée à un bon type mais une mauvaise valeur. Ex : `int('abc')` <!--ID: 1730827063564--> ENDI
- STARTI [Basic] exceptions : quand est-ce qu'une `ZeroDivisionError` est levée ? Back: Lors d'une division par zéro avec `/`, `//`, `%` ou `divmod`. Ex : `1/0` <!--ID: 1730827063568--> ENDI
- STARTI [Basic] exceptions : quelle est la différence entre `TypeError` et `ValueError` ? Back:  <br>`TypeError` = mauvais type (`[]['a']`)<br>`ValueError` = bon type mais mauvaise valeur (`int('abc')`) <br>([[tricks]]) <!--ID: 1730827063570--> ENDI

