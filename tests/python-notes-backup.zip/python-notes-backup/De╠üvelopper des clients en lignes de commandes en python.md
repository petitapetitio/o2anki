MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-10
***

- [[module readline]]
- [[module getpass]]
- module rich : https://pypi.org/project/rich/ (cross-plateform)
- module curses : https://docs.python.org/fr/3/library/curses.html (unix-only)
- module colorama : https://pypi.org/project/colorama/
