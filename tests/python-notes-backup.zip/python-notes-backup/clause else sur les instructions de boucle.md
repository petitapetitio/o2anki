MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Instructions de boucle]]
Date : 2024-10-12
***

***
TARGET DECK: Python
FILE TAGS: loop

- STARTI [Basic] Quand est-ce que la clause `else` d'une instruction de boucle est exécutée ? Back:  Après que la boucle ait terminée naturellement. <br>Au contraire, elle n'est pas exécutée lorsque la boucle termine de façon prématurée (`break`, `return`, exception) <!--ID: 1728749077231--> ENDI

Un exemple typique d'utilisation est le cas d'une recherche d'élément (conjointement à une [[instruction break]]) : 
```python
for n in range(2, 10):
    for x in range(2, n):
        if n % x == 0:
            print(n, 'equals', x, '*', n/x)
            break
    else:
        # loop fell through without finding a factor
        print(n, 'is a prime number')
```

Ressources : 
- https://www.reddit.com/r/Python/comments/wxtgke/why_do_for_loops_have_an_else_block/?rdt=43253
- https://stackoverflow.com/questions/9979970/why-does-python-use-else-after-for-and-while-loops


> Guido has said that in hindsight it should have been called something different.

> Raymond Hettinger says it ought to have been called "No Break"




