Date : 2024-01-15
***

- objet qui fait tourner une coroutine
- utilisé pour planifier des coroutines simultanément
- créer une tâche : 
	- `task = asyncio.create_task(coro)` : crée une tâche et lance la coroutine
	- ne pas instancier de tâches "à la main"
- `await task` : attends la fin de la tâche
```python
import asyncio
import time

async def say_after(delay, what):
    await asyncio.sleep(delay)
    print(what)

async def main():
    print(f"Started at {time.strftime('%X')}")
    t1 = asyncio.create_task(say_after(2, "hello"))
    t2 = asyncio.create_task(say_after(1, "world"))
    await t1
    await t2
    print(f"Done at {time.strftime('%X')}")

asyncio.run(main())

# Sortie attendue
# started at 17:13:52
# hello
# world
# finished at 17:13:54
```


Les tâches peuvent être annulées

## Task Groups

- context manager qui simplifie d'attendre les tâches plusieurs tâches. 
- disponible depuis Python 11
- La fonction coroutine main précédente peut être réécrite :
```python
async def main():
	print(f"Started at {time.strftime('%X')}")
	async with asyncio.TaskGroup() as tg:
	    t1 = asyncio.create_task(say_after(2, "hello"))
		t2 = asyncio.create_task(say_after(1, "world"))
	print(f"Done at {time.strftime('%X')}")
```

TaskGroup est désormais préféré à `asyncio.gather`
```python
async def main():
	print(f"Started at {time.strftime('%X')}")
	await asyncio.gather(
		say_after(2, "hello");
		say_after(1, "world")
	)
	print(f"Done at {time.strftime('%X')}")
```
