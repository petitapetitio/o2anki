MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/datamodel.html#object.__class__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] class : comment accéder à la classe d'un objet `obj` ? Back:  `obj.__class__` ou `type(obj)` <!--ID: 1730827064268--> ENDI
- STARTI [Basic] quelle est la différence fonctionnelle entre `type(c)` et `c.__class__` ? Back:  Aucune. <br>Les deux renvoient la classe de `c`.<br>`type(c) is c.__class__` vaut `True`. <!--ID: 1730827064101--> ENDI

ID: 1730827064274