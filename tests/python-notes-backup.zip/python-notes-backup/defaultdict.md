MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: 

- STARTI [Basic] un `defaultdict` avec une valeur par défaut à zéro ? Back:  `defaultdict(lambda: 0)` <!--ID: 1734710569228--> ENDI
- STARTI [Basic] `defaultdict(lambda: 100)['a']` ? Back:  `100` <!--ID: 1734710569230--> ENDI


START
Basic
Un dictionnaire où la valeur par défaut est une fonction de la clé ? 
Back:
```python
class DKey(dict):
    def __missing__(self, key):
        return '$' + key

print(DKey()['a'])  # '$a'
```
<!--ID: 1734678007484-->
END

START
Basic
```python
class DKey(dict):
    def __missing__(self, key):
        return '$' + key

d = DKey()
d['a'] += 'b'
print(d)
```
Back:
`{'a': '$ab'}`
<!--ID: 1734678007485-->
END
