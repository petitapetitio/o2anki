MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: functools

- quelles sont les 3 fonctions de mémoïsation de `functools` ? `cached_property`, `cache`, `lru_cache`

#### functools.cached_property

START
Basic
Comment faire en sorte qu'une propriété soit mise en cache une fois calculée ? 
Back:
```python
class A:
    @functools.cached_property
    def attr(self):
        print("compute")
        return 0


a = A()
print(a.attr)
print(a.attr)

# Affiche :
#  compute
#  0
#  0
```
<!--ID: 1734678007486-->
END

#### functools.cache et functools.lru_cache 

- STARTI [Basic] lru_cache : *lru* ? Back:  least recently used <!--ID: 1734710569157--> ENDI
- STARTI [Basic] lru_cache : qu'indique le paramètre `max_size` ? Back:  Le nombre de derniers résultats à mémoriser  <!--ID: 1734710569161--> ENDI
- STARTI [Basic] à quoi équivaut `functools.cache` ? Back:  `functools.lru_cache(max_size=None)`  ` <!--ID: 1734710569164--> ENDI


START
Basic
Qu'affiche
```python
@functools.lru_cache(maxsize=2)
def func(a):
    print(f"func({a})")
    return a * a

func(1)
func(1)
```
Back:
```
func(1)
```
<!--ID: 1734678007487-->
END


START
Basic
Qu'affiche
```python
@functools.lru_cache(maxsize=2)
def func(a):
    print(f"func({a})")
    return a * a

func(1)
func(2)
func(3)
func(1)
```
Back:
```
func(1)
func(2)
func(3)
func(1)
```
<!--ID: 1734678007488-->
END

START
Basic
```python
@functools.lru_cache(typed=True)
def tfunc(a):
    print(f"tfunc({a})")

tfunc((1,))
tfunc([1,])
```
Back:
```
tfunc((1,))
TypeError: unhashable type: 'list'
```
<!--ID: 1734678007489-->
END


###### Tips pour un cache avec TTL

```python
from functools import lru_cache
import time


@lru_cache()
def my_expensive_function(a, b, ttl_hash=None):
    del ttl_hash  # to emphasize we don't use it and to shut pylint up
    return a + b  # horrible CPU load...


def get_ttl_hash(seconds=3600):
    """Return the same value withing `seconds` time period"""
    return round(time.time() / seconds)


# somewhere in your code...
res = my_expensive_function(2, 2, ttl_hash=get_ttl_hash())
# cache will be updated once in an hour
```

#### functools.partial

- STARTI [Basic] que permet `functools.partial` ? Back:  La [[curryfication]] de fonctions <!--ID: 1734710569165--> ENDI
- STARTI [Basic] `mmax = functools.partial(max, 0)` ? Back:  Une fonction `mmax(x)` qui renvoie le max entre 0 et `x` <!--ID: 1734710569167--> ENDI
- STARTI [Basic] `functools.partial(max, 0).func` ? Back:  `<built-in function max>` <!--ID: 1734710569169--> ENDI
- STARTI [Basic] `functools.partial(max, 0).args` ? Back:  `(0,)` <!--ID: 1734710569171--> ENDI
- STARTI [Basic] `functools.partial(max, key=len).keywords` ? Back:  `{'key': <built-in function len>}` <!--ID: 1734710569173--> ENDI


#### functools.reduce

- STARTI [Basic] la somme de `l = [1, 2, 3]` avec `reduce` ? Back:  `functools.reduce(operator.add, l)` <!--ID: 1734710569175--> ENDI
- STARTI [Basic] `functools.reduce(operator.add, [1, 1, 1], 1)` ? Back:  `4` <!--ID: 1734710569177--> ENDI
- STARTI [Basic] `functools.reduce(operator.add, [], 1)` ? Back:  `1` <!--ID: 1734710569180--> ENDI
- STARTI [Basic] `functools.reduce(operator.add, [1])` ? Back:  `1` <!--ID: 1734710569182--> ENDI


- [[module functools.heapq]]