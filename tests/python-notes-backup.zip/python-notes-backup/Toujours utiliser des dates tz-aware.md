MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Engineering Practice]], [[3 RESSOURCES/The developer's brain/Notes/Software Design|Software Design]]
Date : 2025-01-14
***


Même si un seul fuseau, cela permet de gérer les [[DST (daylight saving time)]] proprement
