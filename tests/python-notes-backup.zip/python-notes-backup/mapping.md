
- https://docs.python.org/fr/3/glossary.html#term-mapping