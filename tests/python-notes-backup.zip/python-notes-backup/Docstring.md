MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-24
***


Conventions
- https://peps.python.org/pep-0257/
- describe what it does in a concise manner in the first line
- en cas de dostrings sur plusieurs lignes, la deuxième doit être vide
- prefer imperative over descriptive
- don't repeat the function name (unless it comes naturally)


***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] Comment créer une docstring ? Back:  Placer une chaîne de caractère littérale en <u>première</u> instruction du corps d'une [[fonction (Python)]], d'une méthode, d'une classe ou d'un [[module]]. <!--ID: 1729754352051--> ENDI
- STARTI [Basic] Comment récupérer la docstring d'une fonction `f` ? Back:  `f.__doc__` <!--ID: 1729754352053--> ENDI
- STARTI [Basic] Comment afficher la docstring d'une fonction `f` ? Back:  `help(f)` <!--ID: 1729754352054--> ENDI
- STARTI [Basic] Que se passe-t-il lorsque la première instruction d'une fonction est une chaîne de caractères ? Back:  Le compilateur l'interprète comme une docstring et associe cette chaîne de caractères à l'attribut `__doc__` de la fonction. <!--ID: 1729754352056--> ENDI

START
Basic
```python
def f():
    """la docstring de f"""
    pass
```
Qu'affiche `help(f)` ?
Back: 
La docstring de `f` : 
```
Help on function f in module __main__:

f()
    la docstring de f
```
<!--ID: 1729754352049-->
END
