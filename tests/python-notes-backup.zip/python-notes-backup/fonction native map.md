MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

***
TARGET DECK: Python
FILE TAGS: 

https://docs.python.org/3/library/functions.html#map
- STARTI [Basic] Comment appliquer `f` à tous les éléments de `elts` (2 façons) ? Back:  <br>`map(f, elts)` <br>`(f(x) for x in elts)` <!--ID: 1734678007454--> ENDI
- STARTI [Basic] `list(map(lambda x: x + 2, [0, 1]))` ? Back:  `[2, 3]` <!--ID: 1734678007455--> ENDI
