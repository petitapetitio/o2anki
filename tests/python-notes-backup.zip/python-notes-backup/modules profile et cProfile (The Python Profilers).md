MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/profile.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[profiling]]
Date : 2025-01-17
***

- deux modules avec une interface similaire
	- `cProfile` : C-extension avec un faible overhead, recommandée
	- `profile` : module pure-python plus facile à étendre (à utiliser si `cProfile` pas dispo)
- comment utiliser
	- dans un programme python
		- `cProfile.run('re.compile("foo|bar")')`
	- dans le terminal : 
		- `python -m cProfile [-o output_file] [-s sort_order] (-m module | script.py)`
- tips
	- collecter les résultats dans des fichiers et utiliser le [[module pstats]] pour les agréger
	- utiliser `Profile().calibrate(n)` pour calculer le surcoût lié au profilage  
		- procédure
			- commencer avec `n = 10000`
			- lancer plusieurs fois
			- si les résultats sont stables, prendre la plus petite valeur
			- si les résultats varient beaucoup, augmenter n et relancer
		- à calculer une fois pour toute pour chaque machine / version de python
		- `profile.Profile.bias = overhead_measured`
		- plus de détails [dans la doc](https://docs.python.org/3/library/profile.html#calibration)


[Article qui étudie les limites de cProfile et les avantages d'Eliot / pyinstrument](https://pythonspeed.com/articles/beyond-cprofile)