MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/reference/simple_stmts.html#the-del-statement
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-05
***

`del`est un mot réservé du langage (un [[keyword]]) qui permet de supprimer la référence à un objet.


***
TARGET DECK: Python
FILE TAGS: del

Elle libère la référence à l'objet lié
- STARTI [Basic] Que fait l'instruction `del target` ? Back: Elle supprime une référence à un objet. L'objet sera supprimé par le garbage collector quand il n'aura plus aucune référence. <!--ID: 1728239137849--> ENDI
- STARTI [Basic] Quels sont les 3 types de target de `del target` ? Back:  [[variable]], [[attribut]], [[sélection (subscription)]] <!--ID: 1728239137854--> ENDI
- [[variable]]
	- STARTI [Basic] Est-ce que l'instruction `del x` peut être refusée ? Back:  Non. La suppression d'une variable est toujours autorisée. <!--ID: 1728239137859--> ENDI
	- STARTI [Basic] `a = 0; del a; del a` ? Back:  `NameError` car `a` n'est plus définit lors du deuxième appel à `del`. <!--ID: 1728239137862--> ENDI
- [[référence à un attribut]]
	- STARTI [Basic] Est-ce que l'instruction `del p.x` peut être refusée ? Back:  Oui. La suppression d'un attribut passe par la méthode `__delattr__` et peut être refusée par l'objet. <!--ID: 1728239137866--> ENDI
- [[sélection (subscription)]]
	- STARTI [Basic] Est-ce que l'instruction `del t[0]` peut être refusée ? Back:  Oui. La suppression d'une [[sélection (subscription)]] passe par la méthode `__delitem__` et peut être refusée par l'objet conteneur. <!--ID: 1728239137869--> ENDI
	- STARTI [Basic] `x = [0, 1, 2, 3]; del x[2]; x[2]` ? Back:  `3` ([[tricks]])<!--ID: 1728239137873--> ENDI
- [[tranchage (slicing)]]
	- STARTI [Basic] Est-ce que l'instruction `del t[1:3]` peut être refusée ? Back:  Oui. La suppression d'un tranchage passe par la méthode `__delitem__` et peut être refusée par l'objet conteneur. <!--ID: 1728239137878--> ENDI
	- STARTI [Basic] `x = [0, 1, 2, 3, 4, 5]; del x[:4]; x` ? Back:  `[4, 5]` <!--ID: 1728239137882--> ENDI