MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***

***
TARGET DECK: Python
FILE TAGS: match

- STARTI [Basic] Quelle est la différence entre `10 | 20` et `(10 | 20)` ? Back:  Aucune. Il est possible de parenthéser les patterns afin de les organiser, sans que cela change leur signification. <!--ID: 1728727115354--> ENDI
- STARTI [Basic] Quelle est la différence entre le pattern `(10 | 20)` et le pattern `(10 | 20,)` ? Back:  Le premier capture les entiers `10` ou `20`, tandis que le deuxième correspond aux tuples singleton `(10,)` ou `(20,)` <!--ID: 1728727115356--> ENDI
