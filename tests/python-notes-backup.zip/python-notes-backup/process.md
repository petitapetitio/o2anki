MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2025-01-12
***

- instances of running programs that the operating system protects from one another
- la communication entre deux process ([[interprocess communication (IPC)]]) par des fichiers / bases de données, modules dédiés

En python
- [[module multiprocessing (Process-based parallelism)]] permet de paralleliser un programme
- [[module subprocess (Subprocess management)]] permet d'exécuter d'autres programmes