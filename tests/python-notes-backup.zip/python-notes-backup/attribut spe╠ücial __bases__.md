MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/datamodel.html#type.__bases__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] class : comment accéder aux parents directs de `C` ? Back:  `C.__bases__` <!--ID: 1730827064296--> ENDI
- STARTI [Basic] Quelle est la différence entre `C.__bases__` et le [[Method resolution order (MRO)]] `C.__mro__` ? Back:  `C.__bases__` renvoie uniquement les parents directs. <!--ID: 1730827064303--> ENDI

START
Basic
```python
class A: 
    ...

print(A.__bases__)
```
Back:
`(<class 'object'>,)`
<!--ID: 1730827064299-->
END

START
Basic
```python
class A: ...  
class B: ...  
class C(A, B): ...  
  
print(C.__bases__)
```
Back:
`(<class '__main__.A'>, <class '__main__.B'>)`
<!--ID: 1730827064301-->
END
