MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-09-25
***

- Personnalisation de base
	- [[méthode spéciale __new__]]
	- [[méthode spéciale __init__]]
	- [[Méthode spéciale __del__]]
	- [[Méthode spéciale __repr__]]
	- [[Méthode spéciale __str__]]
	- [[Méthode spéciale __format__ et fonction native format]]
	- [[Méthode spéciale de comparaison riches (__eq__, __lt__, ...)]]
	- [[Méthode spéciale __hash__ et fonction native hash]]
	- [[Méthode spéciale __bool__]]
- Personnalisation de l'accès aux attributs
	- [[Méthode spéciale __getattr__]]
	- [[Méthode spéciale __getattribute__]]
	- [[méthode spéciale __setattr__]]
	- [[Méthode spéciale __delattr__]]
	- [[Méthode spéciale __dir__]]
- Conteneurs
	- [[méthode spéciale __contains__]]
	- [[méthode spéciale __getitem__]]
	- [[méthode spéciale __delitem__]]
	- [[méthode spéciale __iter__]]
	- [[méthode spéciale __len__]]
	- [[méthode spéciale __setitem__]]


***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] Quels sont les autres noms des "méthodes spéciales" ? Back: Magic functions, dunder method <!--ID: 1730827064407--> ENDI
- STARTI [Basic] Comment se prononce "\_\_get_item__" ? Back:  "dunder-get-item" <!--ID: 1730827064409--> ENDI
- STARTI [Basic] À quoi reconnaît-on une méthode spéciale ? Back: son nom est préfixé et suffixé par un double underscore. Ex : `__len__` <!--ID: 1730827064412--> ENDI


