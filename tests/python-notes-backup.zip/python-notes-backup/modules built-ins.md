MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-08
***

***
TARGET DECK: Python
FILE TAGS: stdlib


START
Basic
Où trouver la liste des modules built-in disponibles ?
Back:
`sys.builtin_module_names`
```python
import sys
import pprint
pprint.pprint(sys.builtin_module_names)  
# ('_abc',  
#  '_ast',  
#  '_codecs',  
#  '_collections',  
#  '_functools',  
#  '_imp',  
#  '_io',  
#  '_locale',  
#  '_operator',  
#  '_signal',  
#  '_sre',  
#  '_stat',  
#  '_string',  
#  '_symtable',  
#  '_thread',  
#  '_tokenize',  
#  '_tracemalloc',  
#  '_typing',  
#  '_warnings',  
#  '_weakref',  
#  'atexit',  
#  'builtins',  
#  'errno',  
#  'faulthandler',  
#  'gc',  
#  'itertools',  
#  'marshal',  
#  'posix',  
#  'pwd',  
#  'sys',  
#  'time')
```
<!--ID: 1731053653020-->
END

- STARTI [Basic] Comment vérifier si un nom de module est déjà utilisé par Python ? Back: `python -m name`. <br>Si la console affiche "`No module named name`" alors le nom est disponible. <!--ID: 1731053653021--> ENDI

