Date : 2024-01-15
***

- `asyncio.to_threads` 
- permet d'exécuter dans un autre thread des opérations qui auraient été bloquantes sans cela.
- prends en entrée une fonction synchrone et renvoie une fonction [[Coroutine]]