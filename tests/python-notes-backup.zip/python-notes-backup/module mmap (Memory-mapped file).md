MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/mmap.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***


- est un [[file-like object]]
- avantages
	- accès aléatoire rapide
	- modification directe en mémoire
- cas d'usages
	- fichiers volumineux
	- [[interprocess communication (IPC)]]
