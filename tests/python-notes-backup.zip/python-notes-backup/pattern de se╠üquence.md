MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***


***
TARGET DECK: Python
FILE TAGS: match

- STARTI [Basic] Quelle est la différence entre le pattern `[0, 1, *_]` et le pattern `0, 1, *_` ? Back:  Aucune. Les deux patterns permettent de matcher une séquence dont les deux premiers éléments valent `0` et `1` et le reste est ignoré grâce au motif étoilé `*_`. <!--ID: 1728727115338--> ENDI ([[starred pattern]])
- STARTI [Basic] Quel pattern permet de matcher n'importe quelle séquence dont le premier et le dernier éléments valent `0` ? Back:  `0, *_, 0` <!--ID: 1728727115340--> ENDI

