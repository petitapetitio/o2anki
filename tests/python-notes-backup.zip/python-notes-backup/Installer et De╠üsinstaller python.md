Projet : [[2 CASQUETTES/Tamis/Tamis|Tamis]]
Date : 2024-03-04
***

- Lien vers les fichiers d'installation
	- Python 3.10 : https://www.python.org/downloads/release/python-3100/
	- Python 3.8.10 : https://www.python.org/downloads/release/python-3810/
	- Python 3.7.1 : https://www.python.org/downloads/release/python-371/
- Désinstaller sur Windows : aller dans "ajouter ou supprimer des programmes"