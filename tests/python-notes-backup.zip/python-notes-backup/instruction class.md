MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/reference/compound_stmts.html#class-definitions
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-26
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] quelle est la convention de nommage des classes en python ? Back:  CamelCase <!--ID: 1730827064216--> ENDI
- STARTI [Basic] De quelle classe hérite implicitement la classe vide `class C: ...` ? Back:  `object`. <!--ID: 1730827064219--> ENDI
- STARTI [Basic] Comment appelle-t-on la suite de la clause `class` ? Back:  Le corps de la classe <!--ID: 1730827064222--> ENDI
- STARTI [Basic] qu'est-ce que le corps de la classe ? Back:  La suite de la clause `class` <!--ID: 1730827064226--> ENDI
- STARTI [Basic] à quel moment est exécuté le corps de la classe ? Back: Lors de l'exécution de l'instruction `class`. <!--ID: 1730827064229--> ENDI
- STARTI [Basic] dans `class Name: ...`, à quel moment est lié l'identifiant "Name" ? Back: après l'exécution du corps de la classe <!--ID: 1730827064232--> ENDI

START
Basic
Quelle est la syntaxe d'une instruction `class` ?
Back: 
C'est une instruction composée avec une clause unique. 
```python
class name(base-classes, *, *kw):
    statements
```
<!--ID: 1730827064210-->
END


START
Basic
Quel est le type de `A().f` 
```python
class A:  
	def __init__(self):  
		self.f = 1  
  
	def f(self):  
		...
```
?
Back:
`int`. La méthode est d'abord liée à l'instance, puis lors du `__init__`, l'attribut `f` est lié à l'entier `1`.
<!--ID: 1730827064212-->
END
