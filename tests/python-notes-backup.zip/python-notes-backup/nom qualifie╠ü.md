---
aliases:
  - nom non-qualifié
---
MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***

***
TARGET DECK: Python

- STARTI [Basic] Qu'est-ce qu'un nom non-qualifié ? Back:  "un nom sans `.` dedans", autrement dit un [[identifiant (nom)]] simple comme `x` plutôt qu'une [[référence à un attribut]] comme `obj.attr` <!--ID: 1728727115365--> ENDI
