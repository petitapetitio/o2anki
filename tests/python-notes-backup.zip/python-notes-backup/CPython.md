MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/fr/3.13/glossary.html#term-CPython
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

CPython est l'implémentation de python la plus utilisée - aka l'implémentation de référence. Elle est écrite en C et son job est de compiler et d'interprèter les fichiers.

- https://github.com/python/cpython
- https://github.com/python/cpython/blob/main/Objects/object.c
- https://github.com/python/cpython/blob/main/Objects/typeobject.c

***
TARGET DECK: Python

STARTI [Basic] En quel langage est écrit CPython ? Back: C <!--ID: 1727542890161--> ENDI