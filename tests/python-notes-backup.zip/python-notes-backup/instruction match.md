MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***

Référence
- https://docs.python.org/3/reference/compound_stmts.html#match
- https://docs.python.org/3.10/whatsnew/3.10.html#pep-634-structural-pattern-matching


- est une [[instruction composée (compound statements)]]
- permet une [[Approche déclarative ("what")]] (vs [[Approche impérative ("how")]] avec des ifs)
- concepts associés
	- [[garde (de pattern matching)]]
	- Patterns
		- https://docs.python.org/3/reference/compound_stmts.html#patterns
		- On distingue différentes formes de patterns :  
			- [[pattern littéral]]
			- [[wildcard pattern (motif générique)]]
			- [[capture pattern]]
			- [[value pattern]]
			- [[pattern alternatif (or pattern)]]
			- [[group patterns]]
			- [[pattern de séquence]]
			- [[as pattern]]
			- [[mapping pattern]]
			- [[class pattern]]
	
	

***
TARGET DECK: Python
FILE TAGS: match


- STARTI [Basic] En quoi consiste le pattern matching ? Back: Comparer une valeur avec différents motifs pour exécuter le code associé au motif correspondant. <!--ID: 1727939491394--> ENDI
- STARTI [Basic] Dans quelle version de python a été introduit le pattern matching ? Back: 3.10 <!--ID: 1727939491399--> ENDI
- STARTI [Basic] Que se passe-t-il lorsqu'un match est trouvé dans un match statement ? Back: L'action associée au motif est exécutée et les autres cas ne sont pas évalués. <!--ID: 1727939491403--> ENDI
- STARTI [Basic] Quels sont les grandes catégories de sujet de pattern-matching ? Back: littéraux, sequences, mapping, classes <!--ID: 1727939491408--> ENDI
- STARTI [Basic] Quel est le seul symbole qui peut apparaître plus d'une fois dans un pattern de pattern-matching ? Back: `_` (le [[wildcard pattern (motif générique)]] <!--ID: 1727939491412--> ENDI
- STARTI [Basic] De quoi est composé une instruction `match` ? Back:  D'une clause `match` suivie de clauses `case`.  <!--ID: 1728729591870--> ENDI
- STARTI [Basic] pattern-matching : comment appelle-t-on la clause `case` ? Back:  La clause de correspondance <!--ID: 1728729591874--> ENDI
- STARTI [Basic] pattern-matching : quelles sont les deux fonctions d'un pattern ? Back:  <br>1) vérifier que le sujet a une structure particulière <br>2) capturer des composants "matchés" et les lier à des noms pour les réutiliser (dans la garde ou la suite de la clause) <!--ID: 1728729591877--> ENDI

START
Basic
Quelle est la structure canonique d'un pattern matching ?
Back:
```python
match subject:
	case <pattern_1> [if guard_1]:
		<action_1>
	case <pattern_2> [if guard_2]:
		<action_2>
	case _:
		<action_wildcard>
```
<!--ID: 1727939491390-->
END

START
Basic
Quelle est la structure canonique d'une instruction `match` ?
Back: 
```python
match subject:
    case pattern [if guard]:
        statement(s)
    # ...
```
où 
- `subject` peut être est n'importe quelle expression
- `pattern` représente le motif à matcher
- `if guard` permet d'ajouter une condition supplémentaire à vérifier après la correspondance du pattern ([[garde (de pattern matching)]]).
- `statement(s)` sont les instructions à exécuter si le pattern est matché et que la garde est évaluée à _True_.
<!--ID: 1728729591864-->
END


#### Pattern matching et sequences

START
Basic
Quelles sont les limites de la [[dissociation de séquences et d'itérables (unpacking)]] **dans les pattern-matching** ?
Back:  
Ne fonctionne que sur les itérables qui sont des séquence (pas sur itérateurs, pas sur les mappings).
```python
def generator():
    yield 1
    yield 2

a, b = generator()
print(a, b)  # 1, 2 : la dissociation fonctionne ici

match generator():
    case 1, 2:
        print("yes")
    case _ as x:
        print(f"no {x}")  # <-- la dissociation ne fonctionne PAS ici.
```
<!--ID: 1727939491416-->
END

STARTI [Basic] Quelles séquences sont traitées de façon atomique dans les pattern-matching ? Back: `str`, `bytes`, et `bytearray`. <!--ID: 1727939491420--> ENDI

START
Basic
Comment matcher une chaîne de caractère qui commence par "06" ?
Back:
```python
def is_mobile_phone(phone: str):
    match tuple(phone):
        case "0", "6", *_:
            return True
        case _:
            return False
```
Les deux points importants ici sont 
1. De convertir la chaîne de caractère en tuple afin qu'elle soit traitée comme une séquence
2. D'utiliser l'opérateur `*` afin d'absorber la suite
<!--ID: 1729447957678-->
END

START
Basic
```python
def is_mobile_phone(phone: str):
    match phone:
        case "0", "6", *_:
            return True
        case _:
            return False
```
Que renvoie `is_mobile_phone("0613367453")`? Pourquoi ?
Back:
`False`
Bien que ce soit une séquence, une [[str (chaîne de caractères)]] est traitée de façon atomique.
<!--ID: 1729447957681-->
END

STARTI [Basic] Comment matcher toute séquence qui commence par une [[str (chaîne de caractères)]] et termine par un couple d'entiers ? Back: `case str(), *_, (int(), int()):` <!--ID: 1729447957685--> ENDI