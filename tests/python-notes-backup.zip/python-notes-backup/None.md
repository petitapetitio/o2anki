MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***


***
TARGET DECK: Python

- STARTI [Basic] Qu'est-ce que l'objet `None` ? Back: Une constante spéciale utilisée pour représenter l'absence de valeur, ou une valeur nulle. <!--ID: 1728024344585--> ENDI
- STARTI [Basic] Est-ce que l'expression `{None: 0, 1: 0}` est valide ? Back:  Oui. `None` est hashable et peut être utilisé comme clé de dictionnaire <!--ID: 1728024344589--> ENDI

START
Basic  
```python
def command():  
    print("hello")

x = command()
```
Que vaut `x` ?
Back:  
`None` - une fonction renvoie toujours une valeur. Par défaut, elle renvoie `None`.
END