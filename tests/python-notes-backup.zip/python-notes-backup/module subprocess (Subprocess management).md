MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[process]]
Date : 2025-01-12
***

https://docs.python.org/3/library/subprocess.html

- intends to replace other modules and functions (os.system, os.spawn)
- recommandations
	- utiliser `subprocess.run` autant que possible
	- utiliser `subprocess.Popen` pour les cas avancés

```python
r = subprocess.run(["ls", "-la"], capture_output=True)  
print(r.args)             # ['ls', '-la']
print(r.returncode)       # 0
print(r.stdout.decode())  # affiche `ls -la`
```
