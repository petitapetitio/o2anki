MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://peps.python.org/pep-0572/
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-05
***

L'opérateur d'affectation permet de combiner expression et affectation.


***
TARGET DECK: Python
FILE TAGS: opérateurs

- STARTI [Basic] Que permet le walrus operator ? Back:  combiner *évaluation de l'expression* et *assignation* <!--ID: 1728627767745--> ENDI
- STARTI [Basic] Dans quelle version de python a été introduit le walrus operator ? Back:  3.8 <!--ID: 1728627767750--> ENDI


START
Basic
```python
re_match = re.match(r'Name: (\S)', input_string) 
if re_match:
        print(re_match.groups(1))
```
Comment réécrire cette expression en deux lignes ?
Back:  
À l'aide du walrus operator.
```python
if (re_match := re.match(r'Name: (\S)', input_string)):
        print(re_match.groups(1))
```
<!--ID: 1732172979363-->
END

START
Basic
Comment dédoublonner les appels à get_next_value() ? 
```python
v = get_next_value() 
while v is not None:
	# ... do some work with v ...
	v = get_next_value()
```
Back:  
À l'aide du walrus operator :
```python
while (v := get_next_value()) is not None:
	# ... do some work with v ...
```
<!--ID: 1732172979370-->
END

START
Basic
```python
def safe_int(s) -> Optional[int]: 
	try:
		return int(s) 
	except Exception:
		return None

[
    safe_int(s) 
    for s in ['1','2','a','11'] 
    if safe_int(s) is not None
]
```
Comment utiliser le walrus operator pour ne pas avoir à caster les strings deux fois ? 
Back:  
À l'aide du walrus operator :
```python
[
    safei 
    for s in ['1','2','a','11'] 
    if (safei: = safe_int(s)) is not None
]
```
<!--ID: 1732172979376-->
END

***

Exemple tiré de [[3 RESSOURCES/Livres/Fluent Python|Fluent Python]] : 

Que produit le code suivant ? 
```python
>>> x = 'ABC'
>>> codes = [ord(x) for x in x]
>>> x
```
'ABC'

Que produit le code suivant ? 
```python
>>> x = 'ABC'
>>> codes = [last := ord(c) for c in x]
>>> last
```
67

Que produit le code suivant ? 
```python
>>> x = 'ABC'
>>> codes = [last := ord(c) for c in x]
>>> c
```
NameError : name 'c' is not defined
