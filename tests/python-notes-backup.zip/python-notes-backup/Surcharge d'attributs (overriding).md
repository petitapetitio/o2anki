MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-28
***


***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] En quoi consiste la surcharge d'attributs ? Back: Redéfinir un attribut dans une classe fille. <!--ID: 1730827064316--> ENDI


START
Basic
```python
class A:
	x = "xA"

class B(A):
	x = "xB"
	
```
Que renvoie `B.x` ?
Back: `'xB'`
On dit que `B` surcharge l'attributs `x` de sa superclasse `A`.
<!--ID: 1730827064311-->
END


START
Basic
```python
class A:
	def f(self):
		return "fA"

class B(A):
	def f(self):
		return "fB"
	
```
Que renvoie `B().f()` ?
Back: `'fB'`
On dit que `B` surcharge la méthode `f` de sa superclasse `A`.
<!--ID: 1730827064313-->
END
