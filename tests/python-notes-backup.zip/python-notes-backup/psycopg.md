MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-11
***

- [psycopg2](https://pypi.org/project/psycopg2/)
- [psycopg3](https://www.psycopg.org/psycopg3/)


Avantage de psycopg3 :
- interface plus moderne
- support de async/await
- meilleurs performances
- support de COPY FROM/TO


D'où vient le nom ? 
- la v1 a été publiée dans les années 2000
- à cette époque, les drivers étaient complètement fucked up
- Federico Di Gregorio a codé une v1 simple en un weekend. Il a voulu le nommer psychopg en référence aux drivers psychotiques du marché mais a fait une faute de frappe, qui est restée.
- https://www.postgresql.org/message-id/36cffb61-3912-915c-4933-3bcd9cac063a%40dndg.it

> "just to  demonstrate that you can write something that works without over-engineering it. I wanted to call it psychopg (a reference to their psychotic driver) but I typed the name wrong."