MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Testing]]
Date : 2025-01-14
***

- quoi
	- cas typiques
	- cas aux limite
	- failing cases
- tips : 
	- lancer `from module import *` dans la console pour construire les exemples
	- la docstring peut être un copier-coller de la session interactive
	- peut s'intégrer avec le [[module unittest]] (https://docs.python.org/3/library/doctest.html#unittest-api)

###### Exemple
```python
def add(a, b):
    """
    >>> add(1, 2)
    3
    >>> add()
    Traceback (most recent call last):
      File "<stdin>", line 1, in <module>
    TypeError: add() missing 2 required positional arguments: 'a' and 'b'

    """
    return a + b


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# python mod.py      (n'affiche rien car les tests passent)
# python mod.py -v   (affiche le détail des tests exécutés)
```
