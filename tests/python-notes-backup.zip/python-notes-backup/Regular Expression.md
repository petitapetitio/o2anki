MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

- https://docs.python.org/3/library/re.html
- Mastering Regular Expressions, by Jeffrey Friedl (O’Reilly)
- https://docs.python.org/3/howto/regex.html
- https://pythex.org/
- https://regex101.com/
