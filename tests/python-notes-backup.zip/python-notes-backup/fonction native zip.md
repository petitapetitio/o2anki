MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

***
TARGET DECK: Python
FILE TAGS: 

https://docs.python.org/3/library/functions.html#zip
- STARTI [Basic] `list(zip([1, 2], [1, 2]))` ? Back:  `[(1, 1), (2, 2)]` <!--ID: 1734678007438--> ENDI
- STARTI [Basic] `list(zip([1, 2], [1]))` ? Back:  `[(1, 1)]` <!--ID: 1734678007439--> ENDI
- STARTI [Basic] `list(zip([1, 2], [1], strict=True))` ? Back:  `ValueError: zip() argument 2 is shorter than argument 1` <!--ID: 1734678007440--> ENDI
- STARTI [Basic] Comment itérer conjointement sur les valeurs de `l1 = [1, 2]`et `l2 = ['a', 'b']` ? Back:  `for x, y in zip(l1, l2): ...` <!--ID: 1734678007441--> ENDI
