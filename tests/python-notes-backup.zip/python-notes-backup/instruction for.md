MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/compound_stmts.html#the-for-statement
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Instructions de boucle]]
Date : 2024-10-12
***

***
TARGET DECK: Python
FILE TAGS: for

- STARTI [Basic] Qu'est-ce qu'une instruction `for` ? Back: une instruction qui répète l'exécution d'un bloc d'instructions pour chaque élément d'un itérable. <!--ID: 1728749077471--> ENDI
- STARTI [Basic] Comment se déroule `for x in iterable: ...` ? Back: Les éléments de l'itérable sont successivement assignés à `x` et le corps de la boucle est exécuté pour chaque élément. <!--ID: 1728749077474--> ENDI
- STARTI [Basic] Comment itérer sur les couples clé/valeur d'un dictionnaire `d` ? Back:  `for key, value in d.items():` <!--ID: 1728749077482--> ENDI
- STARTI [Basic] Qu'est-ce qu'une variable de contrôle ? Back: La variable qui contrôle le flux d'exécution d'une boucle. Ex : `i` dans `for (int i = 0; i < 10; ++i)` <!--ID: 1728749077486--> ENDI



START
Basic
Quelle est la syntaxe d'une instruction for ?
Back: 
```python
for target in iterable:
    statements
```
<!--ID: 1728749077428-->
END

START
Basic
Comment appelle-t-on cette variable ?
![[2024-09-28 Python in a nutshell-4.png]]
Back:
La variable de boucle ?

Le terme de variable de contrôle vient des langages comme `C` où l'on a `for (int i; i < 10; ++i)`. Il ne fait pas sens sur les boucles for Python car c'est l'[[itérable]] qui contrôle la boucle.
<!--ID: 1728749077433-->
END

START
Basic
Comment appelle-t-on ce bloc d'instructions ?
![[2024-09-28 Python in a nutshell-5.png]]
Back:
Le corps de boucle
<!--ID: 1728749077438-->
END

START
Basic
Qu'affiche 
```python
prototype = [1, '', 3] 
for prototype[1] in 'xyz':
	print(prototype)
```
?
Back:
```
[1, 'x', 3]
[1, 'y', 3]
[1, 'z', 3]
```
Toute expression LHS valide peut être utilisée comme cible d'assignation. ([[tricks]])
<!--ID: 1728749077447-->
END

START
Basic
Qu'affiche
```python
for x in []: 
	process(x)
print(x)
```
?
Back:
`UnboundLocalError: local variable 'x' referenced before assignment`
<!--ID: 1728749077454-->
END

START
Basic
Qu'affiche
```python
for x in [1, 2, 3]: 
	process(x)
print(x)
```
?
Back:
`3`
La variable de contrôle reste liée à la dernière valeur à laquelle l'instruction de boucle l'a liée.
<!--ID: 1728749077464-->
END

