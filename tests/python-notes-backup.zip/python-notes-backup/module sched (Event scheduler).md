MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/sched.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***


- thread safe
- takes functions as argument to allow simulated time (eg for testing) [[Injection de dépendance]]
- doesn't seems widely used - [[Asyncio]] semble plus adapté et flexible
- [[threading.Timer]] permet aussi de programmer des déclenchements
