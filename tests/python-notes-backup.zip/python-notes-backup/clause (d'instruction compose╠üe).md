MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***

- une *clause* se compose d'une **en-tête** et d'une **suite**. 
- une en-tête de clause commence par un [[keyword]] et termine par `:`
- une suite est un groupe d'instruction contrôlé par une clause 
- une suite composée d'instructions simples peut être placée directement après `:` et séparée de `;`
- une suite qui contient une instruction composée doit nécessairement être dans un bloc indenté


***
TARGET DECK: Python
FILE TAGS: instructions

- STARTI [Basic] qu'est-ce qu'une clause ? Back:  Une partie d'une [[instruction composée (compound statements)]] <!--ID: 1732172979405--> ENDI
- STARTI [Basic] De quoi se compose une clause ? Back:  d'une **en-tête** et d'une **suite**. <!--ID: 1728727115344--> ENDI
- STARTI [Basic] Comment commence et termine une en-tête de clause ? Back:  elle commence par un mot-clé (`if`, `while`, `case`, `try`, ...) et se termine par `:` <!--ID: 1728727115346--> ENDI
- STARTI [Basic] Qu'est-ce qu'une suite de clause ? Back:  un groupe d'instructions contrôlé par la clause. <!--ID: 1728727115348--> ENDI
- STARTI [Basic] clause : où peut-on placer une suite composée d'instructions simples ? Back:  <br>1) dans un [[bloc]] indenté <br>2) sur la même ligne, après `:`, en séparant les instructions par des `;` <!--ID: 1728727115350--> ENDI
- STARTI [Basic] clause : où doit être placée une suite contenant une instruction composée ? Back:  dans un bloc indenté (nécessairement). <!--ID: 1728727115352--> ENDI

START
Basic
Comment s'appelle cette partie d'une instruction composée ?
![compound statements-1.png](compound-statement-clause.png)
Back: Une clause
<!--ID: 1732172979385-->
END

START
Basic
Comment s'appelle cette partie de la clause d'une instruction composée ?
![compound statements-1.png](compound-statement-clause-header.png)
Back: L'en-tête de clause
<!--ID: 1732172979391-->
END

START
Basic
Comment s'appelle cette partie de la clause d'une instruction composée ?
![compound statements-1.png](compound-statement-clause-body.png)
Back: La "suite"
<!--ID: 1732172979399-->
END