MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/itertools.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: 

- STARTI [Basic] que contient le module itertools ? Back:  des fonctions performantes pour manipuler les itérateurs <!--ID: 1734710569107--> ENDI
- pairwise
	- STARTI [Basic]  `list(itertools.pairwise('ABCD'))` ? Back:  `[('A', 'B'), ('B', 'C')]` <!--ID: 1734710569114--> ENDI
	- STARTI [Basic]  `itertools.pairwise(seq)` mais avec la [[fonction native zip]] ? Back:  `zip(seq, seq[1:])` <!--ID: 1734710569117--> ENDI
- zip_longest
	- STARTI [Basic]  `list(itertools.zip_longest([1], [1, 2], fillvalue=0))` ? Back:  `[(1, 1), (0, 2)]` <!--ID: 1734710569122--> ENDI

