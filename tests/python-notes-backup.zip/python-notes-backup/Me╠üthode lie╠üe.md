MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-28
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] Qu'est-ce qu'une méthode liée ? Back: Une fonction attachée à une instance. Elle reçoit l'instance en premier paramètre. <!--ID: 1730827064507--> ENDI
- STARTI [Basic] classes : `type(C.f)` ? Back:  `<class 'function'>` ![[Méthode liée-1.png]]<!--ID: 1730827064509--> ENDI
- STARTI [Basic] classes : `type(C().f)` ? Back:  `<class 'method'>` <!--ID: 1730827064511--> ENDI
- STARTI [Basic] Est-ce que les fonctions sont des [[descripteur]]s ? Back:  Oui, ils implémentent `__get__` <!--ID: 1730827064513--> ENDI
- STARTI [Basic] Est-ce que les fonctions sont des data descriptors ? Back:  Non, ils implémentent `__get__` mais pas la méthode `__set__`. <!--ID: 1730827064515--> ENDI
- STARTI [Basic] À quoi correspond l'appel de fonction `x.f(a, b)` lorsque `f` est définie dans la classe de `x` ? Back:  `x.__class__.__dict__['f'](x, a, b)`  <!--ID: 1730827064517--> ENDI


START
Basic
```python
class A:
    def f(self): 
        ...
```
À quel moment la méthode `f` se retrouve liée à une l'instance ?
Back: 
Lors de l'accès à l'attribut via la notation point, avant l'appel. Python lie la méthode en appelant `__get__` pendant la résolution de l'attribut.
<!--ID: 1730827064500-->
END


START
Basic
`set(vars(type(C().f)).keys()) <= set(dir(C().f))` ?
Back: 
`True` 
Les attributs qu'on trouve avec vars() sont nécessairement aussi trouvés avec dir()
<!--ID: 1730827064502-->
END


START
Basic
```python
def f(self, b, c):  
	return self, b, c  
  
class C:  
	name = f
```
Est-ce que `C().name("b", "c")` est valide ?
Back: Oui
Comme `name` est un attribut de classe, l'appel à `__get__` sur `f` transforme `c.name` en une méthode liée à l'instance `c`, ce qui permet d'appeler `c.name("b", "c")`.
<!--ID: 1730827064504-->
END

