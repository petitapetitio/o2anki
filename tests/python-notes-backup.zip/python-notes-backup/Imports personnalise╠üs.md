MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-08
***

***
TARGET DECK: Python
FILE TAGS: imports

- STARTI [Basic] Comment coder une fonction d'import personnalisée ? Back: Via `sys.path_hooks` <br>(plus granulaire et moins risqué que de redéfinir la [[fonction native __import__]]) <!--ID: 1731053653016--> ENDI

START
Basic
Dans quel cas peut-il être utile de définir un mécanisme d'import personnalisé ?
Back:
Importer du code depuis :
- un format d'archive autre que zip
- une base de données
- le réseau
<!--ID: 1731053653017-->
END



Si besoin de ce type de fonctionnalités, lire : https://peps.python.org/pep-0451/

Exemple simple d'utilisation de `sys.path_hooks` avec la fonction legacy `find_module`
```python
import sys, types

class ImporterAndLoader:
    """importer and loader can be a single class"""
    fake_path = "!dummy!"

    def __init__(self, path):
        # only handle our own fake-path marker
        if path != self.fake_path:
            raise ImportError

    def find_module(self, fullname):
        # don't even try to handle any qualified module name
        if "." in fullname:
            return None
        return self

    def create_module(self, spec):
        # returning None will have Python fall back and
        # create the module "the default way"
        return None

    def exec_module(self, mod):
        # populate the already initialized module
        # just print a message in this toy example
        print(f"NOTE: module {mod!r} not yet written")
        sys.path_hooks.append(ImporterAndLoader)
        sys.path.append(ImporterAndLoader.fake_path)
        if __name__ == "__main__":  # self-test when run as main script
            import missing_module  # importing a simple *missing* module
        print(missing_module)  # ...should succeed
        print(sys.modules.get("missing_module"))  # ...should also succeed

```
