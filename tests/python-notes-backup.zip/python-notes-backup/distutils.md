MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3.11/library/distutils.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-14
***

***
TARGET DECK: Python
FILE TAGS: packaging

- STARTI [Basic] Qu'est-ce que `distutils` ? Back:  Un module de la bibliothèque standard historiquement utilisé pour distribuer et installer des [[package]]s.  <!--ID: 1731677487742--> ENDI
- STARTI [Basic] Quand est-ce que `distutils` a été intégré à Python ? Back:  En 2000, dans la version 1.6 (voir la [release note de la 0.1 de distutils](https://svn.python.org/projects/distutils/tags/Distutils-0_1/README) et la [release note de Python 1.6](https://www.python.org/download/releases/1.6/)) <!--ID: 1731677487743--> ENDI
- STARTI [Basic] Quelles étaient les deux grandes limites de `distutils` ? Back: <br>1. Rythme de mise à jour lent (car intégré à la stdlib) <br>2. Manque de documentation <!--ID: 1731677487744--> ENDI
- STARTI [Basic] Dans quelle version de Python `distutils` a-t-il été déprécié ? Back: [[Python 3.10]] (2021), avec la [PEP 632](https://peps.python.org/pep-0632/) <!--ID: 1731677487745--> ENDI
- STARTI [Basic] Dans quelle version de Python `distutils` disparaît ? Back: [[Python 3.12]] (2023) <!--ID: 1731677487746--> ENDI
- STARTI [Basic] Quelle est l'alternative officielle à `distutils` ? Back:  [[setuptools]] <!--ID: 1731677487747--> ENDI

- Auteurs : Greg Ward, Fred Drake

- a émergé pour répondre au pb lié à l'installation de modules d'extensions dans lang compilés