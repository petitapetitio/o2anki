MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org
Projets :
Tags : 
Date : 2023-10-03
***

Python
- [[Histoire de Python]]
- Pourquoi
	- Populaire
	- Facile à apprendre
- Philosophie
	- “coding by and for consenting adults.” (d'où relation mitigée avec typage)
- Gérer les versions
	- installer une version `pyenv install <version>`
	- switcher `pyenv global <version>`, `pyenv local <version>`, `pyenv shell <version>`
- [[Environnement virtuel]]
- [[gitignore template (Python)]]
- [[__init__.py|__init__.py]]
- [[Python Path]]
- Bibliothèques
	- Testing
		- [[pytest|pytest]]
		- [[Mutation testing]] frameworks
			- [[Mutmut]] - encore actif | mais une galère à setup et à tester
			- Mutatest -- dernier commit en février 2023
			- MutPy -- plus de màj depuis 2019
	- Programmation fonctionnelles :
		- [returns](https://returns.readthedocs.io/en/latest/)  (ex dry-python) 👍 
		- [pymonad](https://github.com/jasondelaat/pymonad) : répertoire pas très vivant
		- Dépréciée --  [pymaybe](https://github.com/ekampf/pymaybe) 
		- Dépréciée -- [maybe-else](https://github.com/matthewgdv/maybe) 
- Alternatives
	- Superset
- Community
	- [[Guido van Rossum]]
	- - [[Astral]]
		- authors of uv, ruff
		- fast tools for the python ecosystem
		- https://astral.sh/about
- Ressources 
	- Documentation
		- https://docs.python.org/3/ ("online docs")
		- https://docs.python.org/3/library/index.html
		- https://docs.python.org/3/reference/index.html
		- https://docs.python.org/3/glossary.html
	- Podcasts
		- https://pythonbytes.fm/episodes/all
	- Newsletter
		- https://www.stxnext.com/blog/top-python-newsletters/
	- [[Livres sur Python]]
	


***
TARGET DECK: Python

- STARTI [Basic] Que taper dans la barre de recherche pour accéder à la documentation en ligne ? Back: `docs.python.org` <!--ID: 1728024344793--> ENDI