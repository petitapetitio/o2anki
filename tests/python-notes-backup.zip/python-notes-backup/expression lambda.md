MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/expressions.html#lambda
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-25
***

***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] Qu'est-ce qu'une lambda expression ? Back:  Une expression qui crée <br>- une fonction anonyme, <br>- dont le corps est composé d'une expression unique <br>- et dont le résultat est automatiquement renvoyé. <!--ID: 1730827063892--> ENDI
- STARTI [Basic] Est-ce qu'il existe des cas ou les lambda sont la seule option ? Back:  Non, il est toujours possible de passer par une instruction `def` locale.  Les lambdas sont parfois pratiques mais il est en général préférable de passer par des instructions `def` pour des questions de lisibilité. <!--ID: 1730827063895--> ENDI

