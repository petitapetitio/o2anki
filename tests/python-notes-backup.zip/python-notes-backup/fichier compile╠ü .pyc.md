MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/fr/3.13/tutorial/modules.html#compiled-python-files
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-07
***

***
TARGET DECK: Python
FILE TAGS: imports


- STARTI [Basic] dans quel cas est-ce que le bytecode d'un module est compilé ? Back:  <br>Si le fichier `.pyc` n'existe pas, <br>s'il est plus ancien que le fichier source, <br>ou s'il a été compilé avec une autre version de python. <!--ID: 1731053653002--> ENDI
- STARTI [Basic] quel sera le nom du fichier bytecode de `m.py` compilé avec la python `3.12.4` ? Back:  `m.cpython-312.pyc` <!--ID: 1731053653003--> ENDI
- STARTI [Basic] où sera enregistré le bytecode du module `~/dev/project/m.py` ? Back:  Dans un `__pycache__` à côté du module (`~/dev/project/__pycache__/`)  <!--ID: 1731053653004--> ENDI
- STARTI [Basic] Comment Python détermine-t-il si un fichier `.pyc` est obsolète par rapport au `.py` ? Back:  à partir d'un timestamp interne (et pas à partir de la date enregistrée par le système de fichier) <!--ID: 1731053653005--> ENDI
- STARTI [Basic] Quel piège peut survenir avec les fichiers `.pyc` obsolètes ? Back: Si on supprime un `.py` sans supprimer son `.pyc`, le code reste accessible à l'exécution. ([[gotcha]]) <!--ID: 1731053653006--> ENDI
- STARTI [Basic] Comment éviter l'exécution de "code fantôme" à partir d'anciens fichiers `.pyc` ? Back:  Nettoyer les dossiers `__pycache__` et utiliser l'option `-B` pour éviter la création de nouveaux `.pyc` <!--ID: 1731053653007--> ENDI
- STARTI [Basic] Quelle est l'impact de l'option `-B` sur les performances ? Back:  L'option `-B` affecte uniquement les performances au démarrage. <!--ID: 1731053653008--> ENDI
- STARTI [Basic] Est-il utile de générer les `.pyc` dans un [[conteneur]] ? Back:  Non car les `.pyc` générés sont perdus à chaque redémarrage <!--ID: 1731053653009--> ENDI
