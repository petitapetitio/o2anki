MOC : 
Source :
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python|Python]]
Date : 2024-10-04
***

https://mypy.readthedocs.io/en/stable/cheat_sheet_py3.html

pour générer automatiquement les annotations sur un code legacy : 
https://github.com/Instagram/MonkeyType