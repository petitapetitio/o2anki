MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

- https://docs.python.org/3/library/functions.html#bin

***
TARGET DECK: Python
FILE TAGS: 


- STARTI [Basic] `bin(3)` ? Back:  `0b11` <!--ID: 1734678007472--> ENDI
- STARTI [Basic] `bin(1.5)` ? Back:  `TypeError` <!--ID: 1734678007473--> ENDI

