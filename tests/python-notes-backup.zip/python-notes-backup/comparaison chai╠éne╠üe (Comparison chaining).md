MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-05
***


***
TARGET DECK: Python
FILE TAGS: opérateurs

- STARTI [Basic] Qu'est-ce qu'une comparaison chaînée ? Back: Une suite de comparaisons combinées avec `and`, écrite de façon compacte. Ex : `a < b < c`  <!--ID: 1731910452460--> ENDI
- STARTI [Basic] À quoi équivaut la comparaison chaînée `a < b < c` ? Back: `a < b and b <= c` : les comparaison chaînées impliquent un "et" logique. <!--ID: 1731910452463--> ENDI
- STARTI [Basic] `a < b and b <= c and c < d` en + compacte ? Back: `a < b <= c < d` ([[tricks]]) <!--ID: 1728239138010--> ENDI
