
Super article : https://www.pythonmorsels.com/goose-typing/

Consiste à utiliser le [[duck typing]] (pas d'héritage explicite ni d'interface) conjointement avec les fonctions natives `isinstance` et `issubclass`.

En pratique, consiste à implémenter : 
- `__instancecheck__` sur une [[métaclasse]]
- `__subclasscheck__` sur une [[métaclasse]]
- [[méthode spéciale __subclasshook__]]
- ou utiliser [[Sous-classe virtuelle (register)]]
afin de faire fonctionner `isinstance`, `issubclass` sans héritage explicite.
