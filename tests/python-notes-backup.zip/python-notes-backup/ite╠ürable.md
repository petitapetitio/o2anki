MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[module collections (python) 🌟]]
Date : 2024-10-03
***


***
TARGET DECK: Python
- STARTI [Basic] Qu'est-ce qu'un itérable Back: Un objet sur lequel tu peux boucler. <!--ID: 1728239137995--> ENDI
- STARTI [Basic] Qu'indique l'interface *Iterable* ? Back: Qu'il est possible d'utiliser `for _ in x` dessus  <!--ID: 1728024344783--> ENDI
- STARTI [Basic] Est-ce que tous les itérables sont des conteneurs ? Back: Non. Les générateurs sont itérables mais ne sont pas des conteneurs. <!--ID: 1728239137999--> ENDI
- STARTI [Basic] Est-ce que toutes les collections sont itérables ? Back: Oui - donc les séquences, les mappings, et les ensembles sont itérables. <!--ID: 1728239138003--> ENDI
