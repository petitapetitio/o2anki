MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/expressions.html, https://docs.python.org/fr/3.13/glossary.html#term-expression
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-05
***

Une expression est une combinaison de [[Token]] (valeurs, variables, opérateurs, fonction) qui produit une valeur lorsqu'elle est interprétée.

Par exemple, dans le code python suivant, `a <= b` est une expression qui produit un booléen :  
```python
def min(a, b):
    return a if a <= b else b
```


***
TARGET DECK: Python

- STARTI [Basic] Qu'est-ce qu'une expression ?  Back: une phrase de code qui produit une valeur lorsqu'elle est interprétée (comme `5`, `5 + 5`). <!--ID: 1728036834537--> ENDI
