MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/functions.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***

***
TARGET DECK: Python
FILE TAGS: std-functions

- STARTI [Basic] Comment convertir une liste `l` en tuple ? Back:  `tuple(l)` <!--ID: 1728627767396--> ENDI
- STARTI [Basic] Comment convertir un tuple `t` en liste ? Back:  `list(t)` <!--ID: 1728627767401--> ENDI
