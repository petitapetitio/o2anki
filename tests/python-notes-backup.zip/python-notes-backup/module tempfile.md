MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/tempfile.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Testing]]
Date : 2025-01-14
***

Cas d'usages : quand tu gères un volume de donnée trop important pour la RAM et que tu veux le stocker sur le disque de façon temporaire, sans permettre aux autres processus de le lire, sans risque de collision avec un autre fichier, et en garantissant le nettoyage.


Fonctionnalités
- créer un répertoire temporaire `with TemporaryDirectory() as d:`
- créer un fichier temporaire `with TemporaryFile() as f:`
- accéder au cache du système : `gettempdir()`
- `SpooledTemporaryFile` permet de garder l'objet en mémoire si sa taille le permet. Cela équivaut à BytesIO (du [[module io]]) qui sera enregistré sur disque si besoin.

Gotcha : 
- avec `tempfile.mkdtemp`, `tempfile.mkstemp` c'est à l'utilisateur de s'assurer de supprimer le fichier / dossier temporaire créés. **Même avec context manager ?**

###### Démonstration
```python
with NamedTemporaryFile() as f:
    temp_file_path = f.name # /var/folders/1p/f01pmy1x1kb8dxw165_h6zlr0000gn/T
    assert os.access(temp_file_path, os.F_OK) # le fichier existe

assert not os.access(temp_file_path, os.F_OK) # le fichier n'existe plus
```

###### Exemple pour une [[interprocess communication (IPC)]]
```python
from tempfile import NamedTemporaryFile
import subprocess

with NamedTemporaryFile() as f:
    f.write(b"data")
    f.flush()
    subprocess.run(['external_program', f.name])
```