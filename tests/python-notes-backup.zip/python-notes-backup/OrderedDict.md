MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: OrderedDict

- STARTI [Basic] `OrderedDict({1:1, 2:2}) == OrderedDict({2:2, 1:1})` ? Back:  `False` <!--ID: 1734710569232--> ENDI
- STARTI [Basic] `OrderedDict({1:1, 2:2}) == {1:1, 2:2}` ? Back:  `True` <!--ID: 1734710569234--> ENDI
- STARTI [Basic] `OrderedDict({1:1, 2:2}) == {2:2, 1:1}` ? Back:  `True` <br>L'ordre n'est pas pris en compte dans la comparaison avec un `dict` ordinaire ([[gotcha]]) <!--ID: 1734710569237--> ENDI
- STARTI [Basic] `isinstance(collections.OrderedDict(), dict)` ? Back:  `True` ![[2024-09-28 Python in a nutshell-10.png]] <!--ID: 1734710569239--> ENDI
- STARTI [Basic] `d = OrderedDict(dict.fromkeys("abc", 0)); d.move_to_end("a"); dict(d)` ? Back:   `{'b': 0, 'c': 0, 'a': 0}` <!--ID: 1734710569240--> ENDI

