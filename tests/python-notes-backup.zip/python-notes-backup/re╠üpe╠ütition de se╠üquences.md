MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/stdtypes.html#common-sequence-operations
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[sequence]]
Date : 2024-10-11
***

***
TARGET DECK: Python
FILE TAGS: sequence


- STARTI [Basic] comment répéter la séquence `s = [1, 2, 3]` 5 fois ? Back:  `s * 5` <!--ID: 1731910452442--> ENDI
- STARTI [Basic] comment créer une liste de cinq zéros ? Back:  `[0] * 5` <!--ID: 1731910452445--> ENDI
- STARTI [Basic] `[7] * 0` ? Back:  `[]` une liste vide de type `int` <!--ID: 1731910452449--> ENDI
- STARTI [Basic] `[7] * (-5)` ? Back:  `[]` une liste vide de type `int` <!--ID: 1731910452452--> ENDI

START
Basic
Qu'affiche
```python
lists = [[]] * 3  # [[], [], []]
lists[0].append(3)
print(lists)
```
?
Back:
`[[3], [3], [3]]` ([[gotcha]]) (voir la [note 2](https://docs.python.org/3/library/stdtypes.html#common-sequence-operations))
<!--ID: 1731910452437-->
END
