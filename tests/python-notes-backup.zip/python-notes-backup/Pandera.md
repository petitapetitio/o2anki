
- Bibliothèque python pour valider les schémas de dataframe
- Bénéfices : code + lisible et + robuste

Il est possible
- [d'inférer un schéma à partir d'un dataframe](https://pandera.readthedocs.io/en/stable/schema_inference.html)v
- de transformer un dataframe dans le schéma cible (à l'aide de coerce)

## Supported pandas datatypes

By default, pandera supports the validation of pandas dataframes, so pandera schemas support any of the [data types](https://pandas.pydata.org/docs/user_guide/basics.html#dtypes) that pandas supports:
- Built-in python types, e.g. `int`, `float`, `str`, `bool`, etc.
- [Numpy data types](https://numpy.org/doc/stable/user/basics.types.html), e.g. `numpy.int_`, `numpy.bool__`, etc.
- Pandas-native data types, e.g. `pd.StringDtype`, `pd.BooleanDtype`, `pd.DatetimeTZDtype`, etc.
- Any of the [string aliases](https://pandas.pydata.org/docs/user_guide/basics.html#dtypes) supported by pandas.