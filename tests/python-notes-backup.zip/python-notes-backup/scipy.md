MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-13
***

- https://docs.scipy.org/doc/scipy/index.html
- existe depuis 2008
- open-source software for mathematics, science, and engineering
- for advanced numeric computation (go further than [[numpy]])
- pronounced “Sigh Pie”
