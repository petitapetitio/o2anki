MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-18
***

- https://docs.python.org/3/library/socket.html
- implémentation des [[Berkeley Sockets]] pour Python
- erreurs (sous-classes de [[OSError]])
	- herror : erreur dans la résolution du hostname (`gethostbyname`, `gethostbyaddr`)
	- gaierror : erreur lors de (`getaddrinfo` ou `getnameinfo`)
	- timeout 
- constantes
	- reprennent les constantes de la bibliothèque C
	- `AF_BLUETOOTH` : socket de la famille des adresses Bluetooth
	- `SOCK_DGRAM` : connectionless socket
	- `SOCK_STREAM` : connection oriented socket
- principales fonctions
	- `getaddrinfo(host, port)`
	- `getdefaulttimeout()` / `setdefaulttimeout(timeout_s)`
	- `getfqdn(host)` (fully qualified domain)
	- `gethostbyaddr(ip_adress)`
	- `gethostbyname(hostname)`
	- `getnameinfo(sock_addr)`
- peut être sécurisé grâce au [[module ssl]]

```python
# -- INFO ----------------  
print(f"{socket.getdefaulttimeout()=}")
print(f"{socket.getaddrinfo('localhost', 8883)[0]=}")
print(f"{socket.getfqdn('localhost')=}")
print(f"{socket.gethostname()=}")
print(f"{socket.gethostbyname('localhost')=}")
print(f"{socket.gethostbyaddr('127.0.0.1')=}")

# socket.getdefaulttimeout()=None  
# socket.getaddrinfo('localhost', 8883)[0]=(<AddressFamily.AF_INET: 2>, <SocketKind.SOCK_DGRAM: 2>, 17, '', ('127.0.0.1', 8883))  
# socket.getfqdn('localhost')='1.0.0.127.in-addr.arpa'  
# socket.gethostname()='dune'  
# socket.gethostbyname('localhost')='127.0.0.1'  
# socket.gethostbyaddr('127.0.0.1')=('localhost', ['1.0.0.127.in-addr.arpa'], ['127.0.0.1'])  
```

#### socket object
- https://docs.python.org/3/library/socket.html#socket-objects
- est un context manager
- **timeouts**
	- `None` : chaque opération bloque le thread jusqu'à ce qu'il termine 
	- `0` : chaque opération lève une exception si elle ne peut pas terminer immédiatement
	- `>0.0` : chaque opération bloque jusqu'à terminer ou que le timeout soit écoulé
- créer une socket
	- `create_connection(adress)`
	- `socket(family, type)`
- fonctions
	- recevoir
		- `recv(buffer_size) -> bytes`
		- `recvfrom(buffer_size) -> bytes, address`
		- `recvfrom_into(buffer) -> nbytes, address`
	- envoyer
		- en mode connection
			- `send(bytes) -> nbytes` 
			- `sendall(bytes) -> None`
		- en mode connectionless
			- `sendto(bytes, address)`
	- `shutdown(flag)` (reads, writes, reads and writes)
- les flags dépendent de la plateforme
	- unix : [recv(2) manpage](https://man7.org/linux/man-pages/man2/recv.2.html), [send(2) manpage](https://man7.org/linux/man-pages/man2/send.2.html)
	- windows : [send](https://learn.microsoft.com/en-us/windows/win32/api/winsock2/nf-winsock2-send)

- [[Simple connectionless example]]
- [[Simple connection-oriented example]]


Ressources : 
- https://docs.python.org/3/howto/sockets.html
