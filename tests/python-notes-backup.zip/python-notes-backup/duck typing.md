MOC : [[SOFTWARE ENGINEERING]]
Source : claude
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-25
***

Le duck typing peut être appliqué au [[5 GARDEN/Notes/RECRUTEMENT|RECRUTEMENT]] : si tu sais faire la tâche que j'ai besoin que tu exécutes, alors peu m'importe ton diplôme.

Une façon de [[Regarde ce que les gens font plutôt que ce qu'ils disent (Effet Qatar 2022)]]

***
TARGET DECK: Python
FILE TAGS: typing


- STARTI [Basic] Qu'est-ce que le duck typing ? Back:  Une approche où on regarde ce qu'un objet sait faire (ses méthodes) plutôt que son type intrinsèque ou annoté. Si ça marche comme un canard, on le traite comme un canard. <!--ID: 1730827063852--> ENDI
- STARTI [Basic] Quelle expression résume le duck typing ? Back: If it looks like a duck, swims like a duck, and quacks like a duck, then it probably _is_ a duck. (« si ça ressemble à un canard, nage comme un canard et bavarde comme un canard, alors c'est probablement un canard. ») <!--ID: 1733293675029--> ENDI

START
Basic
Un exemple de duck typing en Python ?
Back:
```python 
def faire_nager(animal): 
    animal.nager() 
	# Si ça nage, peu importe la classe !
```
<!--ID: 1730827063850-->
END
