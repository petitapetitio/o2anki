MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

***
TARGET DECK: Python
FILE TAGS: 

https://docs.python.org/3/library/functions.html#round
- STARTI [Basic] `round(1.1)` ? Back:  `1` (values are rounded to the closest multiple of 10^{-ndigits}) <!--ID: 1734678007445--> ENDI
- STARTI [Basic] `round(1.5)` ? Back:  `2` (if two multiples are equally close, rounding is done toward the even choice) <!--ID: 1734678007446--> ENDI
- STARTI [Basic] `round(0.5)` ? Back:  `2` (if two multiples are equally close, rounding is done toward the even choice) ([[gotcha]]) <!--ID: 1734678007447--> ENDI
- STARTI [Basic] `round(0.1234, 3)` ? Back:  `0.123` <!--ID: 1734678007448--> ENDI
- STARTI [Basic] `round(2.675, 2)` ? Back:  `2.67` (The behavior of round() for floats can be surprising because most decimal fractions can’t be represented exactly as a float.) ([[gotcha]]) <!--ID: 1734678007449--> ENDI
- STARTI [Basic] `x = 0.12345` à 2 chiffres après la virgule ? Back:  `round(x, 2)` <!--ID: 1734678007450--> ENDI
