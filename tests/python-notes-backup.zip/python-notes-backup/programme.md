MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***


- une séquence d'instructions 
- organisé dans des fichiers sources ([[script python]], [[module]])

***
TARGET DECK: Python
FILE TAGS: programs

- STARTI [Basic] Qu'est-ce qu'un programme Python ? Back:  une séquence d'instructions python conçues pour répondre à un problème et organisées dans des fichiers source. <!--ID: 1730972172877--> ENDI
- STARTI [Basic] Comment se matérialise un programme minimal en python ? Back:  Un fichier source unique `myprogram.py` qui utilise uniquement la bibliothèque standard et s'exécute avec `python myprogram.py` <!--ID: 1730972172880--> ENDI
