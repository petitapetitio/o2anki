MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

***
TARGET DECK: Python
FILE TAGS: lexical-structure

START
Basic
Qu'est-ce qu'un bloc ?
Back: 
Un groupe d'instructions qui ont le même niveau d'indentation. Les lignes vides et commentaires sont ignorés.
Ex : 
```python
def fonction():
    x = 1        # début du bloc
                 # ligne vide ignorée
# commentaire ignoré
    y = 2        # toujours dans le bloc
         # des espaces puis un commentaire - ignoré
    return x + y # fin du bloc
```
<!--ID: 1731772677691-->
END
