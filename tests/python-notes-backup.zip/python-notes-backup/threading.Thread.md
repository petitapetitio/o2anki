MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/threading.html#thread-objects
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[thread]]
Date : 2025-01-12
***


En python les threads s'exécutent un à la fois (à cause du [[Global interpreter lock (GIL)]])

Daemon threads
- program wait `Threads` that are not `daemons` to complete before it terminates
- `Threads` that _are_ daemons are killed wherever they are when the program is exiting
- (nom inspiré des [[daemon]])

Utilisation basique : 
```python
import logging
import threading
import time

# exec 1 : daemon=False ; x.join commenté
# exec 2 : daemon=True  ; x.join commenté
# exec 3 : daemon=Any   ; x.join activé


def thread_function(name):
    logging.info("Thread %s: starting", name)
    time.sleep(2)
    logging.info("Thread %s: finishing", name)


if __name__ == '__main__':
    logging.basicConfig(format="%(asctime)s: %(message)s", level=logging.INFO, datefmt="%H:%M:%S")

    logging.info("Main    : before creating thread")
    x = threading.Thread(target=thread_function, args=(1,))
    logging.info("Main    : before running thread")
    x.start()
    logging.info("Main    : wait for the thread to finish")
    x.join()
    logging.info("Main    : all done")
```


Lorsque tu travails avec plusieurs threads, tu peux être intéressé par [[ThreadPoolExecutor]].
