MOC : [[SOFTWARE ENGINEERING]]
Source :
Projets :
Tags : [[COMPUTER NETWORKS]], [[SECURITY]]
Date : 2025-01-18
***

- provide secure connection over an insecure network
- Contexte
	- créé en 1995 en remplacement de [[Telnet]] (échanges non sécurisés)
	- est devenu nécessaire avec le progression d'internet
- Principe
	- **un message chiffré avec la clé publique ne peut être déchiffré qu'avec la clé privée** (aka - [[asymmetric encryption]])
- processus de connexion
	- le client contact le serveur
	- le serveur envoie sa clé publique au client
	- le client vérifie la clé à la main, à partir de l'empreinte, et l'ajoute dans `~/.ssh/known_hosts`
	- le client et le serveur négocient une clé de session
	- le reste de la communication est chiffrée avec cette clé
- processus d'authentification
	- par mot de passe (moins sécurisé car le mdp peut être déviné, rainbowed, brute forced)
	- par clé SSH 
		- le client envoie sa clé publique au serveur
		- le serveur vérifie si cette clé est autorisée (dans `~/.ssh/authorized_keys`)
		- le serveur envoie un nombre aléatoire chiffre avec la clé publique du client
		- le client déchiffre le challenge avec sa clé privée et l'envoie au serveur
- implémentation
	- usually over [[Transmission Control Protocol (TCP)]]


###### Cheat sheet
```
ssh-keygen -t  ed25519
cat ~/.ssh/id_ed25519.pub
```
