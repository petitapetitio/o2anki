- 2023

```python
python -m ensurepip --upgrade
python -m pip install --upgrade setuptools
python -m pip install <module>
```

