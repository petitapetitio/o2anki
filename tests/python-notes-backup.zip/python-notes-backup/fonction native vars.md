MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/functions.html#vars
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-09
***


***
TARGET DECK: Python
FILE TAGS: 

- `vars()` ? le dictionnaire du namespace courant (équivalent de la [[fonction native locals]])
- `vars(obj)` ? le dictionnaire des attributs d'instance de obj

START
Basic
Qu'affiche `print(vars(C()))` ?
```python
class C:
    __slots__ = ["x", "y"]
    def __init__(self):
        self.x = 0
        self.y = 0
```
Back:
`TypeError: vars() argument must have __dict__ attribute`
<!--ID: 1734253836519-->
END


START
Basic
Qu'affiche
```python

class A:
    cx = 'x'
    
    def __init__(self):
        self.x = 1
    
    def f(self):
        pass


class B(A):
    cy = 'y'
    
    def __init__(self):
        super().__init__()
        self.y = 2

    def g(self):
        pass

print(vars(B()))
```
?
Back:
```python
{'x': 1, 'y': 2}
```
<!--ID: 1734678007481-->
END

START
Basic
```python

class A:
    cx = 'x'
    
    def __init__(self):
        self.x = 1
    
    def f(self):
        pass


class B(A):
    cy = 'y'
    
    def __init__(self):
        super().__init__()
        self.y = 2

    def g(self):
        pass

pprint(vars(B))
```
?
Back:
```python
mappingproxy({'__doc__': None,
              '__init__': <function B.__init__ at 0x102b01080>,
              '__module__': '__main__',
              'cy': 'y',
              'g': <function B.g at 0x102b01120>})
```
<!--ID: 1734678007482-->
END