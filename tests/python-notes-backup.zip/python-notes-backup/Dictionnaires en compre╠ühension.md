MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[dict]]
Date : 2024-10-12
***

***
TARGET DECK: Python
FILE TAGS: dict

- STARTI [Basic] `{s: i for (i, s) in enumerate(['zero', 'one', 'two'])}` ? Back:  `{'zero': 0, 'one': 1, 'two': 2}` <!--ID: 1728749077292--> ENDI
- STARTI [Basic] Comment produit l'index inverse d'un dictionnaire en compréhension ? Back:  `{value: key for (key, value) in d.items()}` <!--ID: 1728749077296--> ENDI
