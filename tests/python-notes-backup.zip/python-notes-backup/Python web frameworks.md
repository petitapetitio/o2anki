MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-22
***

- liste complète : https://wiki.python.org/moin/WebFrameworks
- fullstack (everything you may need ~)
	- [[Django]]
	- [[web2py]] → [[py4web]]
	- py4web
		- https://py4web.com/
		- for database-driven web applications
	- TurboGears
	- Pyramid
		- https://trypyramid.com/
- lightweight (just what you need ~)
	- the knowledge-heavy, resources-light approach
	- utilities
		- [[werkzeug]]
			- collection of utilities for [[WSGI (Web Server Gateway Interface)]]
			- https://werkzeug.palletsprojects.com/en/stable/
		- oso (Python Authorization Library)
			- https://www.osohq.com/authorization-library/python
			- support natif de [[Django]], [[Flask]], [[SQLAlchemy]]
		- Beaker
			- https://beaker.readthedocs.io/en/latest/
			- library for caching and sessions
	- [[Flask]]
	- [[FastAPI]]
