MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

ne permet pas d'opération sur les dates ? (le [[module datetime]] permet des opérations)

time instant
- `time.time()` : `1736841182.9470751` (secondes since the epoch . fractions de secondes)
- `time.localtime()` : [[timetuple (struct_time)]]


[[Cheat sheet]] : 
```python
import time

time.sleep(0)

time.timezone  # -3600
time.tzname    # ('CET', 'CEST')

# current instant time in seconds since the epoch
time.time()

# current instant time as timetuple
year, month, day, hour, minute, second, weekday, yearday, dst_flag = time.localtime()

t_name = time.tzname[dst_flag]

# timetuple → seconds since epoch
time.mktime((year, month, day, hour, minute, second, weekday, yearday, dst_flag))

# seconds since epoch → timetuple
time.gmtime(1000000)

# str from timetuple (strftime)
time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime())  # '2025-01-11T16:55:46+0100'

# str parse time (strptime)
time.strptime('2025-01-11T16:55:46+0100', "%Y-%m-%dT%H:%M:%S%z")  # time.struct_time(tm_year=2025, tm_mon=1, tm_mday=11, tm_hour=16, tm_min=55, tm_sec=46, tm_wday=5, tm_yday=11, tm_isdst=-1)

```
