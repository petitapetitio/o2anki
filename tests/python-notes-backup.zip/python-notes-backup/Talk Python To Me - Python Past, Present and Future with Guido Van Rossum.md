---
MOC:
  - "[[SOFTWARE ENGINEERING]]"
Date: 2024-12-07
Source: Talk Python To Me
Type de contenu: Podcast
Projet associé: "[[$P - Mémoriser Python (Mastering Python)]]"
---

https://podcasts.apple.com/fr/podcast/talk-python-to-me/id979020229?i=1000381781024

[[Guido van Rossum]] 
- started with electronics 
- 4 years in ABC team after graduated where he learned to be langage désigner. Worked on the implémentation.

Python 
- general purpose langage (deeply), application agnostic in the philosophy 
- being open source was a key to success 
- stdlib constraints 
	- slow pace 
	- compatibility exigeances 
	- sqllite : stable, popular 

Core developers 
- study python 
- contribute with high quality 
- get mentored 
- qualities : attention to détails 

Migration 
- sous estimée 
- bien + dur qu’anticipé 
- qqes baxkports pour 2.7

Guido 
- works (still ?) at dropbox 
- dream of removing the gil 
- love telling the story of generators 
- favorite features 
	- asyncio 
	- type annotation, mypy 

Type checker 
- complémentaire des tests unitaires (mais faible overlap)