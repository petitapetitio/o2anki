MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Testing]]
Date : 2025-01-14
***

- cela améliore les performances (l'écriture sur disque est longue)
- cela facilite le cleanup (pas besoin de supprimer le fichier après coup)


```python
f = StringIO()

f.write("hello")

f.seek(0)
assert f.read() == "hello"
```