MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/compound_stmts.html#function-definitions
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-23
***

***
TARGET DECK: Python
FILE TAGS: functions

- STARTI [Basic] qu'est-ce qu'une fonction ? Back:  un bloc d'instructions réutilisable, qui prend des arguments en entrée, effectue des opérations, et peut renvoyer un résultat. <!--ID: 1730827064592--> ENDI
- STARTI [Basic] quand s'exécute le corps une fonction ? Back:  lorsqu'elle est appelée (uniquement)  <!--ID: 1730827064594--> ENDI
- STARTI [Basic] comment demande-t-on l'exécution d'une fonction ? Back:  Par un appel de fonction. Par exemple `f()`. <!--ID: 1730827064596--> ENDI
- STARTI [Basic] qu'est-ce qu'un appel de fonction ? Back:  Une demande d'exécution de la fonction. Par exemple `f()`. <!--ID: 1730827064599--> ENDI
- STARTI [Basic] comment appelle-t-on une fonction définie dans une classe ? Back:  une méthode (d'instance, de classe ou statique) <!--ID: 1730827064601--> ENDI
- STARTI [Basic] pourquoi dit-on que les fonctions sont des first-class objects ? Back:  les fonctions sont des objets comme les autres en python. Elles peuvent être assignées à des variables, passées en argument, renvoyées par d'autres fonctions. <!--ID: 1730827064606--> ENDI
- STARTI [Basic] `l = [0, 1]; print(l.pop(), l.pop())` ? Back:  `1 0`.  <!--ID: 1730827064609--> ENDI
- STARTI [Basic] pourquoi est-ce que `l = [0, 1]; print(l.pop(), l.pop())` affiche `1 0`.  ? Back:  Les expressions sont évaluées de gauche à droite. Le pop de gauche sort la dernière valeur introduite (ici `1`). Le pop de droite sort `0`.  <!--ID: 1730827064611--> ENDI



START
Basic
Comment est interprété un appel de fonction `func(expr1, expr2)` ?
Back: 
Python évalue les expressions des arguments de gauche à droite, puis associe ces valeurs aux paramètres avant d'exécuter la fonction.
<!--ID: 1730827064589-->
END
