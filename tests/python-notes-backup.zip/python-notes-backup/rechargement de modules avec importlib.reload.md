MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-08
***

***
TARGET DECK: Python
FILE TAGS: imports

- STARTI [Basic] Comment recharger un module importé avec l'instruction `import m` ? Back:  `importlib.reload(m)` <!--ID: 1731053653010--> ENDI
- STARTI [Basic] Dans quel cas est-il courant de recharger un module ? Back:  En développement interactif (debug, REPL) pour tester des modifications sans relancer le programme. <!--ID: 1731053653011--> ENDI
- STARTI [Basic] est-il nécessaire d'attendre la valeur de retour de `importlib.reload(m)` ? Back:  Non. Le module est mis à jour en place. Les références sont automatiquement mises à jour. <!--ID: 1731053653012--> ENDI
- STARTI [Basic] Quelles sont les limites de `importlib.reload(m)` ? Back: <br>- N'est pas récursif <br>- Ne met pas à jour les attributs importés via `from m import ...` <!--ID: 1731053653013--> ENDI
- STARTI [Basic] est-ce que `importlib.reload` recharge aussi les modules importés par `m` ? Back:  Non, le rechargement n'est pas récursif. <!--ID: 1731053653014--> ENDI

START
Basic
Comment lister les modules importés par un module `m` ?
Back:
```python
import m

for name, attr in vars(m).items():
    if isinstance(attr, type(m)):
        print(name)
```

Via `vars(m)` (aka `m.__dict__`) : 
![[rechargement de modules avec importlib.reload-1.png]]
<!--ID: 1731053653015-->
END


