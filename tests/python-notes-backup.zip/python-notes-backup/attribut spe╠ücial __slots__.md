MOC : [[SOFTWARE ENGINEERING]]
Source : https://wiki.python.org/moin/UsingSlots
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] Quel est l'effet de `__slots__` ? Back:  Double effet : <br>- réduit l'empreinte mémoire (`__dict__` n'est pas créé) <br>- limite les attributs aux noms listés dans `__slots__` <!--ID: 1730827064248--> ENDI
- STARTI [Basic] Est-ce qu'il faut lister les attributs `@property` dans `__slots__` ? Back:  Non, seuls les attributs qui sont normalement stockés dans `__dict__` sont à lister dans `__slots__` . <!--ID: 1730827064254--> ENDI

START
Basic
Est-il possible de modifier `__slots__` pendant l'exécution ?
Back:
Non. <br>Lier `__slots__` à une nouvelle valeur au runtime n'a pas d'effet.

```python
class A:
    __slots__ = ("x", "y")

    def __init__(self):
        self.x = 0
        self.y = 0
        self.z = 0


A.__slots__ = ("x", "y", "z")
print(A.__slots__)  # affiche ('x', 'y', 'z')
A() # lève AttributeError: 'A' object has no attribute 'z'
```
<!--ID: 1730827064256-->
END


START
Basic
Qu'affiche `print(A().x)` ?
```python
class A:
    __slots__ = ("x", "y")

    def __init__(self):
        self.x = 0
        self.y = 0
        self.z = 0
```
Back:
`AttributeError: 'A' object has no attribute 'z'`
<!--ID: 1734019137969-->
END


START
Basic
```python
class OptimizedRectangle(Rectangle):  
    __slots__ = {
        'width': 'rectangle width in pixels',
        'height': 'rectangle height in pixels'
    }
```
Que décrit ici `__slots__` ?
Back: 
Le nom et la docstring des attributs de OptimizedRectangle.
<!--ID: 1730827064246-->
END

