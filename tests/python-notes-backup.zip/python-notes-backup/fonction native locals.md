MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

***
TARGET DECK: Python
FILE TAGS: 

- https://docs.python.org/3/library/functions.html#locals
- STARTI [Basic] `locals()` ? Back:  le dictionnaire du namespace courant (en mode read-only) <!--ID: 1734678007460--> ENDI
- STARTI [Basic] le dictionnaire du namespace courant ? Back:  `locals()` ou `vars()` <!--ID: 1734678007461--> ENDI

