MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/lexical_analysis.html#logical-lines
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Notions de base du développement]]
Date : 2024-09-28
***

Une ligne logique est ce que python interprète comme a single statement.

Une ligne logique correspond en générale à une ligne physique : 
```python
deux = 1 + 1
```

Le backslash permet d'étaler une ligne logique sur plusieurs lignes physiques :
```python
trois = 1 \  
	+ 1 \  
	+ 1
```

De même `[]`, `()` et `"""` permettent d'avoir des lignes logiques sur plusieurs lignes physiques : 
```python
tic_tac_toe = [
	 ["O", "-", "X"],
	 ["O", "X", "-"],
	 ["X", "O", "-"],
]

chroniques = (
    ChroniquesBuilder()
    .with_line(serie="A")
    .with_line(serie="B")
    .build()
)

t = """un
texte sur
plusieurs
lignes
"""
```



***
TARGET DECK: Python
FILE TAGS: lexical-structure

START
Basic  
```python
player1 = "a"
tic_tac_toe = [
	 ["O", "-", "X"],
	 ["O", "X", "-"],
	 ["X", "O", "-"],
]
```
Combien de lignes logiques ?
Back:  2
END

START
Basic  
```python
chroniques = (
    ChroniquesBuilder()
    .with_line(serie="A")
    .with_line(serie="B")
    .build()
)
```
Combien de lignes logiques ?
Back:  1
END

START
Basic  
```python
t = """un
texte sur
plusieurs
lignes
"""
```
Combien de lignes logiques ?
Back:  1
END