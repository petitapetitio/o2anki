MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***


https://docs.python.org/3/library/functions.html#built-in-functions
https://realpython.com/python-built-in-functions/

- [[fonction native all]]
- [[fonction native any]]
- [[fonction native ascii]]
- [[fonction native bin]]
- [[fonction native chr]]
- [[fonction native ord]]
- [[fonction native input]]

- globals vs locals vs vars vs dirs
	- [[fonction native dir]] (TODO)
	- [[fonction native locals]]
	- [[fonction native globals]]
	- [[fonction native vars]]

- [[fonction native filter]]
- [[fonction native map]]
- [[fonction native print]]
- [[fonction native round]]
- [[fonction native sorted]]
- [[fonction native sum]]
- [[fonction native super]]
- [[fonction native zip]]
