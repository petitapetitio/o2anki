MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***

***
TARGET DECK: Python
FILE TAGS: exceptions

- STARTI [Basic] quel est l'intérêt de créer une exception personnalisée ? Back:  Permettre au code client de traiter ce cas d'erreur de façon spécifique grâce au filtrage par type. <!--ID: 1730972172960--> ENDI
- STARTI [Basic] quel est l'intérêt d'hériter d'une exception built-in ? Back: Un code qui gère l'exception parente pourra aussi gérer l'exception personnalisée. <!--ID: 1730972172958--> ENDI
- STARTI [Basic] Comment créer une exception personnalisée `EmptyStringError` qui hérite de `ValueError` ? Back:  `class EmptyStringError(ValueError): pass` <!--ID: 1730972172963--> ENDI
