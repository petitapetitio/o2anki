MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/zoneinfo.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- sur windows, may need `pip install tzdata`
- ZoneInfo implémente tzinfo (see bases)

```python
# Construire un datetime tz-aware : 
d = datetime.now(tz=ZoneInfo("Europe/Paris"))
naive_datetime.replace(tzinfo=ZoneInfo("UTC"))

# ZoneInfo hérite de tzinfo
type(ZoneInfo("Europe/Paris")).__mro__  # (<class 'zoneinfo.ZoneInfo'>, <class 'datetime.tzinfo'>, <class 'object'>)

# La liste des timezones disponibles
zoneinfo.available_timezones()
```

[[Toujours utiliser des dates tz-aware]]