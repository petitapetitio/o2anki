MOC : [[SOFTWARE ENGINEERING]]
Source : 
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2025-01-12
***

- "a lightweight [[process]]" 
- partage la mémoire avec d'autres threads, dans un single process
- quand ? Tasks that spend much of their time waiting for external events (comme le batch scrutator d'[[Ayoub El Khallioui]])

En python : 
- [[threading.Thread]]