MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-17
***

- lorsque le domaine est fini, connu à l'avance, avec assez peu d'elts

###### Exemple factice avec la fonction sin sur les entiers allant de 0 à 360
```python
import math  
  
sin_degree_lookup = {x: math.sin(math.radians(x)) for x in range(361)}  
sin_degree = sin_degree_lookup.get  
print(sin_degree(5))
```
