MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[HyperText Markup Language (HTML)]]
Date : 2025-01-19
***

Fonctionnalités courantes
- substituer des placeholders
- rendus conditionnels
- boucles
- formattage
