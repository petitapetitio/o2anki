MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-25
***

***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] quelle est la limite de profondeur de récursivité par défaut en python ? Back:  1000 <!--ID: 1730827064327--> ENDI
- STARTI [Basic] comment connaître la limite de récursivité dans un programme ? Back:  `sys.getrecursionlimit()` <!--ID: 1730827064329--> ENDI
- STARTI [Basic] est-ce que python implémente *tail-call optimization* ? Back:  Non <!--ID: 1730827064331--> ENDI

