MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/stdtypes.html#tuples
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***

Séquence immutable et ordonnée d'éléments - de type arbitraire et pouvant être différents.

***
TARGET DECK: Python
FILE TAGS: tuple

- STARTI [Basic] Qu'est-ce qu'un tuple ? Back: Une séquence immutable d'éléments de types arbitraires. (`tuple` implémente l'interface `Sequence`) <!--ID: 1728024344727--> ENDI
- STARTI [Basic]Quels problèmes posent le fait de mettre un objet mutable dans un tuple ? Back: 1) Cela peut entraîner de la confusion à la lecture du code : on s'attends à un objet immutable mais il ne l'est que de façon superficielle 2) Le tuple n'est plus hachable - et ne peut plus être utilisé comme clé de dictionnaire. Ex `{(1, []): 0}` lève `TypeError: unhashable type: 'list'` <!--ID: 1728024344730--> ENDI
- STARTI [Basic] Comment créer un tuple `t` composé de 1, 2 et 3 ? Back: `t = 1, 2, 3` <!--ID: 1728024344733--> ENDI
- STARTI [Basic] Comment créer un tuple vide ? Back:  `()` ou `tuple()` <!--ID: 1728024344737--> ENDI
- STARTI [Basic] Comment créer un tuple d'un seul élément `1` ? Back:  `1,`<br>Note : `tuple(1)` lève une `TypeError` car le constructeur attend un itérable. <!--ID: 1728024344741--> ENDI
- STARTI [Basic] Dans quels cas est-ce que les parenthèses sont nécessaires pour les tuples ? Back:  <br>- créer un tuple imbriqué (ex : `1, (2, 3)`) <br>- passer un tuple littéral en argument d'une fonction (ex : `f(True, (1, 2))`)  <!--ID: 1728024344745--> ENDI
- STARTI [Basic] Que donne `tuple('wow')` ? Back:  `('w', 'o', 'w')`. Lorsque `x` est itérable, `tuple(x)` renvoie un tuple dont les éléments sont les mêmes que ceux de `x`. <!--ID: 1728024344749--> ENDI
- STARTI [Basic] `type((1,0))` Back: `<class 'tuple'>` ! ([[gotcha]]) <!--ID: 1730827064128--> ENDI

