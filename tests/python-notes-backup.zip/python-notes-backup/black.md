
- autoformatter pour [[Python]]
- alternative : blue

```bash
black --line-length 120 .
```

Dans [[pyproject.toml]]
```
[tool.black]  
line-length = 120
```
