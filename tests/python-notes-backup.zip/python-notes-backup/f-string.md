MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/reference/lexical_analysis.html#f-strings
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

- qu'est-ce qu'une f-string ? une chaîne de caractère qui contient des "replacement fields"
- replacement fields syntax ? `{value[!conversion][:format-specifier]}` 
- [[Spécifications de format]]

***
TARGET DECK: Python
FILE TAGS: strings

- STARTI [Basic] Dans quelle version de python est-ce que les f-string ont été introduites ? Back: 3.6 <!--ID: 1727362138333--> ENDI
- STARTI [Basic] que signifie "f-string" ? Back: *formatted string literal* <!--ID: 1728024344788--> ENDI
- STARTI [Basic] comment se traduit `f'{x:<format_spec>}'` ? Back:  `x.format(format_spec)`  <br>(par un appel à [[Méthode spéciale __format__ et fonction native format]]) <!--ID: 1734713099775--> ENDI
- STARTI [Basic] afficher l'expression dans une f-string `f'{a*s}'` ? Back:  `f'{a*s=}'` <br>Donne `'a*s=5'`<br>([self-documented expression](https://docs.python.org/3/whatsnew/3.8.html#f-strings-support-for-self-documenting-expressions-and-debugging))<!--ID: 1734713099776--> ENDI
- STARTI [Basic] afficher le nom de la variable dans une f-string `f'{value}'` ? Back:  `f'{value=}'` (affiche `'value=5'`) <!--ID: 1734713099777--> ENDI


