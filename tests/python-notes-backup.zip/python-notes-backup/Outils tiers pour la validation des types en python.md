MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***

- [[mypy]]
- autres type checkers
	- MonkeyType (instagram)
	- pydantic
		- https://docs.pydantic.dev/latest/
		- data validation at runtime
	- Pylance 
	- Pyre (Facebook)
	- Pyright (Microsoft) - static
	- pytype (Google)
