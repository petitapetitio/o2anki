MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/compound_stmts.html#class-patterns
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***


***
TARGET DECK: Python
FILE TAGS: match

- STARTI [Basic] Quelle en-tête de clause permet de matcher n'importe que sujet de type `int` ? Back:  `case int():` <!--ID: 1728729591914--> ENDI
- STARTI [Basic] Quelle en-tête de clause de permet de matcher **et capturer** un sujet de type `int` ? Back:  `case int(x):` <!--ID: 1728729591918--> ENDI
- STARTI [Basic] Est-ce que l'en-tête de clause `case int():` match le sujet `True` ? Back:  Oui car le type bool est un sous-type de int ([[gotcha]]) <!--ID: 1728729591923--> ENDI
- STARTI [Basic] Est-ce que l'en-tête de clause  `case int():` match le sujet `5` ? Back:  Oui <!--ID: 1728729591928--> ENDI
- STARTI [Basic] Est-ce que l'en-tête de clause  `case int():` match le sujet `5.0` ? Back:  Non <!--ID: 1728729591933--> ENDI
- STARTI [Basic] Est-ce que l'en-tête de clause  `case int():` match le sujet `'a'` ? Back:  Non <!--ID: 1728729591938--> ENDI
- STARTI [Basic] Est-ce que l'en-tête de clause  `case float():` match le sujet `5` ? Back:  Non <!--ID: 1728729591942--> ENDI
- STARTI [Basic] Est-ce que l'en-tête de clause  `case float():` match le sujet `5.0` ? Back:  Oui <!--ID: 1728729591946--> ENDI
- STARTI [Basic] Quelle en-tête permet de matcher un sujet de type `list` dont le premier élément est `10` ? Back:  `case list([10, *_]):` <!--ID: 1728729591950--> ENDI

START
Basic
Dans un matching de classe, est-ce que les patterns positionnels peuvent être utilisés sur les classes définies par l'utilisateur ?
Back:
Oui, à condition de définir l'attribut `__match_args__` : 
```python
class Point:
    __match_args__ = ("_x", "_y")

    def __init__(self, x, y):
        self._x = x
        self._y = y


match Point(0, 0):
    case Point(0, _):
        print("OK")
```
<!--ID: 1728729591909-->
END



START
Basic
Comment matcher tout point qui est sur l'axe `x = 0` 
```python
class Point:
    def __init__(self, x, y):
        self._x = x
        self._y = y
```
?
Back: 
`case Point(_x=0):`

Notes : 
- le matching se fait sur les attributs (pas sur les paramètres du constructeur)
- les arguments positionnels requièrent de définir `__match_args__`
<!--ID: 1728729591905-->
END
