MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

- [[CPython]]
- [[PyPy]]

Implémentations émergentes / early stages
- Nuitka
- RustPython


***
TARGET DECK: Python

STARTI [Basic] Quelle est l'implémentation de référence de Python ? Back: CPython <!--ID: 1727542890094--> ENDI