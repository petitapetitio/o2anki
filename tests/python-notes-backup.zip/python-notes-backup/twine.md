MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-16
***

- job = uploader sur un repo comme [[PyPI]]
- s'installe avec `pip install twine`
- des discussions pour merger twine avec [[pip]] sont en cours
- alternatives : [[flit]]

Usage typique
```bash
python -m build --sdist --whell  # crée dist/
twine check dist/*  # vérifie les distributions
twine upload dist/*  # upload sur PyPI
```

Références :
- https://twine.readthedocs.io
- https://packaging.python.org/en/latest/key_projects/#twine

***
TARGET DECK: Python
FILE TAGS: packaging

- STARTI [Basic] qu'est-ce que twine ? Back: L'outil officiel pour uploader des [[package]] sur [[PyPI]] <!--ID: 1731749004776--> ENDI


