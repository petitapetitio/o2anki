MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Testing]], [[Fuzzing]], [[reproductibilité]]
Date : 2025-01-14
***

Cela rends les tests reproductible

```python
import random

random.seed(5)

print(random.random())  # 0.6229016948897019
print(random.random())  # 0.7417869892607294
print(random.random())  # 0.7951935655656966
```