MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/lexical_analysis.html#identifiers, https://docs.python.org/fr/3/reference/executionmodel.html#bind-names
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python|Python]]
Date : 2024-09-28
***

- nom utilisé pour spécifier un objet (variable, fonction, classe)
- en pratique
	- attention aux caractères normalizables
	- attention aux homoglyphes


***
TARGET DECK: Python
FILE TAGS: lexical-structure

- STARTI [Basic] Qu'est-ce qu'un identifiant ? Back: Un nom qui fait référence à un objet ([[variable]], [[attribut]], [[fonction]], [[classe]], [[module]]). <!--ID: 1727542890072--> ENDI
- STARTI [Basic] Par quoi doit commencer par identifiant ? Back: par une lettre ou par `_`. <!--ID: 1727542890074--> ENDI
- STARTI [Basic] Qu'affiche le programme `a = 1; A = 2; print(a)` ? Back: 1. Les identifiants sont sensibles à la casse. <!--ID: 1728036834580--> ENDI
- Quelle est la différence entre un identifiant et une variable ? Une variable est un type particulier d'identifiant : un identifiant auquel on a associé une valeur. (??)

