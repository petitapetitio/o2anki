MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/fr/3.13/library/typing.html#type-aliases
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-03
***

***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] à quoi sert l'annotation `TypeAlias` ? Back:  <br>1) expliciter qu'on définit un alias (`Id = int` → `Id: TypeAlias = int`) <br>2) faire une référence anticipée (`Node: TypeAlias = 'Tree'` ) <!--ID: 1730827063826--> ENDI
- STARTI [Basic] Comment déclarer que `Vector` est un alias pour `list[float]` ? Back:  <br>`type Vector = list[float]` (à partir de 3.12) <br>`Vector: TypeAlias = list[float]` <br><!--ID: 1730827063828--> ENDI
- STARTI [Basic] Quelle est la différence entre <br>`type Vector = list[float]` <br>et <br>`Vector: TypeAlias = list[float]` <br>? Back:  La syntaxe avec `type` est plus concise mais requiert Python 3.12+. <!--ID: 1730827063829--> ENDI
