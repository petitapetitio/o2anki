MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/fr/3.13/library/abc.html#abc.ABCMeta.__subclasshook__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-01
***

https://stackoverflow.com/questions/40764347/python-subclasscheck-subclasshook

***
TARGET DECK: Python
FILE TAGS: abc dunders

- STARTI [Basic] Comment procède `issubclass(X, C)` ? Back: <br>Si `C` est une `ABC` qui implémente `__subclasshook__`, python renvoie `C.__subclasshook__(X)`. <br>Sinon, Python vérifie l'héritage et `register`.  <!--ID: 1730827063997--> ENDI
- STARTI [Basic] quel est le cas d'usage typique de `__subclasshook__` ? Back: Vérifier qu'une classe implémente une interface, <br>- sans nécessiter d'héritage explicite <br>- sans nécessiter d'enregistrement via `register` <!--ID: 1730827064004--> ENDI

START
Basic
Où et comment implémenter `__subclasshook__` ?
Back:
Dans une `ABC`, comme méthode de classe :
```python
class A(abc.ABC):
    @classmethod
    def __subclasshook__(self, subclass):
        print(A.__name__, "__subclasshook__", subclass)
        return True


class B:
    ...


print(issubclass(B, A))
```
<!--ID: 1733561161869-->
END

START
Basic
`issubclass(B, A)` ?
```python
class A(abc.ABC):
    @classmethod
    def __subclasshook__(self, subclass):
        return False

class B(A):
    ...
```
Back:
`False`
`__subclasshook__` a priorité sur l'héritage. [[gotcha]]
<!--ID: 1733573726405-->
END

