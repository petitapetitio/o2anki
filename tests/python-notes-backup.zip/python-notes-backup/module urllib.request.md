MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-18
***

- https://docs.python.org/3/library/urllib.request.html
- https://docs.python.org/3/library/urllib.request.html#examples
- low-level interface - pour une interface plus haut niveau : [[requests (python)]] ou directement [[urllib3]]
