MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- 3rd party (`pip install python-dateutil`)

```python
from dateutil import parser

print(repr(parser.parse('Saturday, January 28, 2006, at 11:15pm')))
# datetime.datetime(2006, 1, 28, 23, 15)
```
