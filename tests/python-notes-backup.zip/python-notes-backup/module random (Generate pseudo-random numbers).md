MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/fr/3.13/library/random.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***


- gestion
	- initialiser le générateur de nombre pseudo-aléatoires ? `random.seed(5)`
- [[entier (int)]]
	- un entier aléatoire entre 0 et 10 ? `random.randrange(10)` ou `random.randint(0, 10)`
	- un entier aléatoire entre 4 et 8 inclus ? `random.randint(4, 8)`
- séquences
	- un élément aléatoire d'une séquence ? `random.choice([1, 2, 3, 4])`
	- mélanger `s = [1, 2, 3, 4]` en place ? `random.shuffle(s)`
	- un mélange de `s = (1, 2, 3, 4)` ? `random.sample(s, len(s))`
- [[Nombres à virgules flottantes (floats)]]
	- une valeur aléatoire entre 0 et 1.0 ? `random.random()`
	- une valeur aléatoire entre 5.0 et 7.0 ? `random.uniform(5., 7.)`
	- une valeur aléatoire sur une distribution gaussienne ? `random.gauss()`
