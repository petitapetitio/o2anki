MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Optimisation]], [[Clarté 🌟]]
Date : 2025-01-16
***

> First make it work. Then make it right. The make it fast - [[Kent Beck]]'s father


> Rules of optimization : Rule 1. Don't do it. Rule 2 (for experts only). Don't do it yet - that is, not until you have a perfectly clear and unoptimized solution.
> 
> Michael A. Jackson
> https://softwarequotes.com/quote/jackson-s-rules-of-optimization--rule-1--don-t-do-
