MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[sequence]], [[mapping]]
Date : 2024-10-31
***

***
TARGET DECK: Python
FILE TAGS: sequence dunders


- à quel moment est appelé `x.__getitem__` ? Lorsqu'on demande accès à un élément via `x[key]` ou `x[index]`
- STARTI [Basic] par quel appel de méthode spéciale se traduit `x["key"]` ? Back:  `x.__getitem__("key")` <!--ID: 1730827064072--> ENDI
- STARTI [Basic] par quel appel de méthode spéciale se traduit `x[5]` ? Back:  `x.__getitem__(5)` <!--ID: 1730827064075--> ENDI
- STARTI [Basic] que doit renvoyer `x.__getitem__(-4)` si `x` est une séquence de 10 éléments ? Back:  `x[6]` car `10 - 4 = 6`. Il est attendu que la méthode spéciale `__getitem__` reproduise le comportement des séquences natives <!--ID: 1730827064077--> ENDI
- STARTI [Basic] que doit renvoyer `x.__getitem__(index)` si `index` n'est pas du type attendu ? Back:  `TypeError` <!--ID: 1730827064079--> ENDI
- STARTI [Basic] que doit renvoyer `x.__getitem__(index)` si `index` est hors de portée (out of range) ? Back:  `IndexError` <!--ID: 1730827064081--> ENDI
- STARTI [Basic] que doit renvoyer `x.__getitem__(-5)` si `x` contient 3 éléments ? Back:  `IndexError` <!--ID: 1730827064083--> ENDI
- STARTI [Basic] que doit renvoyer `x.__getitem__(5)` si `x` contient 3 éléments ? Back:  `IndexError` <!--ID: 1730827064085--> ENDI
- STARTI [Basic] Quelle est la différence entre `__getitem__` pour une séquence et pour un mapping ? Back:  <br>Pour une séquence : attend un entier comme index et accède par position. <br>Pour un mapping : accepte n'importe quel type hashable comme clé et accède par clé <!--ID: 1730827064088--> ENDI



Une façon courante d'implémenter `__getitem__` : 
```python
def __getitem__(self, index):
	# Recursively special-case slicing 
	if isinstance(index, slice):
		return self.__class__(
		    self[x] for x in range(*index.indices(len(self)))
		)
	# Check index, and deal with a negative and/or out-of-bounds index
	index = operator.index(index) 
	if index < 0:
		index += len(self)
	if not (0 <= index < len(self)):
		raise IndexError
```
