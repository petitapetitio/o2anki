MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-24
***

***
TARGET DECK: Python
FILE TAGS: paramètres

- STARTI [Basic] quel caractère est le marqueur "positionnel-uniquement" ? Back:  `/` <!--ID: 1730827064557--> ENDI
- - STARTI [Basic] params : comment appelle-t-on le marqueur `/` ? Back: le marqueur positional-only (positionnel uniquement). <!--ID: 1734166731048--> ENDI
- STARTI [Basic] quel est l'effet du paramètre `/` ? Back: Force les arguments précédents à être positionnels. <!--ID: 1730827064562--> ENDI
- STARTI [Basic] dans quelle version de python est introduit le marqueur "positionnel-uniquement" ? Back:  3.8 <!--ID: 1730827064560--> ENDI
- STARTI [Basic] Comment faire en sorte que le fonction de signature `f(x, y)` n'accepte que des arguments positionnels ? Back:  Ajouter un marqueur positionnel-uniquement à la fin de la liste des paramètres `f(x, y, /)` <!--ID: 1730827064567--> ENDI
- STARTI [Basic] Etant donné la signature `int(x, /, base=10)`, que produit `int(x=10)` ? Back:  `TypeError` <br> `x` précède un marqueur "positionnel-uniquement" et ne peut être fourni que de façon positionnelle. <!--ID: 1730827064565--> ENDI
