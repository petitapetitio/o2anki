MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-04
***

Une référence est un lien qui pointe vers un objet en mémoire.

***
TARGET DECK: Python

- STARTI [Basic] Qu'est-ce qu'une référence ? Back:  Un lien qui pointe vers un objet en mémoire <!--ID: 1728036834541--> ENDI
- STARTI [Basic] Par quel intermédiaire accède-t-on aux objets ? Back:  Via des références  <!--ID: 1728036834544--> ENDI
- STARTI [Basic] Quels sont les moyens d'accéder à une référence ? Back: [[variable]], [[attribut]], [[sélection (subscription)]] <!--ID: 1728036834546--> ENDI
- STARTI [Basic] Une référence a-t-elle un type ? Back:  Non. Une référence n'a pas de type intrinsèque. Seul l'objet auquel elle renvoie a un type. <!--ID: 1728036834548--> ENDI

