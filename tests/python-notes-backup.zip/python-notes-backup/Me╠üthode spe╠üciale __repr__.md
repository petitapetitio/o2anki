MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/datamodel.html#object.__repr__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] quelle est la sortie attendu de `__repr__` ? Back:  Une chaîne de caractère telle que `eval(repr(x)) == x` (dans la mesure du possible). Guideline = make it as unambiguous as possible. Ex : `Point(5, 10)`. <!--ID: 1730827064466--> ENDI
- STARTI [Basic] quelle est le comportement par défaut de `__repr__` ? Back: `object.__repr__` fournit une représentation générique de l'objet (basée sur son identité). <!--ID: 1730827064464--> ENDI

START
Basic
quand est appelé `__repr__` ?
Back:
1. dans l'interpréteur interactif pour afficher le résultat d'une expression
2. dans les messages d'erreur
3. lors d'un appel à `repr(x)`
4. lors d'un appel à `str()` si `__str__` n'est pas défini par l'utilisateur
<!--ID: 1730827064462-->
END
