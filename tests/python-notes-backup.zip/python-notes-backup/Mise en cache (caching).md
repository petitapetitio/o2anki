MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2025-01-17
***

- Consiste à jouer sur le [[Compromis temps-mémoire (Time-memory tradeoff)]]
- Problèmes : 
	- unbounded cache may grow indefinitely → [[Cache eviction policy]]
	- attention au cache avec les [[Nombres à virgules flottantes (floats)]] (utiliser `isclose` pour la comparaison)