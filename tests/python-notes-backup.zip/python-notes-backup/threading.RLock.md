MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- reentrant lock
- keep track of the owning thread
- can only be unlucked by the owning thread


###### enable recursive calls 👇
```python
lock = threading.RLock()
global_state = []
def recursive_function(some, args):
    with lock: # acquires lock, guarantees release at end
        # ...modify global_state...
        if more_changes_needed(global_state):
            recursive_function(other, args)
```
