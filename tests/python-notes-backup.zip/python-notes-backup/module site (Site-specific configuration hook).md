MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- https://docs.python.org/3/library/site.html
- hook exécuté au lancement
- peut être passé avec l'option `-S` 
- site's main task : put sys.path in standard form (abs, dedup, include env, .pth)
- créer `sitecustomize.py` et ne pas écraser `site.py`
