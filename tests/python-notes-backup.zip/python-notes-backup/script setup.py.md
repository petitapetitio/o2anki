MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-16
***

- ==legacy==
- est exécuté avec l'une des commandes listée dans `python /tmp/setup.py --help-commands`. 
- le cas le plus commun = `python setup.py install`
- configuration
	- le setup peut être configuré avec 
		- des paramètres en ligne de commande
		- depuis un fichier `setup.cfg`
		- depuis [[pyproject.toml]]
	- les métadonnées recommandées sont données ici : https://packaging.python.org/en/latest/specifications/core-metadata/
- PB : contient à la fois les spécifications et l'exécution
