MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- case d'usage : limiter l'accès à une ressource (pas + de 5 personnes simultanées dans la pièce)
- un [[threading.Lock]] correspond +/- un `Semaphore(1)`
