MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-05
***

***
TARGET DECK: Python
FILE TAGS: opérateurs

- STARTI [Basic] Qu'est-ce qu'un opérateur court-circuit ? Back:  Un opérateur qui évalue la seconde partie de l'expression uniquement si nécessaire.  <!--ID: 1728239137739--> ENDI
- STARTI [Basic] En quoi est-ce que `and` est un short-circuit operator ? Back:  L'opérande de droite n'est évaluée que si l'opérande de gauche est "vraie" - car il n'est pas nécessaire de connaître sa valeur pour déterminer la valeur de l'ensemble. <!--ID: 1728239137743--> ENDI
- STARTI [Basic] En quoi est-ce que `or` est un short-circuit operator ? Back:  L'opérande de droite n'est pas évaluée si l'opérande de gauche est "vraie" - car il n'est pas nécessaire de connaître sa valeur pour déterminer la valeur de l'ensemble. <!--ID: 1728239137749--> ENDI

START
Basic  
```python
x = 0
def f():
    global x
    x += 1

y = f() if False else None
```
Que vaut `x` ?
Back: `0` car `if/else` est un short-circuiting operator et l'expression `f()` n'est ici pas évaluée.
END 
