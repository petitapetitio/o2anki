MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2025-01-19
***

- eXtensible Markup Language
- concepts normalisés par le [[World Wide Web Consortium (W3C)]] : 
	- namespaces
	- XPath
	- Schema
- samples :
	- http://www.w3schools.com/xml/simple.xml
	- https://www.w3schools.com/xml/xml_examples.asp

En Python : 
- [[module xml]]
- [[lxml - XML and HTML with Python]]