
- Que signifie lier en Python ? Associer un nom à un objet dans un [[namespace]]. Ex : `x = 1` lie le nom `x` à l'objet `1` (def approx de Claude)