MOC : [[SOFTWARE ENGINEERING]]
Source : [[Zen of Python]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Simplicité]], [[Complexité]]
Date : 2024-11-27
***


