
Concepts
- "tables"

[PEP 518](https://www.python.org/dev/peps/pep-0518/) defines `pyproject.toml` as a configuration file to store build system requirements for Python projects. With the help of tools like [Poetry](https://python-poetry.org/), [Flit](https://flit.readthedocs.io/en/latest/), or [Hatch](https://hatch.pypa.io/latest/) it can fully replace the need for `setup.py` and `setup.cfg` files.

Peut être installé dans un `venv` :
```
python -m venv .venv
source .venv/bin/activate
pip install --index-url https://si-devops-mirror.edf.fr/repository/pypi.python.org/simple .
```

### Liens

- Comme expliqué dans [ce thread stackoverflow](https://stackoverflow.com/questions/74508024/is-requirements-txt-still-needed-when-using-pyproject-toml),  la règle est de ne pas préciser les versions des dépendances dans le pyproject.toml afin de permettre à la personne qui installe de résoudre les versions. Il est d'usage que les versions soient "fixées" dans le [[Requirements.txt]] 