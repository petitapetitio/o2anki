MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

- CTRL+D (unix)
- CTRL+Z (windows)

***
TARGET DECK: Python

STARTI [Basic] Comment taper un EOF sur Windows Back: CTRL+Z <!--ID: 1727542890140--> ENDI
STARTI [Basic] Comment taper un EOF sur Unix Back: CTRL+D <!--ID: 1727542890142--> ENDI