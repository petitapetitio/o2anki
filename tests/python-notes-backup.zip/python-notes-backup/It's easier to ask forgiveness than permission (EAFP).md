MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***

Image
- ?  (est-ce que ce fil est électifié ? ah, oui.)

***
TARGET DECK: Python
FILE TAGS: exceptions

- STARTI [Basic] Que signifie EAFP ? Back:  It's easier to ask forgiveness than permission <!--ID: 1730972172935--> ENDI
- STARTI [Basic] De qui est la citation "It's easier to ask forgiveness than permission" (EAFP) ? Back:  [[Grace Hopper]] <!--ID: 1730972172937--> ENDI
- STARTI [Basic] Quel style est préféré en Python entre EAFP et LBYL ? Back:  EAFP <!--ID: 1730972172940--> ENDI
- STARTI [Basic] En quoi consiste le style EAFP ? Back:  Placer l'opération risquée dans un `try` et gérer les exceptions dans des clauses `except`. <!--ID: 1730972172942--> ENDI
- STARTI [Basic] Quelle est la différence structurelle entre EAFP et [[Look before you leap (LBYL)]] ? Back:  EAFP place le cas principal en premier. LBYL le *"cache"* après les vérifications. <!--ID: 1730972172945--> ENDI

```python
try:
    valeur = int(input())
except ValueError:
    valeur = 0
```

START
Basic
Quel est le piège principal du style EAFP ?
Back: Capturer une exception trop large et masquer une erreur non prévue. Ex :
```python
try:
    valeur = int(input())
except Exception:  # Masque toutes les erreurs ! Préférer ValueError
    valeur = 0
```
<!--ID: 1730972172932-->
END
