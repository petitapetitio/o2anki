https://docs.sqlalchemy.org/en/20/index.html

Engine
```python
# Créer un engine sqlite
url = "sqlite:///data/test.sql"

# Créer un engine postgres
url = "postgresql://{user}:{password}@{host}:{port}/{db_name}".format(  
    user=self.user,  
    password=self.password,  
    host=self.host,  
    port=self.port,  
    db_name=self.db_name,  
)
create_engine(url)

```