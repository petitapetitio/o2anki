MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-28
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] quelles sont les différences entre une méthode de classe et une méthode ordinaire ? Back: Une méthode de classe s'appelle directement sur la classe et reçoit la classe plutôt que l'instance en premier paramètre.  <!--ID: 1730827064527--> ENDI
- STARTI [Basic] quel problème de lecture pose la déclaration de méthode de classe classique `def f(cls): ...; f = classmethod(f)` ? Back:  On ne comprends que dans un second temps que `f` sera une méthode de classe. Un intérêt du décorateur est qu'il rend cette intention explicite dès la déclaration. <!--ID: 1730827064529--> ENDI

START
Basic
Comment créer une méthode de classe sans le décorateur @classmethod ?
Back:
```python
class A:
    def f(cls): ...
    f = classmethod(f)
```
<!--ID: 1730827064520-->
END


START
Basic
Comment créer une méthode de classe avec le décorateur @classmethod ?
Back:
```python
class A:
    @classmethod
    def f(cls): ...
```
<!--ID: 1730827064522-->
END


START
Basic
Qu'affiche `A.f()` ?
```python
class Base:  
    @classmethod
    def f(cls):
        print(cls.__name__)

class A(Base): 
    pass
```
Back: 
`A` (et pas `Base` !!)
<!--ID: 1730827064525-->
END
