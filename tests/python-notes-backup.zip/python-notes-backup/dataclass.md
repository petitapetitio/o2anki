MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/dataclasses.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-01
***


***
TARGET DECK: Python
FILE TAGS: dataclass

- STARTI [Basic] Dans quelle version de Python ont été introduites les dataclasses ? Back:  3.7 <!--ID: 1730827063904--> ENDI
- STARTI [Basic] Pourquoi les dataclasses ont-elles été introduites ? Back: Simplifier l'écriture de classes en générant le code répétitif (et en alternative à NamedTuple et attrs) <!--ID: 1730827063909--> ENDI
- STARTI [Basic] Quelles méthodes spéciales ajoute automatiquement le décorateur @dataclass ? Back:  <br>`__init__` <br>`__repr__` <br>`__eq__` <br>(et `__hash__` lorsque `frozen=True`) <!--ID: 1730827063911--> ENDI
- STARTI [Basic] dataclass : quels sont les intérêts de `frozen=True` ? Back: <br>1) rendre l'instance immutable <br>2) rendre l'instance hashable <!--ID: 1730827063914--> ENDI
- STARTI [Basic] En quoi les dataclasses sont adaptées pour créer des Value Objects ? Back:  Avec `frozen=True`, elles fournissent l'immutabilité et la comparaison par valeur. <!--ID: 1730827063918--> ENDI


- Comment optimiser les `dataclass` ? 
	- Mettre `slots` à `True` permet de gagner un peu de mémoire sur chaque instance. 
- Principales composantes
	- `field` function
	- `__post_init__`
	- `asdict` : renvoie un dictionnaire des champs de la classe
	- `astuple`


> RQ : toute les classes sont faite pour stocker des données. à priori le nom "dataclass" est hérité des noms utilisés dans la bibliothèque attrs.


Comment créer un variable d'instance dans une dataclass ? Grâce à l'annotation [[ClassVar]] : 
```python
@dataclass(frozen=True)
class DateElaboration:
    value: str
    _regex: ClassVar[re.Pattern] = re.compile(r"^\d\d\d\d-\d\d-\d\d [A-Z_\.]*$")
```


START
Basic
Quelles sont les raisons d'utiliser une [[dataclass]] plutôt qu'un [[namedtuple]] ?
Back: 
1. Type-safety : la comparaison de [[namedtuple]]/[[NamedTuple (typed)]] regarde uniquement les champs et ne vérifie pas le type :  `Point2D(1, 10) == (1, 10)`
2. Mutabilité : il n'est pas possible de rendre un `namedtuple` mutable
3. Héritage : les `namedtuple` ne permettent pas d'ajouter des champs dans une classe fille
4. Flexibilité : plus d'options de personnalisation (post-init, champs calculés, etc.)

```python
from collections import namedtuple

Point2D = namedtuple('Point2D', ['x', 'y'])

class Point3D(Point2D):
    z: float  # N'a aucun effet


Point3D(0, 0, 0) # TypeError: Point2D.__new__() takes 3 positional arguments but 4 were given
Point3D(0, 0).z  # AttributeError: 'Point3D' object has no attribute 'z'
```
https://peps.python.org/pep-0557/#why-not-just-use-namedtuple
<!--ID: 1730827064259-->
END
