MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***



### 2024-11-28 14:06 - Post

Tout est objet en python.

Vraiment, tout. 👇

Les types primitifs sont des objets
`type(42)` renvoie `<class 'int'>`

Les fonctions sont des objets
`type(f)` renvoie `<class 'function'>`

Les classes sont des objets
`type(A)` renvoie `<class 'type'>`

Les modules sont des objets
`type(sys)` renvoie `<class 'module'>`

Même `None` est un objet 
`type(None)` renvoie `<class 'NoneType'>`


Comme le dit le Zen de Python : 
Special cases aren't special enough to break the rules.

Ici, la règle est que tout est objet.

La conséquence est que ces éléments : 
- peuvent être passés dans des appels de fonction
- peuvent être assignés à des variables
- fournissent des méthodes
- ont des attributs

Plutôt pratique non ?

PS : l'image est issue de ce post : https://www.reddit.com/r/Python/comments/hrvxrd/python_in_a_nutshell_had_to_do_it/?rdt=64730


