MOC : [[SOFTWARE ENGINEERING]]
Source : https://virtualenv.pypa.io/en/latest/
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-15
***

- est + complet et efficace que [[venv]]
- `brew install pipx`,  `pipx install virtualenv` `
- `virtualenv [-p /path/to/python] /path/to/new/virtual/environment`
- `source venv/bin/activate`
- `. venv/Scripts/activate` (sur Windows)

***
TARGET DECK: Python
FILE TAGS: venvs

- STARTI [Basic] quand est apparu virtualenv ? Back:  en 2007 (5 ans avant [[venv]]) <!--ID: 1731677487727--> ENDI
- STARTI [Basic] qui est l'auteur original de `virtualenv` ? Back:  [[Ian Bicking]] <!--ID: 1731677487728--> ENDI
- STARTI [Basic] qui maintient `virtualenv` ? Back:  [[Python Packaging Authority (PyPA)]] <!--ID: 1731677487729--> ENDI
- STARTI [Basic] quel sont les deux intérêts de `virtualenv` par rapport à `venv` ? Back:  <br>Support de Python 2. <br>Fonctionnalités plus avancées. <!--ID: 1731677487730--> ENDI
- STARTI [Basic] quelles sont les options principales spécifiques à `virtualenv` ? Back:  <br>`--python` : expliciter le chemin vers l'interpréteur Python<br>`--relocatable` : rendre l'environnement déplaçable<br>`--system-site-packages` : donner accès aux packages système<br>`--prompt` : personnaliser le prompt <!--ID: 1731677487731--> ENDI

