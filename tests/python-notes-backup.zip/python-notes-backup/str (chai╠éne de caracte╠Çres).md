MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/stdtypes.html#textseq
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***

- séquence de caractères 
- est utilisé pour stocker de l'information textuelle
- est immutable
- [[f-string]]


***
TARGET DECK: Python
FILE TAGS: str strings


- STARTI [Basic] Quelles sont les deux littéraux qui créent la chaîne de caractère *hello* ? Back: `'hello'` ou `"hello"` <!--ID: 1728024344681--> ENDI
- STARTI [Basic] Comment insérer une tabulation dans une chaîne de caractères ? Back: `\t` <!--ID: 1728024344685--> ENDI
- STARTI [Basic] Que fait le backslash dans une chaîne de caractère ? Back: Il démarre une *escape sequence* <!--ID: 1728024344689--> ENDI
- STARTI [Basic] Que produit `print("hello \a")` ? Back: affiche `hello ` dans la console et joue un son de cloche. <!--ID: 1728024344693--> ENDI 
- STARTI [Basic] Que produit `print(r"hello \a")` ? Back: affiche `hello \a` dans la console. (r produit une *raw* string) <!--ID: 1728024344697--> ENDI 
- STARTI [Basic] Que donne `r'\a'` ? Back: `'\\a'` (`r` crée un littéral brute en échappant les backslash)  <!--ID: 1728024344701--> ENDI 
- STARTI [Basic] Qu'affiche `print("\N{Copyright Sign}")` ? Back: le symbole copyright `©` à partir de son nom unicode <!--ID: 1728024344704--> ENDI
- STARTI [Basic] Comment saisir un caractère spécial à partir de son nom unicode ? Back: `'\N{nom-unicode}'` <!--ID: 1728024344706--> ENDI
- STARTI [Basic] Qu'affiche `print("\u00A9")` ? Back: le symbole copyright `©` à partir de son code unicode UTF-8 <!--ID: 1728024344710--> ENDI 
- STARTI [Basic] Comment saisir un caractère spécial à partir de son code unicode UTF-8 ? Back: `'\uXXXX'` <!--ID: 1728024344715--> ENDI
- STARTI [Basic] Qu'affiche `print("\U000000A9")` ?  Back: le symbole copyright `©` à partir de son code unicode UTF-16 <!--ID: 1728024344719--> ENDI
- STARTI [Basic] Comment saisir un caractère spécial à partir de son code unicode UTF-16 ? Back: `'\UXXXXXXXX'` <!--ID: 1728024344723--> ENDI


START
Basic  
Comment éviter d'avoir la première ligne d'une chaîne de caractère triple-quoted à un niveau d'indentation différent des autres lignes ?
Back:
Mettre un anti-slash juste après l'ouverture :
```python
game = """\
X--
0X-
00X
"""
```
END

START
Basic
Quel est le seul caractère qui doit être échappé dans une chaîne de caractère triple-quoted ?
Back:  
Le backslash.
```python
x = """\  
it's ok to have "quotes"  
in the middle of a triple-quoted string 
but \\ should be escaped
"""
```
`print(x)` affiche
```
it's ok to have "quotes"
in the middle of a triple-quoted string
but \ should be escaped
```

START
Basic  
Comment est évaluée l'expression 
```python
(
    "👉"
    "👈"
)
```
Back: `"👉👈"` : les chaînes de caractères littérales adjacentes sont concaténées par le compilateur
<!--ID: 1734713099725-->
END

START
Basic
Comment est évaluée l'expression 
```python
"hello" "world"
```
Back: `"helloworld"` : les chaînes de caractères littérales adjacentes sont concaténées par le compilateur
<!--ID: 1734713099726-->
END

START
Basic
Quelles sont les deux façons de saisir une chaîne de caractère sur plusieurs lignes ?
Back:  
Insérer des retours à la ligne : 

```python
"ligne1\nligne2"
```
ou utiliser les triples quotes : 
```python
"""\
ligne1
ligne2
"""
```
<!--ID: 1734713099727-->
END

## Méthodes

- capitalize
	- STARTI [Basic]  `'abc' -> 'Abc'` ? Back:  `'abc'.capitalize()` <!--ID: 1734713099728--> ENDI
	- STARTI [Basic]  `'abc'.capitalize()` ? Back:  `'Abc'` <!--ID: 1734713099729--> ENDI
- casefold
	- STARTI [Basic]  `'ß'.casefold()` ? Back:  `'ss'` (tandis que `'ß'.lower()` → `'ß'`) <!--ID: 1734713099730--> ENDI
	- STARTI [Basic]  quelle fonction utiliser pour comparer deux textes qui contiennent plus que des caractères ASCII de façon non sensible à la casse ? Back:  Préférer `s.casefold()` à `s.lower()` <!--ID: 1734713099731--> ENDI
- center
	- STARTI [Basic]  `'x' → '__x__'` ? Back:  `'x'.center(5, '_')` <!--ID: 1734713099732--> ENDI
	- STARTI [Basic]  `'x'.center(5, '_')` ? Back:  `'__x__'` <!--ID: 1734713099733--> ENDI
	- STARTI [Basic]  `'x'.center(4, '_')` ? Back:  `'_x__'` <!--ID: 1734713099734--> ENDI
- count
	- STARTI [Basic]  le nombre de `'ab'` dans `'abracadabra'` ? Back:  `'abracadabra'.count('ab')` <!--ID: 1734713099735--> ENDI
- decode
- encode
	- STARTI [Basic]  `'hello' → b'hello'` ? Back:  `'hello'.encode("ascii")` ou `bytes("hello", encoding="ascii")` <!--ID: 1734713099736--> ENDI
- endswith
	- STARTI [Basic]  `s` termine par `"et eurent beaucoup d'enfants."` ? Back:  `s.endswith("et eurent beaucoup d'enfants.")` <!--ID: 1734713099737--> ENDI
- find
	- STARTI [Basic]  la position de `'soleil'` dans `s` ? Back:  `s.find('soleil')` <!--ID: 1734713099738--> ENDI
	- STARTI [Basic]  `"le soleil".find('soleil')` ? Back:  `3` <!--ID: 1734713099739--> ENDI
	- STARTI [Basic]  `"Rouen".find('soleil')` ? Back:  `-1` <!--ID: 1734713099740--> ENDI
- index
	- STARTI [Basic]  `"le soleil".index('soleil')` ? Back:  `3` <!--ID: 1734713099741--> ENDI
	- STARTI [Basic]  `"Rouen".index('soleil')` ? Back:  `ValueError: substring not found` <!--ID: 1734713099742--> ENDI
- isalnum
	- STARTI [Basic]  `''.isalnum()` ? Back:  `False` ([[gotcha]]) <!--ID: 1734713099743--> ENDI
	- STARTI [Basic]  `'Hey!'.isalnum()` ? Back:  `False` <!--ID: 1734713099744--> ENDI
- isdecimal
	- STARTI [Basic]  `isdecimal('1')` ? Back:  `True` <!--ID: 1734713099745--> ENDI
	- STARTI [Basic]  `isdecimal('①')` ? Back:  `False` <!--ID: 1734713099746--> ENDI
	- STARTI [Basic]  `isdecimal('½')` ? Back:  `False` <!--ID: 1734713099747--> ENDI
- isdigit
	- STARTI [Basic]  `isdigit('1')` ? Back:  `True` <!--ID: 1734713099748--> ENDI
	- STARTI [Basic]  `isdigit('①')` ? Back:  `True` <!--ID: 1734713099749--> ENDI
	- STARTI [Basic]  `isdigit('½')` ? Back:  `False` <!--ID: 1734713099750--> ENDI
- isnumeric
	- STARTI [Basic]  `isnumeric('1')` ? Back:  `True` <!--ID: 1734713099751--> ENDI
	- STARTI [Basic]  `isnumeric('①')` ? Back:  `True` <!--ID: 1734713099752--> ENDI
	- STARTI [Basic]  `isnumeric('½')` ? Back:  `True` <!--ID: 1734713099753--> ENDI
	- STARTI [Basic]  `isnumeric('1.0')` ? Back:  `False` ([[gotcha]]) <!--ID: 1734713099754--> ENDI
	- STARTI [Basic]  `isnumeric('1/2')` ? Back:  `False` ([[gotcha]]) <!--ID: 1734713099755--> ENDI
	- STARTI [Basic]  `isnumeric('ⅩⅣ')` ? Back:  `True` (**ssi** les [caractères romains](https://fr.wikipedia.org/wiki/Table_des_caract%C3%A8res_Unicode/U2150) sont utilisés !!) <!--ID: 1734713099756--> ENDI
- isidentifier
	- STARTI [Basic]  `'s'` est un nom de variable valide ? Back:  `s.isidentifier()` <!--ID: 1734713099757--> ENDI
	- STARTI [Basic]  `'_value'.isidentifier()` ? Back:  Oui <!--ID: 1734713099758--> ENDI
	- STARTI [Basic]  `'12apps'.isidentifier()` ? Back:  Non <!--ID: 1734713099759--> ENDI
- islower
	- STARTI [Basic]  `'s'` est en minuscule ? Back:  `s.islower()` <!--ID: 1734713099760--> ENDI
	- STARTI [Basic]  `'É'.lower()` ? Back:  `'é'` <!--ID: 1734713099761--> ENDI
- join
	- STARTI [Basic]  `['1', '2', '3', 'soleil !'] → '1, 2, 3, soleil !'` ? Back:   `', '.join(['1', '2', '3', 'soleil !'])` <!--ID: 1734713099762--> ENDI
- ljust / rjust
	- STARTI [Basic]  `'ab' →  'ab:::'` ? Back:  `'ab'.ljust(5, ':')` <!--ID: 1734713099763--> ENDI
	- STARTI [Basic]  `'ab'.ljust(3, ':')` ? Back:  `'ab:'` <!--ID: 1734713099764--> ENDI
- lower
	- STARTI [Basic]  `'ABC' → 'abc'` (2 façons) ? Back:  `'ABC'.lower()` ou `'ABC'.swapcase()` <!--ID: 1734713099765--> ENDI
- strip / lstrip / rstrip
	- STARTI [Basic]  `'ABCDCBA' → 'CDC'` ? Back:  `'ABCDCBA'.strip('AB')` <!--ID: 1734713099766--> ENDI
	- STARTI [Basic]  `'  x  ' → 'x'` ? Back:  `'  x  '.strip()` <!--ID: 1734713099767--> ENDI
	- STARTI [Basic]  `'  x  ' → 'x  '` ? Back:  `'  x  '.lstrip()` <!--ID: 1734713099768--> ENDI
	- STARTI [Basic]  `'  x  ' → '  x'` ? Back:  `'  x  '.rstrip()` <!--ID: 1734713099769--> ENDI
- replace
	- STARTI [Basic]  `'<><<>><>' → 'O<O>O'` ? Back:   `'<><<>><>'.replace('<>', 'O')` <!--ID: 1734713099770--> ENDI
- split
	- STARTI [Basic]  `'a|b|c' → ['a', 'b', 'c']` ? Back:  `'a|b|c'.split('|')` <!--ID: 1734713099771--> ENDI
	- STARTI [Basic]  `'a|b|c' → ['a', 'b|c']` ? Back:  `'a|b|c'.split('|', maxsplit=1)` <!--ID: 1734713099772--> ENDI
- splitlines
	- STARTI [Basic]  `' 1\n 2\n' → [' 1\n', ' 2\n']`  ? Back:  `' 1\n 2\n'.splitlines(keepends=True)` <!--ID: 1734713099773--> ENDI
- upper
	- STARTI [Basic]  `'abc' → 'ABC'` (2 façons) ? Back:  `'abc'.upper()` ou `'abc'.swapcase()` <!--ID: 1734713099774--> ENDI

