
![[The 21 principles of Dokkōdō]]