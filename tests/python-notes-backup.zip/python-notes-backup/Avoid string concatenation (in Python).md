MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-17
***

- Python strings are immutable. String concatenation `s1 += s2` involves freeing `s1` and allocating a new string of size `len(s1) + len(s2)`. Cela a un impact désastreux dans une boucle. 

###### Dans une boucle
```python
from io import StringIO

# ❌
s = ""
for x in collection:
    s += x

# ✅
strings = []
for x in collection:
    strings.append(x)
s = ''.join(strings)

# ✅
b = StringIO()
for x in collection:
    b.write(x)
b.seek(0)
s = b.read()
```

##### Dans une interpolation
```python
# ❌ (very slow)
str(x) + ' eggs and ' + str(y) + ' slices of ' + k + ' ham'  

# ✅ (fast)
'{} eggs and {} slices of {} ham'.format(x, y, k)  

# ✅ (faster)
f'{x} eggs and {y} slices of {k} ham'
```
![[Python in a Nutshell-4.png]]
