MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-31
***

***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] par quel appel de méthode spéciale se traduit `elts[key] = e` ? Back:  `elts.__setitem__(key, e)` <!--ID: 1730827064021--> ENDI
- STARTI [Basic] à quel moment est appelé `elts.__setitem__(key, e)` ? Back:  Lors d'une assignation via la syntaxe `elts[key] = e` <!--ID: 1730827064023--> ENDI
- STARTI [Basic] Quelle exception `__setitem__` doit-il lever si la clé/index n'est pas du type attendu ? Back:  `TypeError` <!--ID: 1730827064025--> ENDI
- STARTI [Basic] Quelle exception `__setitem__` doit-il lever si l'index est hors limites pour une séquence ? Back: `IndexError` <!--ID: 1730827064027--> ENDI
- STARTI [Basic] Quelle est la différence d'utilisation de `__setitem__` entre une [[sequence]] et un [[mapping]] ? Back:  <br>séquence : attend un entier ou une tranche comme index. <br>mapping : attend une valeur hashable comme clé<!--ID: 1730827064029--> ENDI
