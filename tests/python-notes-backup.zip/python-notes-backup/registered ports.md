MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-18
***

- numéros allant de 1024 à 49151
- assignés par l'[[Internet Assigned Numbers Authority (IANA)]]
