MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/compound_stmts.html#while
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Instructions de boucle]]
Date : 2024-10-12
***


***
TARGET DECK: Python
FILE TAGS: while

- STARTI [Basic] Qu'est-ce qu'une instruction `while` ? Back: une instruction qui répète l'exécution d'un bloc d'instructions tant qu'une condition est vraie. <!--ID: 1728749077512--> ENDI
- Comment se déroule `while condition: statements` ? Back: La condition est testée et avant chaque itération et la boucle continue tant que la condition est vraie. 



START
Basic
Quelle est la syntaxe d'une instruction while ?
Back: 
```python
while expression:
    statements
```
<!--ID: 1728749077493-->
END

START
Basic
Comment appelle-t-on cette expression ?
![[2024-09-28 Python in a nutshell-3.png]]
Back: 
La condition de boucle (loop condition)
<!--ID: 1728749077501-->
END

START
Basic
Comment appelle-t-on ce bloc d'instructions ?
![[3 RESSOURCES/The developer's brain/Notes/Python/_assets/2024-09-28 Python in a nutshell-2.png]]
Back: 
Le corps de boucle (loop body)
<!--ID: 1728749077506-->
END
