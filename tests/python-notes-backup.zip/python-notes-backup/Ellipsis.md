MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/library/constants.html#Ellipsis, https://realpython.com/python-ellipsis/
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python|Python]]
Date : 2024-10-04
***


Cas d'usage
- comme `pass`
- lever contrainte sur annotation
- [[tranchage (slicing)]] ?

***
TARGET DECK: Python
FILE TAGS: Ellipsis

- STARTI [Basic] Qu'est-ce que l'objet `...` ? Back: `Ellipsis`. Une constante built-in. <!--ID: 1728024344571--> ENDI
- STARTI [Basic] Que désigne le type hint `Callable[..., int]` ? Back: Toute fonction qui renvoie un `int`. Ellipsis permet ici de lever les restrictions sur les paramètres. <!--ID: 1728024344575--> ENDI
- STARTI [Basic] Que désigne le type hint `tuple[int, ...]` ? Back: Un tuple homogène d'entiers. OK : `t=(); t=(1,); t=(1, 2, 3)`. KO : `t=(1, "a"); t=[1, 3]`. <!--ID: 1728024344579--> ENDI
- STARTI [Basic] Comment typer un tuple homogène d'entiers ? Back: `tuple[int, ...]` <!--ID: 1729447957738--> ENDI
- STARTI [Basic] `dict.fromkeys(['A', ...], 0)` ? Back: `{'A': 0, Ellipsis: 0}`. Ellipsis est hachable et peut être utilisé comme clé. <!--ID: 1728024344582--> ENDI
