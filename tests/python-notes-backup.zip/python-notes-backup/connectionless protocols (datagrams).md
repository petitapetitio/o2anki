MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[COMPUTER NETWORKS]]
Date : 2025-01-18
***

- fonctionnent comme envoyer des cartes postales
	- tu n'es pas sur que le message a été délivré
	- l'ordre des messages n'est pas garanti
	- en général un aller-retour (question / réponse)
- intérêt
	- overhead réduit par rapport aux [[connection-oriented protocols]]
- ex : 
	- [[Domain Name System (DNS)]] communications (most)
	- [[User Data Protocol (UDP)]]


![[Connectionless protocols-1.png]]