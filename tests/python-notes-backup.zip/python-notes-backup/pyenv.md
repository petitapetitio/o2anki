MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

- pyenv facilite l'installation de versions conjointes

Méthode de résolution de la version:
1. `PYENV_VERSION` (si set)
2. fichier `.pyenv_version` du dossier courant (définit avec `pyenv local`)
3. premier fichier `.pyenv_version` trouvé en remontant les dossiers
4. fichier `version` (définit avec `pyenv global`)

Commandes utiles :
```
# Lister les versions disponibles
pyenv install -l

# Installer une version
pyenv install 3.10.4

# Changer de version 
pyenv global 3.10.4

# Lister les versions installées
pyenv versions
```

## Ressources 

- https://github.com/pyenv/pyenv
- https://blog.stephane-robert.info/docs/developper/programmation/python/pyenv/


***
TARGET DECK: Python
FILE TAGS: 

- STARTI [Basic] pyenv : installer 3.10.4 ? Back:  `pyenv install 3.10.4` <!--ID: 1734767204418--> ENDI
- STARTI [Basic] pyenv : les versions disponibles ? Back:  `pyenv install -l` <!--ID: 1734767204419--> ENDI
- STARTI [Basic] pyenv : les versions installées ? Back:  `pyenv versions` <!--ID: 1734767204420--> ENDI

