MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[COMPUTER NETWORKS]]
Date : 2025-01-18
***

- fonctionnent comme des appels téléphoniques
	- demande de connection à un endpoint particulier (n° de téléphone)
	- la personne décide de "décrocher" ou pas
	- à la fin de la conversation, chacun se dit au-revoir - aussi on sait si quelque chose se passe mal entre temps
- ex : [[Transmission Control Protocol (TCP)]]
- idéales pour
	- mail exchanges
	- command-line shell interactions
	- transmission de contenu web
