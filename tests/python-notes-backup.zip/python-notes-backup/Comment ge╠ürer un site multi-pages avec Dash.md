

depuis 2.5, dash a introduit un mécanisme de "Page"

avant cela, on utilisait
```
# approche 1
dcc.Location(id="url", refresh=True), avec une callback

# approche 2
dash.register_page(__name__, path='/')
```