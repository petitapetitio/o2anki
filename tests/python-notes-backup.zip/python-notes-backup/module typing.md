MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-05
***

- Quelles sont les catégories principales du module typing ?
	- des types spéciaux (Any, NoReturn, ...)
	- des constructeurs de types (Union, Callable, Generic, TypeVar)
	- des types dépréciés (`List`, `Dict`, ...)
	- des directives spéciales (NamedTuple, Protocol)
	- des protocoles (SupportsAbs...)
	- des fonctions utilitaires (cast, overload, ...)
	- des décorateurs (@type_check_only, @final...)
	- des constantes (TYPE_CHECKING, ...)

***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] typing : comment indiquer que `x` peut être de n'importe quel type ? Back:  `x: Any` <!--ID: 1730827063697--> ENDI
- STARTI [Basic] comment typer la variable `f` qui référence une fonction qui prends exactement deux arguments entiers et ne renvoie rien ? Back:  `Callable[[int, int], None]` <!--ID: 1730827063699--> ENDI
- STARTI [Basic] comment typer la variable `f` qui référence une fonction qui ne prends aucun argument et renvoie un flottant ? Back:  `Callable[[], float]` <!--ID: 1730827063702--> ENDI
- STARTI [Basic] comment annoter un argument qui doit être un littéral entier parmi 1, 2, 4 ? Back:  `Literal[1, 2, 4]` <!--ID: 1730827063704--> ENDI
- STARTI [Basic] Comment annoter une fonction ne termine jamais ? Back:  `f() -> NoReturn`. Ex : `def error(msg: str) -> NoReturn: raise Exception(msg)` <!--ID: 1730827063706--> ENDI
- STARTI [Basic] Comment annoter qu'un argument chaîne de caractères doit être fourni de façon littérale afin d'éviter les attaques par injection ? Back:  `f(arg: LiteralString)`. <!--ID: 1730827063709--> ENDI
- STARTI [Basic] à quoi correspond l'annotation `IO`  ? Back:  <br>`BinaryIO` pour les fichiers binaires (ouverts en mode `rb`) ou <br>`TextIO` pour les fichiers textes (ouverts en mode `r`) <!--ID: 1730827063712--> ENDI
- STARTI [Basic] Quelles classes du module typing sont dépréciées depuis 3.9 ? Back: Les classes représentant  : <br>1) les types built-ins (`List`, `Dict`, `Set`)  <br>2) les classes de base de `collections.abc` (`Iterable`, `Iterator`, ...), sauf `Hashable` et `Sized` <!--ID: 1730827063714--> ENDI
- STARTI [Basic] comment annoter `d` comme un dictionnaire ? Back:  `d: dict` (`d: Dict` avant 3.9) <!--ID: 1730827063719--> ENDI

- [[Protocols (Classes)]]
- [[ClassVar]]
- [[conversion de valeur en type avec cast]]
- [[typage avec @final et Final]]
- [[TYPE_CHECKING]]
- [[Overloading]]
- [[Generic]] et [[TypeVar]]
- [[NamedTuple (typed)]]
- [[TypedDict]]
- [[Alias de type (TypeAlias)]]
- [[NewType]]
- [[pyi stub files]]
