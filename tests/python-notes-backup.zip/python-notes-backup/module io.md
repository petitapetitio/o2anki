MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/io.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

##### fonction native open
- https://docs.python.org/3/library/functions.html#open
- paramètres
	- encoding, errors : pour les fichiers binaires ouverts en mode texte
	- buffering : à chaque write, à chaque ligne, tous les `n` bytes
- recipes
	- ouvrir un fichier en lecture en mode texte ? `with open("file.txt") as f:`
	- ouvrir un fichier en mode éditable ? `with open("file.txt", "r+") as f:`
	- créer un nouveau fichier en mode lecture/écriture ? `with open("file.txt", "w+") as f:` 


##### Hierarchie de classes du module io 
- https://docs.python.org/3/library/io.html#class-hierarchy

```mermaid
classDiagram
IOBase <|-- RawIOBase
IOBase <|-- BufferedIOBase
IOBase <|-- TextIOBase
RawIOBase <|-- FileIO
TextIOBase <|-- TextIOWrapper
TextIOBase <|-- StringIO
BufferedIOBase <|-- BytesIO
```


```python
f = open("file.txt", "rb")  # Exemple de FileIO
f = BytesIO()               # Exemple de BytesIO
f = open("file.txt", "r")   # Exemple de TextIOWrapper
f = StringIO()              # Exemple de StringIO
```


##### Lien avec les protocols du [[module typing]]

- ne pas confondre `io.BytesIO` avec `typing.BinaryIO`
- ne pas confondre `io.StringIO`avec `typing.TextIO` 

`typing.TextIO` permet d'annoter mais `StringIO` et `TextIOWrapper` : 
```python
def f(value: typing.TextIO): ...  
f(open("file.txt")) # ok pour le typechecker
f(StringIO()) # ok pour le type checker
```
mais ils ne sont pas liés par une relation d'héritage
```python
isinstance(open("file.txt"), typing.TextIO) # False
isinstance(StringIO(), typing.TextIO) # False
```
