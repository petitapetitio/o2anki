MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-16
***


***
TARGET DECK: Python
FILE TAGS: packaging

- STARTI [Basic] quels sont les avantages des built distributions ? Back: Elles sont rapide à installer et l'utilisateur n'a pas besoin d'avoir un compilateur configuré. <!--ID: 1731749004777--> ENDI
- STARTI [Basic] quel est le format d'une built distribution ? Back: [[wheel (.whl)]] <!--ID: 1731749004779--> ENDI
- STARTI [Basic] comment inspecter le contenu d'une wheel ? Back:  <br>`unzip -l package.whl` (lister)<br>`unzip package.whl` (extraire)  <!--ID: 1731749004780--> ENDI
- STARTI [Basic] quelle est la différence entre built distribution et source distribution ? Back:  La built est déjà compilée et est prête à installer. <!--ID: 1731749004781--> ENDI

