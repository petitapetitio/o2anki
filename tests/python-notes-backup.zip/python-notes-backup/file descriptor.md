MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

- an integer that the operating system uses as an opaque handle to refer to an open file
- comment se matérialise un file descriptor ? un entier 
- créer un objet fichier à partir d'un descripteur ? `os.fdopen(fd)` (du [[module os]])
- le *file descriptor* d'un objet fichier `f` ? `f.fileno()`

> On Unix-like and Windows platforms, some file descriptors are preallocated when a process starts: - 0 is the file descriptor for the process’s standard input
> - 1 for the process’s standard output, and 
> - 2 for the process’s standard error.
