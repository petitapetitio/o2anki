MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/weakref.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Garbage collection]]
Date : 2025-01-12
***

- qu'est-ce qu'une référence faible (weak reference) ? a special object w that refers to some other object x without incrementing x’s reference count
- dans quel cas est-ce utile ? élément d'une liste qui référence sont conteneur, afin d'éviter les [[mutual reference loop (cyclic garbage collections)]]


```python
import sys
import weakref

class A:
    ...

x = A()
y = weakref.ref(x)

print(sys.getrefcount(x) - 1)      # 1 (x est la seule référence, y n'est pas compté)
print(weakref.getweakrefcount(x))  # 1 (y est la seule weak ref)
print(weakref.getweakrefs(x))      # [<weakref at 0x1042409a0; to 'A' at 0x104296cc0>]

```

Le module fournit aussi des "collections faibles" dont les éléments disparaissent lorsque leur refcount tombe à zéro.
```python
import weakref  
  
class A: 
   pass  
  
a = A()  
s = weakref.WeakSet([a])  

print(s)  # {<weakref at 0x100f49800; to 'A' at 0x100f162d0>}
del a  
print(s)  # set() (un ensemble vide !)
```
