MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

***
TARGET DECK: Python
FILE TAGS: 


- https://docs.python.org/3/library/functions.html#globals
- STARTI [Basic] `globals()` ? Back:  le dictionnaire du module courant <!--ID: 1734678007458--> ENDI
- STARTI [Basic] le dictionnaire du module courant ? Back:  `globals()` <!--ID: 1734678007459--> ENDI

