MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/typing.html#typing.NamedTuple
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-03
***


***
TARGET DECK: Python
FILE TAGS: typing collections

- STARTI [Basic] Quelle est la différence entre `NamedTuple` et `namedtuple` ? Back: `NamedTuple` est une version typée de [[namedtuple]] <!--ID: 1730827063781--> ENDI
- STARTI [Basic] Que renvoie `isinstance(Point2D(), tuple))` si `Point` hérite de `NamedTuple` ? Back: `True` <!--ID: 1730827063784--> ENDI

START
Basic
Comment créer un `NamedTuple` nommé `Point` avec deux attributs entier `x` et `y` nuls par défaut ?
Back: 
```python
class Point(NamedTuple):
    x: int = 0
    y: int = 0
```
<!--ID: 1730827063772-->
END

START
Basic
Comment redéfinir `Point` avec `NamedTuple` (et des coordonnées entières) 
```python
Point = namedtuple('Point', ['x', 'y'], defaults=(0, 0))
```
?
Back:
```python
class Point(NamedTuple):
    x: int = 0
    y: int = 0
```
<!--ID: 1730827063776-->
END
