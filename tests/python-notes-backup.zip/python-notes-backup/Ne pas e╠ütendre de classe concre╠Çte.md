MOC : [[SOFTWARE ENGINEERING]], [[2 CASQUETTES/Tamis/Tamis/RESSOURCES/Software Engineering/Software Design|Software Design]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-01
***

Source
- http://www.billharlan.com/papers/Avoid_extending_classes.html
- Arthur J. Riel argued in his 1996 book "Object-oriented Design Heuristics"

Rule of thumb : si tu es tenté d'en faire hériter une de l'autre, fait remonter ce qu'elles ont en commun dans une classe abstraite

Permet d'éviter bon nombre des pièges de l'héritage
