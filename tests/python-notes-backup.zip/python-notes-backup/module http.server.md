MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-22
***

- ok pour des développement locaux
- single-threadé par défaut
- pas sécurisé, limité, ne pas utiliser en prod
