MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/stdtypes.html#bytes-objects
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***

- séquence immutable d'entiers allant de 0 à 255
- peut être initialisé à partir d'une chaîne de caractères : `b'abc'`
- peut être initialisé à partir d'une liste d'entiers : `bytes([97, 98, 99])`
- les objets bytes sont représentés sous forme de chaîne de caractère : `repr(bytes([97, 98, 99]))` == `"b'abc'"`
- un objet bytes peut être initialisé à partir d'une chaîne de caractères brute `rb'\ = abc'`
- comment convertir `b'abc'` en `'abc'` ? `b'abc'.decode()'


***
TARGET DECK: Python
FILE TAGS: bytes

- STARTI [Basic] Qu'est-ce qu'un objet de type `bytes`? Back: une séquence immutable d'entiers allant de 0 à 255 (ie d'octets) <!--ID: 1728024344764--> ENDI
- STARTI [Basic] Comment initialiser un objet `bytes` de façon littérale ? Back: `b'abc'` (`bytes([97, 98, 99])` n'est pas une approche littérale car elle fait appel au constructeur `bytes`) <!--ID: 1728024344768--> ENDI
- STARTI [Basic] Comment initialiser un objet `bytes` à partir d'entiers ? Back: `bytes([97, 98, 99])` <!--ID: 1728024344772--> ENDI
- STARTI [Basic] `repr(bytes([97, 98, 99]))` ? Back: `"b'abc'"`. Les `bytes` sont représentés sous la forme de chaînes de caractère ASCII <!--ID: 1728024344776--> ENDI
- STARTI [Basic] Comment convertir un objet de type bytes `b'abc'` en son équivalent ASCII `str` ? Back: `b'abc'.decode()` <!--ID: 1728024344779--> ENDI
- STARTI [Basic] `type(b'abc')` Back: `<class 'bytes'>` <!--ID: 1730827064266--> ENDI