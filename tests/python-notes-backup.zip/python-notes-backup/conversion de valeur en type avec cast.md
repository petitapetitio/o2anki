MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/typing.html#typing.cast
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-04
***

***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] typing : à quoi sert `x = cast(float, x)` ? Back:  Signaler au type checker que `x` est un flottant, sans impacter l'exécution.<!--ID: 1730827063722--> ENDI
- STARTI [Basic] typing : quand utiliser `cast` ? Back:  Quand le type checker ne peut pas déduire le bon type mais que tu sais qu'il est correct <!--ID: 1730827063725--> ENDI
- STARTI [Basic] typing : que fait  `x = cast(float, x)` au runtime ? Back:  rien <!--ID: 1730827063728--> ENDI
- STARTI [Basic] Quelle différence entre `x = cast(float, x)` et `x = float(x)` ? Back: `cast` renvoie la valeur inchangée. <!--ID: 1733378568819--> ENDI
