MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[argument]]
Date : 2024-10-24
***


***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] Qu'est-ce qu'un argument positionnel ? Back:  un argument associé à un paramètre par sa position. <!--ID: 1729754352024--> ENDI
- STARTI [Basic] Est-ce qu'un argument nommé peut précéder un argument positionnel ? Back:  Non. Les arguments positionnels sont placés en premiers puis suivis de zéro ou plusieurs arguments nommés. <!--ID: 1729754352026--> ENDI
- STARTI [Basic] De quel type est l'argument `0` dans `f(0, y=1)` ? Back:  Positionnel (il est passé sans spécification du nom du paramètre) <!--ID: 1729754352027--> ENDI
- STARTI [Basic] Quelles sont les deux façons de donner des arguments positionnel ? Back:  <br> 1) Au début de la liste des arguments : `f(1, True, c="C")`<br> 2) Via `*iterable` : `f(*[1, True], c="C")` <!--ID: 1729754352029--> ENDI
