MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-24
***

***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] de quoi est composé l'espace de nom local d'une fonction ? Back: des paramètres et des noms définis localement (via assignation, ou via instruction `def`, `class`) <!--ID: 1729754351997--> ENDI
- STARTI [Basic] qu'est-ce qu'une variable locale ? Back: une variable qui n'est accessible que dans l'espace de nom où elle est définie (module, classe ou fonction) <!--ID: 1732776513900--> ENDI

START
Basic
Qu'affiche `f(1)`
```python
x = 0
def f(x):
    print(x)
```
?
Back:
`1` (le paramètre `x` **masque** la variable globale `x`)
<!--ID: 1729754351995-->
END


![[Espace de nom des fonctions-1.png]]