MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***

***
TARGET DECK: Python
FILE TAGS: loop

- STARTI [Basic] Que fait l'instruction `continue` ? Back: <br>1) elle met fin à l'itération en cours et <br>2) elle passe à l'itération suivante. <!--ID: 1728749077254--> ENDI
- STARTI [Basic] En cas de boucles imbriquées, à quelle instruction de boucle s'applique l'instruction `continue` ? Back:  À la première boucle parente de l'instruction `continue`. <!--ID: 1728749077262--> ENDI
- STARTI [Basic] Où peut-on utiliser l'instruction `continue` ? Back:  Dans le corps d'une boucle ([[instruction for]], [[instruction while]]) <!--ID: 1728749077265--> ENDI

START
Basic
Qu'affiche 
```python
for i in [0, 1, 2, 3, 4]:  
	if i % 2 == 0:  
		continue  
	print(i)
```
?
Back:
```
1
3
```
<!--ID: 1728749077250-->
END

DELETE
ID : 1728749077256