MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]], https://docs.python.org/3/library/stdtypes.html#boolean-type-bool
Tags : [[Python]]
Date : 2024-10-04
***


***
TARGET DECK: Python
FILE TAGS: stdtypes


- STARTI [Basic] Quelles sont les deux constantes booléennes ? Back:  `True`, `False` <!--ID: 1728024344542--> ENDI
- STARTI [Basic] `isinstance(True, int)` ? Back:  `True`. Le type build-in `bool` est une sous-classe de `int`. <!--ID: 1728024344548--> ENDI
- STARTI [Basic] `True + True` ? Back:  `2`. Le type build-in `bool` est une sous-classe de `int`. ([[gotcha]]) <!--ID: 1728024344552--> ENDI
- STARTI [Basic] Comment compter le nombre d'items "vrais" dans une séquence ? Back:  `sum(bool(x) for x in seq)` <!--ID: 1728024344556--> ENDI