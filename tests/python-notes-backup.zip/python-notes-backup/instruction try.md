MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-05
***

***
TARGET DECK: Python
FILE TAGS: exceptions

instruction try
- [[instruction composée (compound statements)]]
- STARTI [Basic] quelles sont les clauses d'une instruction `try` ? Back: `try`,  `except`, `else`, `finally` <!--ID: 1730827063642--> ENDI

clause except
- STARTI [Basic] comment appelle-t-on le corps d'une clause `except` ? Back:   un gestionnaire d'exception (exception handler) <!--ID: 1730827063645--> ENDI
- STARTI [Basic] quelle clause `except` pour intercepter une division par zéro ? Back:  `except ZeroDivisionError: ...`  <!--ID: 1730827063648--> ENDI
- STARTI [Basic] Pourquoi ordonner les except du plus spécifique au plus général ? Back:  Car seul le premier `except` matché est exécuté. Par exemple, `except Exception` avant `except ValueError` ne capturera jamais ValueError <!--ID: 1730827063651--> ENDI
- STARTI [Basic] Qu'intercepte une clause `except` sans expression ? Back:  Toute exception <!--ID: 1730827063654--> ENDI

START
Basic
Quel est le risque principal d'un except sans expression ?
Back:
Qu'il intercepte les interruptions système (KeyboardInterrupt, SystemExit) et empêche l'arrêt du programme. 

Ex : 
```python
while True:
    try:
        ...
    except:  # dangereux : Ctrl+C ne fonctionnera pas
        pass
```
<!--ID: 1730827063656-->
END
- STARTI [Basic] Quelle alternative sûre au 'bare except' ? Back:  `except Exception:` qui n'intercepte pas les interruptions système <!--ID: 1730827063659--> ENDI
- STARTI [Basic] Est-ce que `except Exception` intercepte `KeyboardInterrupt` et `SystemExit` ? Back:  Non <!--ID: 1730827063662--> ENDI
- STARTI [Basic] Comment intercepter plusieurs types d'exceptions dans une même clause `except` ? Back:  En les groupant avec des parenthèses : `except (ValueError, TypeError):` <!--ID: 1730827063664--> ENDI
- STARTI [Basic] Comment capturer l'objet exception dans un `except` ? Back:  Avec `as` : `except ValueError as e:` <!--ID: 1730827063669--> ENDI

clause else
- STARTI [Basic] try: quand s'exécute la clause `else` ? Back:  Lorsque la clause `try` termine normalement et sans exception <!--ID: 1730827063672--> ENDI
- STARTI [Basic] try: qu'est-ce qui empêche l'exécution de la clause `else` ? Back:  <br>- Une exception<br>- Un `break`/`continue` (dans une boucle) <br>- Un `return` (dans une fonction)<!--ID: 1730827063675--> ENDI
- STARTI [Basic] try: quel est l'intérêt d'utiliser `else` plutôt que de placer le code après l'instruction ? Back:  Le code dans `else` n'est exécuté que si aucune exception n'est levée, alors que le code après `try` est toujours exécuté. <!--ID: 1730827063677--> ENDI

clause finally
- STARTI [Basic] Comment appelle-t-on le corps d'une clause `finally` ? Back:  Un gestionnaire de nettoyage (cleanup handler) 🧹 <!--ID: 1730827063679--> ENDI
- STARTI [Basic] try : quand s'exécute le bloc `finally` ? Back: En dernier et dans tous les cas, après `try`, `except` et `else` <!--ID: 1730827063691--> ENDI
- STARTI [Basic] En cas d'exception dans la clause `try`, est-ce que l'exception est propagée s'il y a un `finally` ? Back: Oui, le `finally` s'exécute puis l'exception continue sa propagation. <!--ID: 1730827063684--> ENDI
- STARTI [Basic] En cas d'instruction `break`, `continue` ou `return` dans la clause `try`, est-ce que le corps de la clause `finally` est exécutée ? Back:  Oui <!--ID: 1730827063686--> ENDI
- STARTI [Basic] Quelle syntaxe moderne remplace try/finally pour la gestion des ressources ? Back:  L'instruction `with` avec les context managers. Ex : `with open(file)` <!--ID: 1730827063689--> ENDI


START
Basic
Que renvoie 
```python
try:
    return 'try'
finally:
    return 'finally'
```
?
Back:
'finally'. Un return dans `finally` remplace silencieusement tout return précédent. ([[gotcha]])
👉 pourrait devenir un syntax warning : https://peps.python.org/pep-0765/
👉 [[$A - return -- finally]]
<!--ID: 1730827063637-->
END

START
Basic
Quand préférer `finally` à une [[instruction with]] ?
Back:
Pour des nettoyages qui ne concernent pas des ressources comme réinitialisation d'état global :
```python
try:
    MY_GLOBAL = 'temporaire'
    ...
finally:
    MY_GLOBAL = 'initial'  # nettoyage d'état
```
<!--ID: 1730827063694-->
END


START
Basic
A quoi correspond cette [[instruction with]] en termes de try/finally 
```python
with open(path) as f:
    do_something(f)
```
?
Back:
```python
f = open(path)
try:
    do_something(f)
finally:
    f.close()
```
<!--ID: 1730827063640-->
END


DELETE
ID : 1730827063682