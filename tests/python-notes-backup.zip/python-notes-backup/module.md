MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/fr/3.13/glossary.html#term-module
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

Un module est un fichier que tu peux importer pour fournir des fonctionnalités.

Par exemple le fichier `utils.py` avec le contenu suivant : 
```python
def is_palindrome(x: str) -> bool:
    for i in range(len(x) // 2):
        if x[i] != x[-(i + 1)]:
            return False
    return True
```

***
TARGET DECK: Python
FILE TAGS: programs

- STARTI [Basic] Qu'est-ce qu'un module (dans le cas général) ? Back: un [[fichier .py]] qui contient du code réutilisable (variables, fonctions, classes) <!--ID: 1730972172840--> ENDI
- STARTI [Basic] Est-ce que tous les fichiers `.py` sont des modules ? Back:  Oui <br>Tout fichier `.py` peut être importé, y compris le point d'entrée (même si cet import récursif n'est pas recommandé) <!--ID: 1730972172843--> ENDI
- STARTI [Basic] Est-ce que les modules python sont forcément des fichiers .py ? Back:  Non. Un module peut être un fichier source (.py), compilé (.pyc), d'extension (C/C++), ou créé en mémoire de façon dynamique. <!--ID: 1730972172846--> ENDI





#### Corps d'un module

- STARTI [Basic] À quel moment s'exécute le corps d'un module ? Back: Au moment où il est importé pour la première fois <!--ID: 1730972172849--> ENDI
- STARTI [Basic] L'objet module est-t-il créé avant ou après que le corps du module soit exécuté ? Back:  Avant.  <!--ID: 1730972172852--> ENDI
- STARTI [Basic] À quel moment sont créés les modules, fonctions, et classes ? Back: <br>Module et fonction : avant l'exécution de leur corps <br>Classe : après l'exécution de son corps <!--ID: 1730972172854--> ENDI
- STARTI [Basic] Quel est le rôle du corps d'un module ? Back: Définir ses attributs :<br>- des fonctions avec des [[instruction def]] <br>- des classes avec des [[instruction class]] <br>- des variables globales. <br>en évitant toute autre forme de logique d'exécution. <!--ID: 1730972172857--> ENDI
- STARTI [Basic] Quel problème pose de mettre de la logique d'exécution dans le corps d'un module ? Back:  <br>1) Il est inattendu qu'un import ait des effets de bord <br>2) Il est difficile de contrôler quand ce code sera exécuté.  <!--ID: 1730972172859--> ENDI

#### Attributs d'un objets module




- STARTI [Basic] Comment accéder au dict d'un module depuis son corps ? Back: `locals()` ![[module-1.png]]<!--ID: 1734513825836--> ENDI
- STARTI [Basic] A quoi équivaut `mymodule.x = 1` ? Back:  `mymodule.__dict__['x'] = 1` <!--ID: 1730972172867--> ENDI
- STARTI [Basic] Que produit `mymodule.__dict__ = 0` ? Back:  Une AttributeError : `__dict__` est en lecture seule <!--ID: 1730972172870--> ENDI
- STARTI [Basic] Comment ajouter une docstring à un module ? Back:  Placer une chaîne de caractère en première instruction du module. Ex : `"""Ce module fait..."""` <!--ID: 1730972172872--> ENDI
- STARTI [Basic] Quel est le risque à utiliser un attribut privé (commençant par \_) d'un module tiers ? Back:  Il risque de disparaître dans une prochaine release car il ne fait pas partie de l'interface publique. <!--ID: 1730972172875--> ENDI

START
Basic
Comment créer un attribut de module de façon lazy ?
Back: Utiliser une fonction `__getattr__` au niveau du module. Elle fonctionnera comme la [[Méthode spéciale __getattr__]]. Par exemple
```python
def __getattr__(name):
    if name == "first_million_primes":

        def generate_n_primes(n): 
            ...

        import sys        
        this_module = sys.modules[__name__] # get the current module object
        this_module.first_million_primes = generate_n_primes(1_000_000)
        return this_module.first_million_primes

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
```
([[tricks]])
<!--ID: 1730972172834-->
END

