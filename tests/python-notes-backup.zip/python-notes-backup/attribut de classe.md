MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] qu'est-ce qu'un attribut de classe ? Back: Un attribut qui est défini au niveau du corps de la classe et partagé entre toutes les instances. <!--ID: 1730827064287--> ENDI
- STARTI [Basic] Comment faire référence à un attribut de classe dans le corps de la classe ? Back:  un nom simple suffit <br>(pas besoin de [[nom qualifié]]) <br>Ex : <br>![[attribut de classe-2.png]] <br><!--ID: 1730827064289--> ENDI
- STARTI [Basic] Comment faire référence à un attribut de classe dans une méthode ? Back: Passer par un [[nom qualifié]] : <br> `C.x` | `self.x` <br> Ex : <br>![[attribut de classe-3.png]] <br><!--ID: 1730827064291--> ENDI
- STARTI [Basic] quelle est la différence entre `C.x` et `self.x` ? Back:  <br>- `C.x` accède directement à l'attribut de classe <br>- `self.x` cherche d'abord dans les attributs de l'instance. <!--ID: 1730827064294--> ENDI

START
Basic
`print(B.x)` ?

```python
class A:
    x = 'x'

class B(A):
    ...
```
Back:
`x`
Les attributs de classe sont accessibles depuis les classes filles.
<!--ID: 1733727626214-->
END