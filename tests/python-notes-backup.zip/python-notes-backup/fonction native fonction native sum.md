MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/functions.html#sum
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***

***
TARGET DECK: Python
FILE TAGS: std-functions

- STARTI [Basic] `sum([1, 2])` ? Back:  3 <!--ID: 1728627767406--> ENDI
- STARTI [Basic] `sum([true, false, true])` ? Back:  `2`.  <!--ID: 1728627767409--> ENDI
- STARTI [Basic] `sum(1, 2, 3)` ? Back:  `TypeError`. `sum` attend un itérable en premier argument. Contrairement aux [[fonctions natives min et max]], `sum` n'accepte pas que les valeurs soient passées comme arguments positionnels ([[gotcha]]) <!--ID: 1728627767413--> ENDI
