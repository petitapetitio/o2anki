MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/fr/3/tutorial/classes.html#
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-26
***

Une classe est comme un concept : elle agit comme de centre de gravité. Elles agrègent la connaissance métier dans un même endroit. Plutôt que de penser "1 classe = 1 responsabilité", je préfère penser "1 classe = 1 concept"

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] Qu'est-ce qu'une classe ? Back:  un type défini par l'utilisateur.  <!--ID: 1730827064696--> ENDI
- STARTI [Basic] Qu'est-ce qu'instancier une classe ? Back: construire un objet de ce type (une instance) <!--ID: 1730827064697--> ENDI
- STARTI [Basic] Comment nomme-t-on un appel de classe ? Back: Une instanciation <!--ID: 1730827064699--> ENDI
- STARTI [Basic] Que renvoie une instanciation ? Back: Une instance <!--ID: 1730827064701--> ENDI
- STARTI [Basic] Qu'est-ce que le type d'un objet ? Back: Sa classe <!--ID: 1730827064702--> ENDI
- STARTI [Basic] Une classe peut-elle être placée dans une liste ? Back:  Oui, les classes sont des objets ordinaires en python. On dit que les classes sont des [[first-class objects]]. <!--ID: 1730827064704--> ENDI
- STARTI [Basic] que dit-on d'une classe `JsonStorage` dont la classe de base est `Storage` ? Back: qu'elle hérite, étend, dérive ou "subclass" `Storage` <!--ID: 1730827064706--> ENDI
- STARTI [Basic] quels sont les synonymes de base-class ? Back:  super-class, parent class <!--ID: 1730827064708--> ENDI
- STARTI [Basic] à quoi sert l'[[instruction class]] ? Back: créer un type personnalisé <!--ID: 1730827064710--> ENDI
- STARTI [Basic] `issubclass(C, C)` ? Back: `True`. Toute classe est une sous-classe d'elle-même. <!--ID: 1730827064712--> ENDI

