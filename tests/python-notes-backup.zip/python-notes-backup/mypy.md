MOC : [[SOFTWARE ENGINEERING]]
Source : https://mypy-lang.org/about.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

- standalone
- "my version of python"
- plug-in dispo pour Vim, Emacs, PyCharm, VS Code IDEs
- doc : https://mypy.readthedocs.io/en/stable/running_mypy.html
- cheat sheet : https://mypy.readthedocs.io/en/stable/cheat_sheet_py3.html

***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] Qu'est-ce que mypy ? Back: Un vérificateur de type. Il analyse les annotations pour détecter les erreurs de type sans exécuter le code. (On parle aussi de static type checker.)  <!--ID: 1730827064162--> ENDI
- STARTI [Basic] Quelles sont les figures derrière Mypy ? Back:  [[Jukka Lehtosalo]], [[Guido van Rossum]] et plusieurs développeurs de Dropbox <!--ID: 1730827064164--> ENDI
- STARTI [Basic] En quelle année est-ce que [[Jukka Lehtosalo]] a commencé à travailler sur mypy Back: 2012 <!--ID: 1730827064168--> ENDI
- STARTI [Basic] Comment Mypy indiquait-il les types avant le module typing ? Back: Via des commentaires spéciaux. ex : `x = [] # type: List[int]` <!--ID: 1730827064172--> ENDI


