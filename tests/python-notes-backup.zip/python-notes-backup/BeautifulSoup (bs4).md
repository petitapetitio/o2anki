MOC : [[SOFTWARE ENGINEERING]]
Source : https://pypi.org/project/beautifulsoup4/
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-19
***

- depuis 2004
- créé par [[Leonard Richardson]]
- pour parser et générer des documents HTML
- construit sur [[lxml - XML and HTML with Python]] et [[html5lib]]

Utilisation
- parsing
	- supporte `html.parser`, [[lxml - XML and HTML with Python]], [[html5lib]]
	- utilise `html.parser` par défaut
	- pour utiliser un autre parseur : `bs4.BeautifulSoup(thedoc, 'html5lib')`
- affichage
	- `s.prettify()` : met en forme le document - utilisé par défaut
	- `s.decode()` : chaîne de caractère
	- `s.encode()` : bytes
- Objets
	- Tag
		- https://www.crummy.com/software/BeautifulSoup/bs4/doc/#bs4.Tag
	- Navigable Strings
		- https://www.crummy.com/software/BeautifulSoup/bs4/doc/#bs4.NavigableString

Ressources
- https://www.crummy.com/software/BeautifulSoup/bs4/doc/ 🌟
- https://realpython.com/beautiful-soup-web-scraper-python/


```python
import bs4

# Intérpétation tout terrain
s = bs4.BeautifulSoup('<p foo="bar" class="a b">baz', 'html.parser')
s.decode() # '<p class="a b" foo="bar">baz</p>'


# Accès aux attributs
s = bs4.BeautifulSoup('<p foo="bar" class="a b">baz', 'html.parser')

s.p['foo']      # 'bar'
s.p.get('foo')  # 'bar'
s.get('foo')    # None

s.p.get('class')  # ['a', 'b']


# Accès au contenu
s = bs4.BeautifulSoup('<p>Pastèque <b>sauvage</b></p>', 'html.parser')
s.p.string  # None (car ne contient pas que du texte)
s.p.b.string  # 'sauvage'
list(s.p.strings)  # ['Pastèque ', 'sauvage']
s.text                  # 'Pastèque sauvage'
s.get_text()            # 'Pastèque sauvage'
s.get_text(strip=True)  # 'Pastèquesauvage'


# contents, children, descendants, parent, parents  
s = bs4.BeautifulSoup('<ul><li>A</li><li>B<em>52</em></li></ul>', 'html.parser')  
s.ul.li # <li>A</li> (le premier élément li)  
s.ul.contents # [<li>A</li>, <li>B <em>52</em></li>]  
list(s.ul.children) # [<li>A</li>, <li>B <em>52</em></li>]  
list(s.descendants) # [
    #   <ul><li>A</li><li>B <em>52</em></li></ul>, 
    #   <li>A</li>, 
    #   'A', 
    #   <li>B <em>52</em></li>, 
    #   'B ', 
    #   <em>52</em>, 
    #   '52'
    # ]  
s.ul.li.parent.name # 'ul'  
list(t.name for t in s.ul.li.parents) # ['ul', '[document]']


# next_sibling(s), previous_sibling(s)
s = bs4.BeautifulSoup('<ul><li>a</li><li>b</li><li>c</li></ul>', 'html.parser')  
s.ul.next_sibling            # None
s.ul.li.next_sibling         # <li>b</li> 
list(s.ul.li.next_siblings)  # [<li>b</li>, <li>c</li>]
s.ul.li.previous_sibling     # None


# next_element(s), previous_element(s)
s.ul.next_element           # <li>a</li>
s.ul.li.next_element        # 'a'
list(s.ul.li.next_elements) # ['a', <li>b</li>, 'b', <li>c</li>, 'c']
s.ul.li.previous_element    # <ul><li>a</li><li>b</li><li>c</li></ul>


# Tag vs NavigableString
s = bs4.BeautifulSoup('<div><p>Hello</p></div>', 'html.parser')  
type(s.div.p)  # <class 'bs4.element.Tag'>
type(s.div.p.string)  # <class 'bs4.element.NavigableString'>
list(s.div.descendants)  # [<p>Hello</p>, 'Hello']
list(type(t) for t in s.div.descendants)  # [
    #   <class 'bs4.element.Tag'>, 
    #   <class 'bs4.element.NavigableString'>
    # ]

```

```python
# css selectors
html = '<p>1</p><p class="foo">2</p><p class="foo bar">3</p>'
s = bs4.BeautifulSoup(html, 'html.parser')  
s.select('.foo') # [<p class="foo">2</p>, <p class="foo bar">3</p>]

```

```python
# find... (find, find_all, find_next, find_parent, find_next_sibling, ...)

# Finding by tag bame
s = bs4.BeautifulSoup('<b><p>bah</p></b>', 'html.parser')  
s.find_all('b') # [<b><p>bah</p></b>] (== s.find_all(name='b'))
s.find_all(['b', 'p']) # [<b><p>bah</p></b>, <p>bah</p>]
s.find_all(re.compile(r'^b')) # [<b><p>bah</p></b>]
s.find_all(re.compile(r'bah')) # []
s.find_all(lambda tag: tag.parent.name == 'b') # [<p>bah</p>]

# Finding by string
s = bs4.BeautifulSoup('<b>ah <p>bah</p></b>', 'html.parser')  
s.find_all(string='bah') # ['bah']  
s.find_all(name='b', string='bah') # []

# Finding by attribute
s = bs4.BeautifulSoup('<p>1</p><p foo>2</p><p foo bar>3</p>', 'html.parser')  
s.find_all('p', {'foo': True, 'bar': None})  # [<p foo="">2</p>]
```


