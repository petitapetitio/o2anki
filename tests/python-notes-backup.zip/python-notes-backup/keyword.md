MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/lexical_analysis.html#keywords
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

- aka "reserved word"
- pour afficher la liste : `import keyword; keyword.kwlist`
- soft keywords
	- mots clés qui sont réservés uniquement dans certains contextes
	- pour afficher la liste : `import keyword; keyword.softkwlist`

![[python-keywords.png]]


***
TARGET DECK: Python
FILE TAGS: lexical-structure

- STARTI [Basic] Qu'est-ce qu'un mot clé ? Back: Un mot réservé par le langage <!--ID: 1727542890065--> ENDI
- STARTI [Basic] Comment afficher la liste des mots clés depuis un terminal ? Back: `python -c "import keyword; print(keyword.kwlist)"` <!--ID: 1727542890067--> ENDI
- STARTI [Basic] Qu'est-ce qu'un mot clé "soft" ? Back: Un mot réservé par le langage dans certains contextes seulement. <!--ID: 1727542890069--> ENDI