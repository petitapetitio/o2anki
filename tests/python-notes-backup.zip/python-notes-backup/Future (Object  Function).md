Date : 2024-01-15
***

- représente le résultat éventuelle d'une opération asynchrone
- awaitable