MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Instruction (statement)]], [[paramètre (formel)]]
Date : 2024-10-23
***

***
TARGET DECK: Python
FILE TAGS: functions

- STARTI [Basic] à quoi sert l'instruction `def` ? Back:  à créer une fonction <!--ID: 1730827064114--> ENDI
- STARTI [Basic] que fait l'interpréteur lorsqu'il rencontre une instruction `def name` ? Back:  Il crée un objet fonction qu'il lie à l'identifiant `name` dans l'espace de noms courants. <!--ID: 1730827064116--> ENDI

START
Basic
Quelle est la syntaxe pour définir une fonction ?
Back: 
```python
def name(parameters):
    statements
```
où
- `name` est l'[[identifiant (nom)]] de la fonction
- le bloc indenté et non-vide `statements` est le corps de la fonction. Il contient les instructions exécutées lors d'un l'appel de la fonction
- `parameters` est une liste optionnelle qui spécifie les identifiants qui vont être liés aux valeurs fournies par les appels de fonction (les [[argument]]s)
<!--ID: 1730827064107-->
END


START
Basic
Comment déclarer une fonction vide `do_nothing` sans paramètres ?
Back: 
```python
def do_nothing():
    pass
```
<!--ID: 1730827064109-->
END


- [[Signature de fonction]]