MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[connectionless protocols (datagrams)]]
Date : 2025-01-18
***

![[Python in a Nutshell-8.png]]

- en haut : le code / en bas, l'exécution
- à gauche, le client / à droite le serveur
- RQ : démarrer le serveur avant le client

`client.py` : 
```python
import socket

MESSAGE = """\
I write, erase, rewrite
Erase again, and then
A poppy blooms.
"""

server_host = "localhost"
server_port = 8883
server_address = server_host, server_port

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:

    sock.settimeout(2)
    print("Timeout set to 2 seconds")

    for line in MESSAGE.splitlines():
        data = line.encode("utf-8")
        bytes_sent = sock.sendto(data, server_address)
        print(f"SENT {data} ({bytes_sent} of {len(data)} to {server_address}")
        response, address = sock.recvfrom(1024) # pk from plutôt que rcv ?
        print(f"RDCV {response.decode('utf-8')} from {server_address}")

print("Disconnected")

```

`server.py`
```python
import socket

server_ip = 'localhost'
server_port = 8883
server_address = server_ip, server_port

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
    sock.bind(server_address)
    print(f"Serving at {server_ip}:{server_port}")
    while True:
        data, sender_address = sock.recvfrom(1024)
        print(f"rcvd {data} from {sender_address}")

        bytes_sent = sock.sendto(data, sender_address)
        print(f"SENT {data} ({bytes_sent}/{len(data)}) to {sender_address}")

```
