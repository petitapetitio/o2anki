MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/dbm.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[DBM]], [[serialization]]
Date : 2025-01-11
***


Les clés et les valeurs doivent êtres des [[bytes]]

#### Démo

```python
import dbm  

with dbm.open("test", flag="n") as db:  
    db["hey".encode()] = b"000"  
  
with dbm.open("test", flag="r") as db:  
    print(db["hey".encode()])  
  
assert dbm.whichdb("test") == "dbm.ndbm"  
assert dbm.whichdb("a-file-that-don't-exist") == None  
assert dbm.whichdb(__file__) == ""
```
