MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-07
***

***
TARGET DECK: Python
FILE TAGS: programs imports

- STARTI [Basic] que permet l'instruction `from` ? Back: Importer des attributs spécifiques d'un module (dans l'espace de nom courant) <!--ID: 1730972172789--> ENDI
- STARTI [Basic] comment importer l'attribut `f` du module `m` ? Back:  `from m import f` <!--ID: 1730972172793--> ENDI
- STARTI [Basic] comment importer l'attribut `func` du module `m` sous le nom `f` ? Back:  `from m import func as f` <!--ID: 1730972172796--> ENDI
- STARTI [Basic] comment importer les attributs `function1`, `function2` d'un module `m` sous les noms `f1` et `f2` ? Back:  `from m import function1 as f1, function2 as f2`  <!--ID: 1730972172799--> ENDI
- Quels sont les deux types d'imports en Python ? <br>- Import relatif : résolu par rapport au chemin du module importeur (`from . import m`) <br>- Import absolu : résolu depuis `sys.path` (`import m`)


START
Basic
Comment organiser l'import des fonctions `function1`, `function2`, `function3` du module `m` sur plusieurs lignes ?
Back: 
```python
from m import (
    function1,
    function2,
    function3,
)
```
<!--ID: 1730972172784-->
END


from _ import *
- comment importer tous les attributs d'un module `m` dans l'espace global du module courant ? `from m import *`
- que fait l'instruction `from m import *` ? Elle importe tous les attributs publiques du module `m` dans l'espace global du module qui importe.
- Comment un module `m` peut-il contrôler ce qui est importé par `from m import *` ? En précisant la liste des attributs exportés via `__all__`.
- quels attributs sont importés si `m` contient un attribut `__all__` ? uniquement les attributs listés dans `__all__`
- quel problème pose `from m import *` ? Car cela peut écraser des variables existantes sans avertissement ([[gotcha]])
- quel sont les préconisations quant à la forme `from m import *` ? Ne pas l'utiliser

guidelines
- dans quel cas est-ce que l'import via `from` est préféré à `import` ? Lorsqu'on importe un module spécifique d'un package
- dans quels cas est-ce que l'import via `import` est préféré à `from` ? Lorsque l'on souhaite manipuler les attributs d'un module. `m.func()` et moins concis que simplement `func()`, mais est souvent plus clair. Un autre avantage est que `import` fonctionne bien avec `importlib.reload`.
