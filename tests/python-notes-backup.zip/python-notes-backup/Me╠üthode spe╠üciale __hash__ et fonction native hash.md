MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/datamodel.html#object.__hash__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[hash]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: hachage dunders

- STARTI [Basic] comment se traduit `hash(x)` ? Back:  `x.__hash()__` <!--ID: 1730827064428--> ENDI
- STARTI [Basic] quand définit-on la fonction `__hash__` ? Back:  Pour les objets immutables qui définissent `__eq__`. <!--ID: 1730827064438--> ENDI
- STARTI [Basic] `{True, 1}` ? Back:  `{True}` car l'expression `1 == True` évalue à `True` et `hash(1) == hash(True)`. ([[gotcha]]) <!--ID: 1730827064440--> ENDI





START
Basic
que renvoie `hash(x)` lorsque `__hash__` n'est pas fournie mais que `__eq__` est fourni ?
Back:
Une exception. 
`__eq__` sous-entend un comportement mutable ou complexe pour la comparaison.
```python
class A:
    ...

class B:
    def __eq__(self, other):
        ...


print(hash(A())) # 273746489
print(hash(B())) # TypeError: unhashable type: 'B'
```
<!--ID: 1730827064434-->
END



