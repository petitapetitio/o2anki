MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

- https://docs.python.org/3/library/threading.html#timer-objects
- `threading.timer(3.0, my_function).start() ` équivaut à `setTimeout(myFunction, 3000)` en [[JavaScript]]
- attention : durée exacte n'est pas garantie

```python
def hello():
    print("hello, world")

t = Timer(3.0, hello)
t.start()
```
