MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***


***
TARGET DECK: Python
FILE TAGS: set

- STARTI [Basic] Comment créer l'ensemble des carrés des éléments pairs de la séquence d'entiers `seq` en compréhension ? Back:  `{x * x for x in seq if x % 2 == 0}` <!--ID: 1728749077305--> ENDI
- STARTI [Basic] `{n//2 for n in range(10)}` ? Back:  `{0, 1, 2, 3, 4}` - les éléments dupliqués sont supprimés car il s'agit d'un ensemble <!--ID: 1728749077311--> ENDI

