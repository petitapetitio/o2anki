MOC : [[SOFTWARE ENGINEERING]]
Source : Łukasz Langa via [[Python in a Nutshell]] - [extrait de la conférence](https://www.youtube.com/watch?v=wbohVjhqg7c&t=387s)
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-03
***

- Vrai dans beaucoup de cas. Parfois, c'est le système de typage qui manque d'expressivité
- Certains fonctions natives du langage comme `x` sont [challengeantes à typer](https://gist.github.com/rhettinger/beb2f4a1d6d2ada70a468f51592e58cd)
