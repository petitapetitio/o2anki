MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags :
Date : 2025-01-14
***

Concepts : 
- *reference count* : 
	- quoi ? how many references to x are outstanding
	- comment la récupérer ? `sys.getrefcount(obj)` ([[module sys]])
	- CPython collecte `x` lorsque son nombre de références tombe à zéro
- [[mutual reference loop (cyclic garbage collections)]]
