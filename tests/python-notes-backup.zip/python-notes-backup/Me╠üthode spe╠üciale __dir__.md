MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/datamodel.html#object.__dir__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: classes dunders

- STARTI [Basic] `dir(x)` ? Back:  La liste triée des attributs de l'instance, de la classe et des classes parentes de `x`. <!--ID: 1730827064470--> ENDI
- STARTI [Basic] quelle instruction déclenche `x.__dir__()` ? Back: `dir(x)` <!--ID: 1734019138005--> ENDI

START
Basic
Qu'affiche `pprint(dir(B()))` ?
```python
class A:
    cx = 'x'

    def __init__(self):
        self.x = 1

    def f(self):
        pass


class B(A):
    cy = 'y'

    def __init__(self):
        super().__init__()
        self.y = 1
    
    def g(self):
        pass
```
Back:
La liste triée des attributs de l'instance, de la classe et des classes parentes de l'objet : 
```
['__class__',
 '__delattr__',
 '__dict__',
 '__dir__',
 ...
 '__subclasshook__',
 '__weakref__',
 'cx',
 'cy',
 'f',
 'g',
 'x',
 'y']
```
<!--ID: 1734019137997-->
END

START
Basic
Est-ce que la liste `dir(x)` est garantie complète ?
Back: Non 
Elle peut par exemple omettre les attributs dynamiques :
```python
class DynamicAttributes:
    def __getattr__(self, name):
        if name == "dynamic_attr":
            return "I am dynamic!"
        raise AttributeError(f"{name} not found")

assert "dynamic_attr" not in dir(DynamicAttributes())
```
<!--ID: 1730827064468-->
END
