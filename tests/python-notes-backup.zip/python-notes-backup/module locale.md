MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/locale.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[internationalization (i18n)]]
Date : 2025-01-11
***

- typically set at program startup
- est utile pour gérer les réglages à l'échelle du programme
- **n'est pas fait pour gérer plusieurs locales en même temps**
- peut être réglé pour tout (LC_ALL) ou par catégorie (LC_TIME, LC_NUMERIC, LC_MESSAGES, ...)
- peut affecter le [[module string]], [[module os]], [[module gettext]],  [[module time]]


```python
locale.setlocale(locale.LC_ALL, 'en_us')
locale.setlocale(locale.LC_NUMERIC, 'fr_FR')

locale.getlocale(locale.LC_TIME) # ex : ('fr_FR', 'ISO8859-1')
locale.localeconv()

locale.atof("0,123")  # 0.123
locale.atoi("00123")  # 123
locale.currency(550)  # 550,00 Eu
```
