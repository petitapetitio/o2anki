MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[COMPUTER NETWORKS]]
Date : 2025-01-18
***

- modèle d'architecture réseau où 
	- un serveur attends passivement les connexions en écoutant le traffic à un endpoint 
	- le client initie les connexions vers le serveur
	- le serveur répond aux requêtes des clients
- Traitement des requêtes
	- [[connectionless protocols (datagrams)]] : requêtes traitées de façon indépendantes, dès qu'elles arrivent
	- [[connection-oriented protocols]] : nécessitent un mécanisme de // (afin de pouvoir accepter plusieurs connections simultanément)
- Implémentations
	- [[Berkeley Sockets]] (implémentation ultra-dominante)
	- Winsock (Windows)
	- STREAMS (System V UNIX)

Exemples en python : 
- [[Simple connectionless example]]
- [[Simple connection-oriented example]]
