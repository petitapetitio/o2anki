MOC : [[SOFTWARE ENGINEERING]]
Source : https://en.wikipedia.org/wiki/List_of_TCP_and_UDP_port_numbers
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Transmission Control Protocol (TCP)|TCP]], [[User Data Protocol (UDP)|UDP]]
Date : 2025-01-18
***

- numéros allant de 0 - 1023
- éviter de taper dans cette plage
- Exemple 
	- [[HTTP]] : 80
	- [[HTTPS]] : 443
	- [[SMTP (Simple Mail Transfer Protocol)]]
	- [[Post Office Protocol (POP3)]]
- ils sont suivi des [[registered ports]]
