MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***


- d'où vient le terme curryfication ? du nom du mathématicien [[Haskell Curry]]