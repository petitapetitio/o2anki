MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/datamodel.html#object.__delattr__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: hachage dunders

- STARTI [Basic] comment se traduit `del x.attr` ? Back:  `x.__delattr__('attr')` <!--ID: 1730827064487--> ENDI
- STARTI [Basic] quelle instruction déclenche `x.__delattr__('attr')` ? Back: `del x.attr` <!--ID: 1730827064490--> ENDI
- STARTI [Basic] quel est le comportement par défaut de `x.__delattr__('attr')` ? Back: Supprime l'attribut via `del x.__dict__['attr']` <!--ID: 1730827064493--> ENDI
