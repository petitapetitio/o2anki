MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- https://docs.python.org/3/library/atexit.html
- hooks exécutés avant la terminaison du programme (en cela l'opposé du [[module site (Site-specific configuration hook)]])
- hooks exécutés in LIFO
