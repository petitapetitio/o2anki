MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-13
***

- https://docs.python.org/3/library/array.html
- sequence mutable mono-dimensionnelle homogène
- cas d'usage :
	- optimiser l'empreinte mémoire pour de grands tableaux de données du même type
	- interagir avec du code [[C]]
	- pour des cas d'usages plus avancés, regarder [[numpy]] et [[SciPy]]

```python
# Les array sont mutable
a = array('l') # signed long
a.append(2)    # array('l', [2])

# Les array peuvent être initialisés à la construction
array('l', [1, 2, 3, 4, 5])

# Un array de doubles
array('d', [1.0, 2.0, 3.14, -math.inf, math.nan])

```
