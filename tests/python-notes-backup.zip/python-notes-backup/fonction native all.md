MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/functions.html#all
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

***
TARGET DECK: Python
FILE TAGS: 

- STARTI [Basic] `all([1, True, None])` ? Back:  `False` <!--ID: 1734678007477--> ENDI
- STARTI [Basic] `all([1, True, ""])` ? Back:  `False` car `bool("") == False`  <!--ID: 1734678007478--> ENDI
- STARTI [Basic] `all([1, True, "a"])` ? Back:  `True` <!--ID: 1734678007479--> ENDI
- STARTI [Basic] Est-il possible de passer une fonction d'évaluation à `all` ? Back:  Non <!--ID: 1734678007480--> ENDI
