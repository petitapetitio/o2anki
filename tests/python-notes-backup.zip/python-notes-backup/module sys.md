MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

***
TARGET DECK: Python
FILE TAGS: 

- getrefcount
	- STARTI [Basic] Le nombre de référence à `x` ? Back:  `sys.getrefcount(x)` <!--ID: 1734678007427--> ENDI
	- STARTI [Basic] `sys.getrefcount(10)` ? Back:  Le nombre de référence à l'objet `10` <!--ID: 1734678007428--> ENDI
- getsizeof
	- STARTI [Basic] La taille de `None` en octets ? Back:  `sys.getsizeof(None)` <!--ID: 1734678007430--> ENDI
	- STARTI [Basic] `sys.getsizeof(None)` ? Back:  `16` La taille de `None` (en octets) <!--ID: 1734678007431--> ENDI
- plateform
	- STARTI [Basic] `sys.plateform` ? Back:  `'darwin'` (on my mac) <!--ID: 1734678007432--> ENDI
	- STARTI [Basic] Est-on sur linux ? Back:  `sys.platform.startswith('linux')` <!--ID: 1734678007433--> ENDI
- ps1, ps2
	- STARTI [Basic] `sys.ps1` ? Back:  `'>>> '` <!--ID: 1734678007434--> ENDI
	- STARTI [Basic] `sys.ps2` ? Back:  `'... '` <!--ID: 1734678007435--> ENDI
- stdin, stdout, stderr
- version
	- STARTI [Basic] Quel est le risque à tester la version de python à partir de `sys.version` ? Back:  `'3.10'` compare inférieur à `'3.8'` ! <!--ID: 1734678007436--> ENDI
- version_info
	- STARTI [Basic] Comment vérifier au runtime que la version est supérieure à `3.8` ? Back:  `sys.version_info >= (3, 8)` <!--ID: 1734678007437--> ENDI

