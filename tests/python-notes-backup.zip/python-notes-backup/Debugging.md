
En quoi consiste le déboggage ? <u>Découvrir</u> la cause d'un comportement incorrect et la <u>réparer</u>.

Principes
- [[Crée un test qui reproduit le bug avant de le fixer]]

Outils [[Python]] : 
- [[module inspect (Inspect live objects)]]
- [[module pdb (The Python Debugger)]] / [[ipdb]] / [[pudb]]
- [[module warnings]]


> Debugging is twice as hard as writing the code in the first place. Therefore, if you write the code as cleverly as you can, you are, by definition, not smart enough to debug it. Brian Kernighan

That's why : [[Préfère la clarté à avoir l'air intelligent (clear over clever)]]