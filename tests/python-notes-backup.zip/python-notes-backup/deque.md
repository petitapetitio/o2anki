MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/collections.html#deque-objects
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: 

- STARTI [Basic] que signifie "deque" ? Back:  “double-ended queue” <!--ID: 1734710569206--> ENDI
- STARTI [Basic] quels sont les intérêts d'un deque ? Back:  Ajout/supprimer en début/fin de liste est de façon rapide et thread-safe <!--ID: 1734710569208--> ENDI
- quels cas d'usage pour les deque ? FIFO, the latest N things seen (ring buffer)
- STARTI [Basic] deque : ajouter `e` à la fin ? Back:  `d.append(e)` <!--ID: 1734710569210--> ENDI
- STARTI [Basic] deque : ajouter `e` au début ? Back:  `d.append(e)` <!--ID: 1734710569212--> ENDI
- STARTI [Basic] deque : ajouter `elts` à la fin ? Back:  `d.extend(elts)` <!--ID: 1734710569214--> ENDI
- STARTI [Basic] deque : ajouter `elts` au début ? Back:  `d.extendleft(elts)` <!--ID: 1734710569215--> ENDI
- STARTI [Basic] `d = deque([0, 1, 2]); d.rotate(1); d` ? Back:  `deque([2, 0, 1])` <!--ID: 1734710569217--> ENDI
- STARTI [Basic] `d = deque([0, 1, 2]); d.rotate(-1); d` ? Back:  `deque([1, 2, 0])` <!--ID: 1734710569219--> ENDI
- STARTI [Basic] `d = deque([0, 1], maxlen=2); d.append(2); d` ? Back:  `deque([1, 2], maxlen=2)` <!--ID: 1734710569222--> ENDI
- STARTI [Basic] un deque vide de taille maximale `2` ? Back:  `deque(maxlen=2)` <!--ID: 1734710569224--> ENDI
- STARTI [Basic] `deque([0, 1, 2])[:2]` ? Back:  `TypeError: sequence index must be integer, not 'slice'` <!--ID: 1734710569226--> ENDI

