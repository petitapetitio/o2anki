MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-08
***

- http://pythonwheels.com/
- https://oreil.ly/python-nutshell-24

***
TARGET DECK: Python
FILE TAGS: packaging

- STARTI [Basic] qu'est-ce qu'une wheel ? Back:  Une version pré-compilée d'un package. <!--ID: 1731677487721--> ENDI
- STARTI [Basic] Quels sont les deux types de wheels ? Back:   <br>*pure wheel* : ne nécessitent pas de compilation <br>*non-pure wheels* : doivent être créés depuis la plateforme cible <!--ID: 1731749004782--> ENDI
- STARTI [Basic] Quel était le format de distribution répandu avant le format wheel ? Back:  [[python eggs]] <!--ID: 1731677487723--> ENDI

- STARTI [Basic] Quand est-ce que le format wheel a été introduit ? Back:  En 2012-2013 avec la [[PEP 427 – The Wheel Binary Package Format 1.0]] <!--ID: 1731749004783--> ENDI
- STARTI [Basic] Quel problème adresse les wheels ? Back:  La distribution de [[module d'extension]] compilés pour différentes architectures <!--ID: 1731749004784--> ENDI
- STARTI [Basic] Que contient la `psycopg2-2.9.3-py310-cp310-macosx_12_0_arm64.whl` ? Back:  La version  2.9.3 de psycopg2 pour CPython 3.10 pour la plateforme macOS avec un processeur ARM 64-bit. <!--ID: 1731749004785--> ENDI
- Quelle est la convention de nommage des wheels ? `{dist}-{version}(-{build_tag})?-{python_tag}-{abi_tag}-{platform_tag}.whl`. ([[ABI (application binary interface)]])

START
Basic
Pourquoi le nom "wheels" ?
Back:
En référence aux meules de fromage car [[PyPI]] est aussi surnommé « cheeseshop ».

Cheeseshop fait référence au sketch des Monty Python. Le cheeseshop n'a pas de fromage, et la blague était que PyPI était initialement comme cela : il n'y avait rien dedans, que des liens. 
( #post )
<!--ID: 1731677487724-->
END


Quels sont les 3 principaux avantages des wheels par rapport aux eggs ?
- Installation plus rapide (pas de compilation nécessaire)
- Format standardisé [PEP 427](https://peps.python.org/pep-0427/) (puis [màj](https://packaging.python.org/en/latest/specifications/binary-distribution-format/))
- Meilleure gestion des dépendances

From https://discuss.python.org/t/where-the-name-wheel-comes-from/6708/2 : 
> PyPI used to be called a cheeseshop, in reference to a Monty Python sketch (where the cheeseshop has no cheese). The joke was that PyPI was initially like that - it had nothing in it back then. 
> 
> Based off that, wheel is a reference to wheels of cheese.

***

**Différence wheel vs sdist :** 
Q : Quelle est la différence fondamentale entre une wheel et une sdist ? 
R : 
- wheel (.whl) = package _déjà construit_, prêt à être installé
- sdist (.tar.gz) = _code source_ qui doit être construit à l'installation

**Format incompatible :** 
Q : Est-ce qu'une wheel peut être une sdist ? 
R : Non, ce sont deux formats distincts et incompatibles :
- wheel = format binaire
- sdist = archive source

**Choix du format :** 
Q : Quand utiliser wheel vs sdist ? 
R : 
- wheel : pour une installation rapide, sans compilation
- sdist : quand une compilation spécifique à la machine est nécessaire

**Extension des fichiers :** 
Q : Quelles sont les extensions de fichiers pour wheel et sdist ? R : 
- wheel : `.whl`
- sdist : `.tar.gz`

**Ordre d'installation de pip :** 
Q : Quel format pip préfère-t-il installer entre wheel et sdist ? 
R : pip préfère installer une wheel compatible si disponible, sinon utilise la sdist

**Nécessité de wheel :** 
Q : Est-il nécessaire de fournir une wheel si le paquet est en pure Python ? 
R : Non, pip peut créer automatiquement une wheel à l'installation à partir de la sdist

**Avantages wheel pure Python :** 
Q : Quels sont les avantages à fournir une wheel même pour un paquet pure Python ? 
R : 
- Installation plus rapide (pas de build)
- Vérification d'intégrité plus simple
- Évite les problèmes de build sur la machine cible

**Définition pure Python :** 
Q : Qu'est-ce qu'un paquet "pure Python" ? 
R : Un paquet qui ne contient que du code Python, sans code natif à compiler (C, C++, Rust...)

**Cas où wheel nécessaire :** 
Q : Dans quels cas une wheel est-elle nécessaire ? 
R : 
- Paquets avec extensions C/C++/Rust
- Paquets avec build complexe
- Paquets nécessitant une compilation