MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/contextlib.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-05
***

***
TARGET DECK: Python
FILE TAGS: 

- STARTI [Basic] Dans quel module sont placés les utilitaires liés aux [[Context Manager]] ? Back:  `contextlib` <!--ID: 1730827063595--> ENDI
- STARTI [Basic] Que contient le module `contextlib` ? Back:  des utilitaires liés à l'[[instruction with]] et aux [[Context Manager]] (dont des classes *somewhat abstruse*) <!--ID: 1730827063598--> ENDI


START
Basic
Comment ignorer l'exception `FileNotFoundError` dans un contexte donné ?
Back:
```python
from contextlib import suppress
with suppress(FileNotFoundError):
    os.remove('fichier.txt')
```
<!--ID: 1730827063593-->
END