MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[URL]]
Date : 2025-01-18
***

- https://docs.python.org/3/library/urllib.parse.html#module-urllib.parse
- fonctions
	- synthétiser une url avec `urlunsplit`, `urljoin`
	- décomposer une url avec `urlsplit`
	- encoder et décoder 
		- `urlencode` (pour encoder la query en [[percent-encoding]]) / `parse_qs`
		- `quote` (perform percent encoding) / `unquote`
		- `quote_plus` (`quote` mais encode les espaces avec un `+` et percent-encode `/`)

###### Démo
```python
from urllib import parse as urlparse  
  
urlparse.urljoin('http://host.com/some/path/here', '../other/path') == 'http://host.com/some/other/path'  
  
url = urlparse.urlsplit('http://www.python.org:80/faq.cgi?src=file#blue')  
url.scheme == 'http'  
url.hostname == 'www.python.org'  
url.port == 80  
url.path == '/faq.cgi'  
url.query == 'src=file'  
url.fragment == 'blue'  
tuple(url) == ('http', 'www.python.org:80', '/faq.cgi', 'src=file', 'blue')

urlparse.urlunsplit(('http', 'www.python.org', '/faq.cgi', 'src=file', 'blue')) == 'http://www.python.org/faq.cgi?src=file#blue'

urlparse.quote('/El Niño/') == '/El%20Ni%C3%B1o/'
urlparse.quote_plus('/El Niño/') == '%2FEl+Ni%C3%B1o%2F'
urlparse.quote_plus('/El Niño/', safe='/') == '/El+Ni%C3%B1o/'
urlparse.urlencode({'spam': 1, 'eggs': '/El Niù'}) == 'spam=1&eggs=%2FEl+Ni%C3%B9
urlparse.parse_qsl('spam=1&eggs=%2FEl+Ni%C3%B9') == {'spam': ['1'], 'eggs': ['/El Niù']}
```
