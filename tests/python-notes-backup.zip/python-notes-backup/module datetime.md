MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

- https://docs.python.org/3/library/datetime.html
- tz aware ou naive (par défaut)
- instances immutables
- classes
	- `datetime.date`
	- `datetime.time`
	- `datetime.datetime`
	- `datetime.timedelta`
	- `datetime.tzinfo` (abtract)
	- `datetime.timezone` (implémente `tzinfo`)


#### class datetime.date
- https://docs.python.org/3/library/datetime.html#date-objects

[[Cheat sheet]] : 
```python
from datetime import date


# Créer une date

date(2025, 1, 10)

date.today() #  datetime.date(2025, 1, 11)
  
date.fromtimestamp(1) # date(1970, 01, 01)
  
date.fromordinal(1) # date(0001, 01, 01)
date.fromordinal(2) # date(0001, 01, 02)


# Méthodes des dates 

d = date.today()

d.isoformat()       # '2025-01-11'
d.replace(month=5)  # date(2025, 1, 11)

# import locale
# locale.setlocale(locale.LC_ALL, "fr_FR")
d.strftime("%d %B %y") # 11 janvier 25

d.toordinal()       # 739262
d.timetuple()       # time.struct_time(tm_year=2025, tm_mon=1, tm_mday=11, tm_hour=0, tm_min=0, tm_sec=0, tm_wday=5, tm_yday=11, tm_isdst=-1)

```

#### classe datetime.time
- https://docs.python.org/3/library/datetime.html#time-objects
- tz aware ou naïve

```python
from datetime import time


t = time(17, 30, 10, 150)

t.replace(minute=35)  # time(17, 30, 10, 150)

time(17, 30, 10).isoformat()      # '17:30:10' 
time(17, 30, 10, 150).isoformat() # '17:30:10.000150'

t.strftime("%H:%M:%S")            # '17:30:10' 
```


#### classe datetime.datetime
- https://docs.python.org/3/library/datetime.html#datetime-objects
- [[module zoneinfo (IANA time zone support)]]
- peut être tz aware ou naïve

```python
from datetime import datetime

# Construire une datetime naïve

dt.datetime.now() 
datetime(2025, 1, 10, 17, 30)

# Construire un datetime tz-aware : 
d = datetime.now(tz=ZoneInfo("Europe/Paris"))
naive_datetime.replace(tzinfo=ZoneInfo("UTC"))
```


#### classe datetime.timedelta
- https://docs.python.org/3/library/datetime.html#timedelta-objects

```python
from datetime import time, datetime, date


# Créer un timedelta

timedelta(days=1, hours=12)

date.today() - date(2025, 1, 1)  # timedelta(days=10)
date.today() - date(1992, 5, 4)  # timedelta(days=11940)

time(12, 0, 0) - time(9, 30, 0) # TypeError

datetime(2025, 1, 10, 17, 30) - datetime(2025, 1, 10, 11, 55) # timedelta(seconds=20100)


# Ajouter un timedelta

date(2000, 1, 1) + timedelta(minutes=1)     # date(2000, 1, 1)
date(2000, 1, 1) + timedelta(minutes=1440)  # date(2000, 1, 2)

```
