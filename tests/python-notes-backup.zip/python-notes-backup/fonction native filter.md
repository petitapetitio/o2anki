MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

***
TARGET DECK: Python
FILE TAGS: 

https://docs.python.org/3/library/functions.html#filter
- STARTI [Basic] `list(filter(None, [1, 0, 10]))` ? Back:  `[1, 10]` <!--ID: 1734678007456--> ENDI
- STARTI [Basic] filter : les éléments pairs de `elts = [1, 2, 3, 4]` ? Back:  `filter(lambda x: x % 2 == 0, elts)` <!--ID: 1734678007457--> ENDI
