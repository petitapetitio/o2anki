MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/reference/import.html#packages
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-07
***

Refs : 
- https://docs.python.org/3/reference/import.html#packages
- https://docs.python.org/fr/3.13/glossary.html#term-regular-package
- https://docs.python.org/fr/3.13/glossary.html#term-namespace-package
- [https://stackoverflow.com/a/68897551/5994461](https://stackoverflow.com/a/68897551/5994461)

***
TARGET DECK: Python
FILE TAGS: programs

- STARTI [Basic] qu'est-ce qu'un package ? Back:  Un [[module]] qui contient d'autres modules.  <!--ID: 1730972172822--> ENDI
- STARTI [Basic] comment se matérialise un paquet classique ? Back: un dossier contenant un fichier [[1 PROJETS/The developer's brain/Notes/Python/__init__.py|__init__.py]] et des [[fichier .py]]  <!--ID: 1730972172825--> ENDI
- STARTI [Basic] quels sont les deux types de packages en python ? Back:  les packages classiques et les namespaces packages <!--ID: 1730972172828--> ENDI
- STARTI [Basic] quelle est la différence entre un package classique et un namespace package ? Back:  un paquet classique se matérialise par un dossier contenant un fichier `__init__.py`, les namespaces packages sont virtuels et n'ont pas de fichier `__init__.py`. <!--ID: 1730972172831--> ENDI
- STARTI [Basic] qu'est-ce que le corps d'un regular package `p` ? Back:  le contenu du fichier `p/__init__.py` <!--ID: 1731677487769--> ENDI
- STARTI [Basic] à quel moment est exécuté le corps d'un package ? Back: lors du premier import d'un module (du package). <!--ID: 1731677487770--> ENDI
- STARTI [Basic] Est-ce que <br>`from p import m as v` <br>est équivalent à <br>`import p.m as v` <br>? Back:  Oui <!--ID: 1731677487771--> ENDI
- STARTI [Basic] packages : que renvoie `p.__file__`  ? Back:  le chemin absolu vers le fichier `__init__.py` du package. Ex : `/Users/lxnd/dev/python-demo/p/__init__.py` <!--ID: 1731677487772--> ENDI
- STARTI [Basic] qu'importe `from p import *` si le fichier `p/__init__.py` est vide ? Back:  Rien <!--ID: 1731677487773--> ENDI

START
Basic
packages : comment définir la liste des attributs qui seront importés via `from p import *` ?
Back:
En définissant l'attribut `__all__` dans `p/__init__.py`

`p/__init__.py` : 
```python
M = 50
V = "alpha"

__all__ = [
    "M",
    "V"
]
```

`main.py` : 
```python
from p import *  
print(M, V) # affiche : 50 alpha
```
<!--ID: 1731677487774-->
END

