https://docs.python.org/fr/3.13/glossary.html#term-REPL
un autre nom pour l'interpréteur interactif.