MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/sys.html#sys.path
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-07
***

***
TARGET DECK: Python
FILE TAGS: imports

- STARTI [Basic] Quel est le rôle de `sys.path` ? Back: Lister les dossiers et les archives zip où chercher les modules. <!--ID: 1731053653023--> ENDI

START
Basic
Que contient sys.path par défaut ?
Back: 
En mode script : le dossier du script, PYTHONPATH, les chemins site-specific (.pth)
En mode interactif :le dossier courant, PYTHONPATH, les chemins site-specific (.pth)

source : https://docs.python.org/3/tutorial/modules.html#the-module-search-path
<!--ID: 1731053653022-->
END
