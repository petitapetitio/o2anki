MOC : 
Recommandé par : 
Auteur : [[Alex Martelli]]
Date : 2024-09-26
Projet : 
Note /10 :
Tags : #livre

***
## Pourquoi

- Looks amazing
- Couvre les bases
- Màj en 2023 

- [[Python in a Nutshell - A desktop quick reference (4th Edition).pdf]]
- [[24 Packaging Programs and Extensions.pdf]]
- [[25 Extending and Embedding Classic Python.pdf]]

## Résumé rapide

- survol des principaux éléments du langage
- idéal si tu déjà des notions de python, que tu aimes le langage, et que tu souhaites aller en profondeur sur le langage, et poser des fondations solides pour la suite.

## Key takeways

comment lire ce genre de livre ? 
- créer une fiche par concept
- lire sur ordinateur (en split screen)
- pratiquer (ne pas se contenter de lire)
- ajouter des cheat sheets / recipes aux fiches


## Mes notes

Commencé le 2024-09-28
Terminé le 2025-01-19

Dans quelle mesure est-ce que https://docs.python.org/3/tutorial/index.html n'aurait pas été une meilleure option ? La couverture de la section tutoriel est très parcellaire et se concentre surtout sur des parties non intuitives du langage.


# Introduction

TARGET DECK: Python

[[Python|Python]]
- [[Histoire de Python]]
- Développement
	- [[Python Steering Council (PSC)]]
	- [[Python Software Foundation (PSF)]]
	- [[Python Enhancement Proposal (PEP)]]
	- [[Feature releases]]
- Outils pour tout le cycle de développement : analysis, design, prototyping, coding, testing, debugging, tuning, documentation, maintenance ([[Le cycle de vie du développement logiciel|The Software Development Life Cycle (SDLC)]])
- Programmes pythons performants
	- En général la performance est suffisante ([[Choisis une option suffisamment bonne (Good Enough vs Best)]])
	- Lorsque ce n'est pas le cas, voir techniques p. 541 dans Python in a nutshell
- Le langage
	- est riche
	- adhère au principe que : a language should not have “convenient” shortcuts, special cases, ad hoc exceptions, overly subtle distinctions, or mysterious and tricky under-the-covers optimizations.
- La bibliothèque standard et les modules d'extension
- [[Python Implementations]]
- Installation
	- [[pyenv]]
	- Distributions
		- Anaconda et Miniconda
			- Python packagé avec un ensemble d'extensions
			- Basé sur la technologie de packaging conda
			- Utilise un mécanisme différent de pip pour les environnements virtuels
	- [[Python Launcher (Windows)]]
	- **Ne pas toucher à la version pré-installée (elle est parfois utilisée par le système et la changer peut entrainer des bugs)**

# The Python Interpreter

[[interpréteur Python]]

Python Development Environments
- [[IDE]]
	- IDLE : l'IDE embarqué avec la distribution standard
	- [[Visual Studio Code]] with PTVS plug-in
	- [[Vim]]
	- [[PyCharm|PyCharm]]
- Outils
	- Code formatting 
		- [[black]]
		- Blue
	- pre-commit
	- [[mypy]]

Running python programs
- [[programme]]
- [[script python]]
- [[module]]
- [[fichier .py]]
- [[Shebang]]
- [[$A - Running python programs (staled)]]


Python in the browser
- [[PyScript]]
- [[Jupyter]]

# The Python Language

## Lexical Structure

### Lignes et indentation

- [[ligne physique]]
- [[ligne logique]]
- [[continuation line]]
- [[bloc]]

STARTI [Basic] Comment est-ce que les programmes sont structurés ? Back: Python utilise l'indentation pour structurer les programmes sans avoir recours aux accolades `{}` et aux point-virgules `;`. <!--ID: 1727939491436--> ENDI
### Character sets
Utilise [[UTF-8]] par défaut (compatible avec du 7-bit ASCII)

### Tokens
[[Token]]

### Statements (instructions)
- [[instruction simple (simple statement)]]
- [[instruction composée (compound statements)]]


## Data Types
- [[type]]
- [[types numériques]]
- [[module collections (python) 🌟]]
	- [[sequence]]
		- [[str (chaîne de caractères)]]
		- [[bytes]]
		- [[bytearray]]
		- [[tuple]]
		- [[list]]
	- [[set (et frozenset)]]
	- [[dict]]
- [[None]]
- [[Ellipsis]]
- [[Callable]]
- [[Booléens (bool)]]


## Variables and Other References
- [[référence]]
- [[variable]]
- [[instruction d'assignation]]
- [[instruction del]]

## Expressions and operators
- [[expression]]
- [[comparaison chaînée (Comparison chaining)]]
- [[opérateur court-circuit (short-circuiting operator)]]
- [[expression d'affectation (Walrus operator)]]

## Opérations numériques
- [[Opérations numériques]]

## Sequence operations
https://docs.python.org/3/library/stdtypes.html#common-sequence-operations

- [[fonction native len]]
- [[fonctions natives min et max]]
- [[fonction native fonction native sum]]
- [[conversion de séquence]]
- [[concatenation de séquences]]
- [[répétition de séquences]]
- [[test de présence (opérateur in)]]
- [[sélection (subscription)]]
- [[tranchage (slicing)]]

### List operations
- [[list]]
- [[fonction native sorted]]

## Set operations
- [[set (et frozenset)]]

## Dictionary operations
- [[dict]]

## Instructions de contrôle de flux (Control flow statements)

- Control flow : A program’s control flow regulates the order in which the program’s code executes
- Principales instructions : if, match, for, while, try, with, (functions ?)
	- [[instruction conditionnelle if]]
	- [[instruction match]]
	- [[instruction while]]
	- [[instruction for]]
		- [[itérateur]]
		- [[range]]
		- [[Liste en compréhension]]
		- [[Ensembles en compréhension]]
		- [[Dictionnaires en compréhension]]
	- [[instruction break]]
	- [[Instruction continue]]
	- [[Instructions de boucle]]
	- [[clause else sur les instructions de boucle]]
	- [[instruction pass]]
	- [[Instruction try et raise]]
	- [[instruction with]]


questions
- à quoi sert une instruction ... ?
- comment fonctionne une instruction ... ?
- quelle est la syntaxe d'une instruction ... ?

## Functions
- [[fonction (Python)]]
- [[instruction def]]
- [[paramètre (formel)]]
	- [[Paramètre ordinaire (positionnel ou nommé)]]
	- [[Marqueur positionnel-uniquement]]
	- [[Paramètre var-positional (Collecteur d'arguments positionnels)]]
	- [[Marqueur keyword-only (nommé uniquement)]]
	- [[Paramètre var-keyword (Collecteur d'arguments nommés)]]
- [[Attributs des fonctions]]
- [[Instruction return]]
- [[Appel de fonction]]
- [[Espace de nom des fonctions]]
- [[Instruction global]]
- [[fonction imbriquée]]
	- [[instruction nonlocal]]
	- [[variable libre]]
	- [[variable globale]]
	- [[variable de closure]]
	- [[closure]]
	- [[LEGB]]
- [[expression lambda]]
- [[fonction génératrice (yield)]]
- [[Expression génératrice (Generator expression)]]
- [[Récursivité]]

# Object-oriented Python

## Classes et instances


- [[classe]]
- [[instruction class]]

### corps de classe

#### attributs des objets classe

- [[attribut de classe]]
- [[attribut spécial __name__]]
- [[attribut spécial __bases__]]
- [[attribut spécial __class__]]
- [[attribut spécial __dict__]]
- [[attribut spécial __slots__]]

#### Méthode
[[méthode]]

### descriptors 
[[descripteur]]

### instance de classe
https://docs.python.org/3/reference/datamodel.html#class-instances
https://docs.python.org/3/reference/datamodel.html#id4

- STARTI [Basic] comment créer une instance d'une classe `class C: pass` ? Back: `C()` <br>Appeler l'objet classe comme si c'était une fonction. <!--ID: 1730827064745--> ENDI
- STARTI [Basic] à quoi correspond `z.__dict['z']__ = 67` ? Back:  `z.z = 67` (dans le cas général) <!--ID: 1730827064747--> ENDI

- [[méthode spéciale __init__]]
- [[méthode spéciale __new__]]

### Référence à un attribut
[[référence à un attribut]]

### Bound and unbound methods
[[Méthode liée]]

### Héritage
- [[Method resolution order (MRO)]]
- [[Surcharge d'attributs (overriding)]]
- [[Délégation aux méthodes de la superclasse]]
- [[fonction native type]]

- STARTI [Basic] est-ce qu'une classe peut hériter d'un type built-in ? Back:  oui <!--ID: 1730827064749--> ENDI
- STARTI [Basic] Qu'indique `TypeError: multiple bases have instance lay-out conflict` ? Back: Qu’une classe hérite de types built-ins qui ne sont pas conçus pour coopérer. Ex : `class A(list, dict): ...` lève cette exception. <!--ID: 1730827064751--> ENDI

### Type built-in "object"
[[classe object]]

### Class-level methods
- [[Méthode statique]]
- [[Méthode de classe]]

### Propriétés
[[Propriété]]

### per instance methods
pas compris


## Méthodes spéciales
[[Méthodes spéciales]]

Special Methods for Containers : Ce chapitre contient des indications sur les méthodes qu'il est recommandé d'implémenter lorsque tu crées des séquences et des mappings custom. Hériter des classes de base de collections.abc est un bon point de départ mais ne remplit pas tous les requirements listés.

### Abstract Base Classes
- [[Classe de base abstraite]]
- [[Sous-classe virtuelle (register)]]
- [[méthode spéciale __subclasshook__]]
- [[Numeric tower (tour des nombres)]]

#### Méthodes spéciales pour les types numériques
Beaucoup de méthodes.

## Décorateurs
- [[higher-order function]]
- [[Décorateur (decorator)]]

## Métaclasse
- [[métaclasse]]
- [[méthode spéciale __init_subclass__]]
- [[méthode spéciale __set_name__]]
- [[méthode spéciale __prepare__]]


### Data Classes
[[dataclass]]

### Enums (Python)
[[Enums]]

# Type annotation
[[type annotations]]

# Exceptions
[[Exception]]

# Modules and packages

- [[programme]]
- [[module]]
- [[module d'extension]]
- [[package]]

## Module Objects
- [[module object]]

## Importation de modules
https://docs.python.org/3/reference/import.html

- importation ? Processus par lequel le code Python d'un module est mis à la disposition du code Python d'un autre module. (ref : https://docs.python.org/3/glossary.html#term-importing)

- [[instruction import]]
- [[instruction from]]
- [[fonction native __import__]]
- [[sys.path]]
- [[fichier compilé .pyc]]
- [[modules built-ins]]
- [[chargement du programme principal]]
- [[rechargement de modules avec importlib.reload]]
- [[Imports circulaires]]
- [[Imports personnalisés]]

## Packages
[[package]]


## Distribution utilities 

Quelles sont les différentes façons de distributer un package ? 
- archives compressées zip
- wheels
- ...

- [[distutils]]
- [[setuptools]]
- [[wheel (.whl)]]
- [[pip]]


## Python environments
[[Environnement virtuel]]


# Core built-ins and Standard Library Modules


- [[types natifs]]
	- what is type equality checking ? `type(9.0) is float`
	- pourquoi préférer `isinstance(9.0, float)` à `type(9.0) is float` ? Permet pas de jouer avec le polymorphisme: un sous-type de float va passer le test.
	- [[Goose typing]]
- [[Built-ins functions]]
- [[module sys]]
- [[module copy]]
- [[module collections]]
- [[module functools]]
- [[module argparse]]
- [[module itertools]]

# Strings and things

- [[str (chaîne de caractères)]]
- [[module string]]
- [[module textwrap]]
- [[module pprint]]
- [[module unicodedata]]

# Regular expression

- [[Regular Expression]]
- [[module re]]
- [[module regex (third party)]]

# File and text operations

- qu'est-ce qu'un fichier ? un flux de texte ou de bytes qu'un programme peut lire/écrire
- qu'est-ce qu'un système de fichier ? un répertoire hiérarchique de fichiers

Concepts
- random access (accès non séquentiel)
- [[file-like object]]s (https://docs.python.org/3/glossary.html#term-file-like-object, [[duck typing]])
- buffering

- [[module io]] 
- [[module tempfile]]
- [[module struct]]
- [[module tarfile]]
- [[module zipfile]]
- [[module os]]
- [[file descriptor]]
- [[module os.path]]

### OSError
- 3 attributs intéressants : `errno`, `filename`, `stderror`
- le nom de l'erreur associée à `oserror.errno` ? `errno.errorcode[oserr.errno]` 

- [[module pathlib]]
- [[module stat]]
- [[module filecmp]]
- [[module glob]]
- [[module shutil (shell utilities)]]
- [[module getpass]]
- [[module readline]]
- [[Développer des clients en lignes de commandes en python]]

## Internationalization (i18n)

- [[internationalization (i18n)]]
- [[localisation (i10n)]]
- [[module locale]]
- [[module gettext]]

## Persistance and databases

- [[DBM]]
- [[Relational Database Management System (RDBMS)]]

- [[serialization]]
	- [[module marshall (Internal Python object serialization)]]
	- [[module csv (CSV File Reading and Writing)]]
	- [[module json (JSON encoder and decoder)]]
	- [[module pickle (Python object serialization)]]
	- [[module shelve (Python object persistence)]]
	- [[module dbm (Interfaces to Unix “databases”)]]

- [[Python DBAPI]]
- [[module sqlite3]]

Pour aller + loins : creuser postgre et psycopg


# Time operations

- [[DST (daylight saving time)]]
-  python epoch ? 1er janvier 1970 UTC
- concepts
	- time instant
	- time interval

- [[module time]]
- [[module datetime]]
- [[module zoneinfo (IANA time zone support)]]
- [[Toujours utiliser des dates tz-aware]]
- [[module dateutil]]
- [[module sched (Event scheduler)]]
- [[module calendar (General calendar-related functions)]]

How to see if a module is actively used ? 
- look at the updates ! 
	- le [[module sched (Event scheduler)]] n'a pas été modifié depuis 3.3
	- le [[module calendar (General calendar-related functions)]] a été modifié dans 3.12


# Customizing execution

- [[module site (Site-specific configuration hook)]]
- [[module atexit (Exit handlers)]] (**TODO : démo**)
- [[fonctions natives exec, eval et compile]]

## Garbage collection

- [[Garbage collection]]
- [[module gc]]
- [[module weakref (weak references)]]

# Concurrency - threads and processes

- [[(multi)threading]]
- [[Crée un thread dédié pour chaque sous-système externe]]
- [[module threading (Thread-based parallelism)]]
- [[module multiprocessing (Process-based parallelism)]]

## Running other programs

- [[module subprocess (Subprocess management)]]
- exécuter d'autres programmes avec le [[module os]] (déprécié)
	- os.exec* 
		- remplace le process courant et ne retourne jamais (sauf erreur)
		- `os.execl('/bin/ls', 'ls', '-l') # le code après ne s'exécutera jamais`
	- os.popen 
		- crée un pipe vers la commande
		- renvoie un objet file-like
	- os.spawn*
		- crée un nouveau processus
		- `os.spawnl(os.P_WAIT, '/bin/ls', 'ls', '-l')`
		- → `subprocess.call(['/bin/ls', 'ls', '-l'])
	- [os.system(command)](https://docs.python.org/3/library/os.html#os.system)
		- exécute via le shell, bloque jusqu'à la fin de l'exécution et renvoie le code de sortie
		- `status = os.system('ls -l')`
		- → `subprocess.call`

- [[module mmap (Memory-mapped file)]]


# Numeric processing

- [[Nombres à virgules flottantes (floats)]]
- [[module math (Mathematical functions)]]
- [[module cmath (Mathematical functions for complex numbers)]]
- [[module statistics]]

- [[module random (Generate pseudo-random numbers)]]
- [[module secret (Generate secure random numbers for managing secrets)]]

- [[module fraction (Rational numbers)]]
- [[module decimal (Decimal fixed-point and floating-point arithmetic)]]

## Array processing

- [[module array]]
- [[numpy]]
- [[scipy]]

# Testing, debugging and optimizing

- [[Testing]]
- [[Debugging]]
- [[Optimisation]]

Ressources 
- [[Modern Systems Analysis and Design]]
- [[The Psychology of Computer Programming]]

# Networking basics

- [[connection-oriented protocols]]
- [[connectionless protocols (datagrams)]]

- [[Berkeley Sockets]]
- [[Client-Server networking]]
- [[module socket]]

- [[Transport security layer (TLS)]]
- [[Certificat digital (certificate authority (CA)]]
- [[module ssl]]


# Client-side network protocol modules

- [[module imaplib]]
- [[module poplib]]
- [[module smtplib]]

- [[module urllib.parse]]
- [[module urllib.request]] (TODO : demo)
- [[module urllib.robotparser (Parser for robots.txt)]]
- [[module ftplib (FTP protocol client)]]


Activité : 
- me connecter à mon serveur perso avec imap en python ! 
- envoyer un e-mail depuis mon post ! 



# Serving HTTP

- [[CGI (Common Gateway Interface)]]
- [[WSGI (Web Server Gateway Interface)]]
- [[module http.cookies]]
- [[module http.server]]
- [[Python web frameworks]]

# Email, MIME, Network Encodings

- [[MIME]]
- [[email package - An email and MIME handling package]]
- [[module base64]]
- [[HyperText Markup Language (HTML)]]
- [[XML]]

==TODO : jouer à décortiquer des e-mails que de ma boite e-mail (avec le package email)==

# Packaging Programs and Extensions

[[24 Packaging Programs and Extensions.pdf]]
https://packaging.python.org/en/latest/

- [[Python Packaging]]
- [[Python Project Management Tools]]

### Histoire du packaging en Python

[[PyPI]]
[[python eggs]]
[[setuptools]]
[[distutils]]
[[wheel (.whl)]]
[[pip]]

## The build process

[[build frontend]]
[[build backend]]

entry points
- Entry points are a way to identify particular pieces of your code (modules or functions, in most cases) by names that need not relate to the names they are given in the logic.
- 2 rôles
	- ajouter des commandes, aka *console scripts* dans le vocabulaire de [[setuptools]],  *scripts* dans le vocabulaire de [[Poetry]].

[[arborescence source]]

2 types de distributions
- [[source distribution (sdist)]]
- [[built distribution]]

2 types de packages
- Pure packages : 
	- uniquement du code python et des données. 
	- installation très simple : just need to move the source in the virtual env site-packages 
- extension packages : 
	- inclut du code compilé qui requiert des outils de compilation pendant le build process
	- always delivered as [[wheel (.whl)]] files


[[Poetry]]
[[setuptools]]


Guidelines
- ==keep project name in pyproject.toml the same as the name of the package directory so that pip install xxx match with import xxx==


## Distribution

- [[source distribution (sdist)]]
- [[wheel (.whl)]]
- [[twine]]
- [[flit]]
- [[zipapp]]


# Extending and Embedding Classic Python ✨

[[25 Extending and Embedding Classic Python.pdf]]

[[CPython]]
- les [[types natifs]] sont codés en C
- https://github.com/python/cpython/tree/main
- [[Dynamically loaded librairies (dll, so, dylib)]]

Ressources
- https://docs.python.org/3/extending/index.html 🌟
- https://docs.python.org/3/c-api/index.html

*Extending Python* means building modules coded in another language that Python code can import. 
*Embedding Python* means executing Python code from an application coded in another language.

Motivations pour créer une extension
- performances : réimplémenter une partie critique avec un langage plus bas niveau
- réutilisation : donner accès à Python à une lib d'un autre langage

2 approches pour étendre python
- étendre avec Python's C API (et sans outils tiers)
	- très bas niveau
	- courbe d'apprentissage + longue
- étendre sans Python's C API ([[Cython]], cffi, SWIG, [[Numba]])

Cython
- https://cython.org/
- https://pypi.org/project/Cython/
- https://cython.readthedocs.io/en/latest/
- https://cython.readthedocs.io/en/latest/src/quickstart/index.html 🌟
- maintenu par [[Stefan Behnel]]
- "make writing C extensions for Python as easy as Python itself"
- superset of the Python language
	- at least aimed to
	- few limitations : http://docs.cython.org/en/latest/src/userguide/limitations.html


# Misc

- https://www.youtube.com/watch?v=FGdiSJakIS4
- [[Zen of Python]]
- Quelle est la façon standard de lever une exception `SystemExit` ? Appeler `sys.exit()`
- qu'est-ce qu'un idiome ? 


