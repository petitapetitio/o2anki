MOC : 
Source : [RFC1939](https://www.ietf.org/rfc/rfc1939.txt), [RFC2449](https://www.ietf.org/rfc/rfc2449.txt)
Projets :
Tags : 
Date : 2025-01-18
***

- depuis 1996
- attention : protocol largement répandu mais **obsolète**
- récupère les e-mails localement 
- fonctionne comme stack.pop() (par défaut, les clients suppriment les messages récupérés)
