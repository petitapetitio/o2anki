MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/fr/3/library/filecmp.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

- comparer deux fichiers ? 
	- `filecmp.cmp(f1, f2)` pour une comparaison superficielle (stats)
	- `filecmp.cmp(f1, f2, shallow=False)` pour une comparaison bit à bit
- comparer deux dossiers ? 
	- `filecmp.dircmp(d1, d2)`

pour des deltas plus précis, regarder du côté du [[module difflib]].
