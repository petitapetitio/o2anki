MOC : [[SOFTWARE ENGINEERING]]
Source : [[Zen of Python]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Complexité]]
Date : 2024-11-27
***

Ex dans [[$P - Tamis]] : faire tourner les tests d'intégration directement sur le cluster vs dans Gitlab.