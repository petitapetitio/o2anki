MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/glossary.html#term-parameter
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-24
***

On distingue 5 sortes de paramètres en python :
- [[Paramètre ordinaire (positionnel ou nommé)]]
- [[Marqueur positionnel-uniquement]]
- [[Paramètre var-positional (Collecteur d'arguments positionnels)]]
- [[Marqueur keyword-only (nommé uniquement)]]
- [[Paramètre var-keyword (Collecteur d'arguments nommés)]]

***
TARGET DECK: Python
FILE TAGS: paramètres

- STARTI [Basic] quel est le nom complet (pédant) de "paramètre" ? Back: paramètre formel <!--ID: 1730827064139--> ENDI
- STARTI [Basic] que décrivent les paramètres d'une fonction ? Back: Les arguments que la fonction accepte : <br>- nom <br>- type <br>- valeur par défaut éventuelle<br>- mode de passage (positionnel/nommé) <!--ID: 1730827064141--> ENDI
- STARTI [Basic] quelles sont les 5 modes de passage des paramètres ? Back: <br>positional-or-keyword `f(p)` <br>positional-only `f(p, /)` <br>keyword-only `f(*, p)` <br>var-positional `f(*args)` <br>var-keyword `f(**kwargs)`<!--ID: 1730827064143--> ENDI


START
Basic
Qu'affiche `f(1); f(2)` 
```python
def f(x, y=[]): 
	y.append(x)
	print(y)
	return y
```
?
Back:
`[1]`
`[1, 2]`
([[gotcha]])
<!--ID: 1730827064135-->
END


START
Basic
```python
def f(x, y=[]): 
	return id(y)
```
`f(1) == f(2)` 
?
Back:
Oui
<!--ID: 1730827064137-->
END
