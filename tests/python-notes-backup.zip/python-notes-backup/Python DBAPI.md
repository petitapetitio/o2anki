MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-11
***

- https://peps.python.org/pep-0249/
- connect
- Connection
	- commit
	- rollback
	- close (préco : close as soon as you're done with the DB, don't keep connections open)
	- cursor
- Cursor
	- execute
	- executemany
	- fetchall
	- fetchmany
	- fetchone
	- rowcount
- Exceptions
	- Error
	- Warning
- paramstyle
- factory functions
	- Binary
	- Date
	- DateFromTicks
	- Time
	- TimeFromTicks
	- Timestamp
	- TimestampFromTicks

Python DBAPI compliant modules
- https://wiki.python.org/moin/DatabaseInterfaces
- [pyodbc](https://pypi.org/project/pyodbc/) ([[Open Database Connectivity (ODBC)]])
- [mysql-connector-python](https://pypi.org/project/mysql-connector-python/) ([[MySQL]])
- [[psycopg]] ([[PostgreSQL]])
- [[module sqlite3]]
