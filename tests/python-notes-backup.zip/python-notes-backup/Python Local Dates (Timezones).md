- Comment créer une datetime avec une timzeone (aware datetime)
	- depuis une string
	- depuis le constructeur
- comment ajouter une timezone à une datetime sans TZ
- comment changer la timezone d'une date qui a déjà une TZ
- https://www.datacamp.com/tutorial/converting-strings-datetime-objects?dc_referrer=https%3A%2F%2Fwww.google.com%2F

```python
# approche avec les nouvelles versions de python 
# avec zoneinfo (peut nécessiter d'installer tzdata sur anciennes versions de Python)
datetime(2024, 9, 7, 14, 0, 0, 0, tzinfo=ZoneInfo("Europe/Paris"))

# approche avec les anciennes versions de python
pytz.timezone('Europe/Paris').localize(datetime(2024, 9, 7, 14, 0, 0))
```

- `datetime.fromisoformat("2021-12-06T02:00:00+01:00")` représente une heure UTC+1 hardcodée
- `pytz.timezone("Europe/Paris")` désigne la Timezone de Paris, c'est à dire
	- CET (Central European Time) l'hiver
	- CEST (Central European Summer Time) en été
- "CET" est UTC+1 en heure d'hiver
- "CEST" est UTC+1 en été

Ressources : 
- https://chat.openai.com/share/b09bf996-98f5-4373-9ecf-4e840b5d2ca6