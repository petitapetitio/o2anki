MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Base64]]
Date : 2025-01-19
***

- pour encoder en [[Base64]], base 32 ou base 16
- principales fonctions pour la base 64 :
	- `b64encode(s, altchars=None)` / `b64decode(s, altchars=None, validate=False)` 
	- `standard_b64encode(s)` (= `b64encode(s)`)
	- `urlsafe_b64encode(s)` (= `b64encode(s, '-_)`, pour passer la valeur dans une url)
###### Démo
```python
# Encodage
key = b'j\x9b~\xff'
base64.b64encode(key)           # b'apt+/w=='
base64.standard_b64encode(key)  # b'apt+/w==' (équivaut à b64encode)
base64.urlsafe_b64encode(key)   # b'apt-_w==' (+ et / remplacés par - et _)

# Décodage
base64.b64decode("abcd") # b'i\xb7\x1d'
base64.b64decode("abc?d", validate=True) # Erreur
base64.b64decode("abc?d") # b'i\xb7\x1d' : caractères invalides ignorés par défaut
```
