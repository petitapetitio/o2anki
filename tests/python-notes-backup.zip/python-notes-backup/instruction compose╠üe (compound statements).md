MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/compound_stmts.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

Une instruction composée (compound statement) est une instruction qui contient une ou plusieurs autres instructions et affecte ou contrôle leur flux exécution. Une instruction composée possède une ou plusieurs [[clause (d'instruction composée)]].

Exemple - l'instruction `if` est une instruction composée : 
```python
captcha = input("Combien font 4 + 3 ?")
if captcha == "7":
	print("Bien joué")
```

```python
def http_error(error_status):
    match error_status:
        case 400:
            return "erreur 400"
        case 404:
            return "une 404"
        case _:
            return "Something's wrong with internet"
```



***
TARGET DECK: Python
FILE TAGS: lexical-structure instructions

- STARTI [Basic] Quelle est la traduction anglaise d'instruction composée ? Back:  compound statement <!--ID: 1728727115371--> ENDI
- STARTI [Basic] Qu'est-ce qu'une instruction composée ? Back:  une instruction qui contient d'autres instructions. Ex : [[instruction conditionnelle if]], [[instruction def]], ... <!--ID: 1728727115373--> ENDI
- STARTI [Basic] Est-ce qu'une instruction composée peut tenir sur une seule ligne ? Back:  Oui : `if x: print(x)`  <!--ID: 1728727115375--> ENDI
- STARTI [Basic] Est-ce que l'instruction composée présentée une seule ligne physique `if True: msg = "hello"; print(msg)`  est valide ? Back: Oui. La suite peut être mise directement après le symbole ":" lorsqu'elle est constituée d'instructions simples. <!--ID: 1727542890080--> ENDI
- STARTI [Basic] Est-ce que l'instruction composée présentée sur une seule ligne physique  `if c1: if c2: print(x)`  est valide ? Back: Non. La suite doit être placée dans un bloc indenté si elle comporte une instruction composée. <!--ID: 1727542890082--> ENDI
- STARTI [Basic] Quel problème poserait la syntaxe sur une seule ligne physique `if c1: if c2: print(x)` Back: Cette structure crée une ambiguïté si on ajoute un `else` : `if c1: if c2: print(x); else: print(y)`. On ne sait pas à quel `if` correspond le `else`. <!--ID: 1728329117642--> ENDI