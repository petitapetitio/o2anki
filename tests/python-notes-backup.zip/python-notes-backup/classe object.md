MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-28
***


***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] quels types héritent de `object` ? Back: Tous les objets python : les types natifs comme les classes utilisateur. <!--ID: 1730827064305--> ENDI
- STARTI [Basic] à quoi peut servir d'instancier `object()` ? Back:  obtenir une sentinelle qui compare inégale à tout objet distinct. <!--ID: 1730827064308--> ENDI
