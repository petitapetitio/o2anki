MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

**1991**
[[Guido van Rossum]] publie Python en version beta. Cette version incluait déjà les classes, l'héritage, la gestion des exceptions, les fonctions et les types fondamentaux.

**1994**
La version 1.0 est publiée. Elle introduit des features comme les expressions lambda, filter, map

**2000**
[Python 2.0](https://docs.python.org/3/whatsnew/2.0.html#) est publié. Elle introduit des features comme les listes par compréhension, les assignations augmentées (+=), et le garbage collector.

**2008** 
Python 3.0 est publié.

**2010**
The Zen of Python est publié.

**2020**
Le support de Python 2 est officiellement arrêté. La transition aura durée 10 ans !

**2022**
Python devient le plus populaire au monde selon l'index TIOBE ? Cette popularité s'explique notamment par son utilisation en data science.

**Pour quelle année est prévu Python 4 ?** 
Il n'est pas prévu de version 4 à l'heure actuelle - le passage de la version 2 à la version 3 a montré que travailler avec de petits incréments est plus simple à gérer.


***
TARGET DECK: Python

- STARTI [Basic] Qui a créé Python ? Back: [[Guido van Rossum]] (le guide dans un van rose) <!--ID: 1727542890118--> ENDI
- STARTI [Basic] En quelle année est-ce que python a été créé Back: 1991 (L'année avant ma naissance) <!--ID: 1727542890120--> ENDI
- STARTI [Basic] En quelle année a été publiée la version 3.0 ? Back: 2008 <!--ID: 1727542890122--> ENDI

Posts 
- [[$A - Python en 7 dates clés]]