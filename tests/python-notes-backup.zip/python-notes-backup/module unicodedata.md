MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/fr/3/library/unicodedata.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: strings

- lookup
	- STARTI [Basic]  `unicodedata.lookup('LEFT CURLY BRACKET')` ? Back:  `'{'` <!--ID: 1734713099679--> ENDI
	- STARTI [Basic]  le symbole qui a le nom unicode `'PICK'` ? Back:  `'\N{PICK}'` ou `unicodedata.lookup('PICK')` <!--ID: 1734713099681--> ENDI
- name
	- STARTI [Basic]  le nom unicode de `'⛏️'` ? Back:  `unicodedata.name('⛏️'[0])` <br>(⛏️ est composé de l'emoji `'PICK'` et du variation selector `'VARIATION SELECTOR-16'`) <!--ID: 1734713099682--> ENDI
	- STARTI [Basic]  le nom unicode de `'/'` ? Back:  `unicodedata.name('/')` <br>(`'SOLIDUS'`) <!--ID: 1734713099683--> ENDI
- numeric
	- STARTI [Basic]  la valeur numérique de `'①'` ? Back:  `unicodedata.numeric('①')` <br>(`1.0`) <!--ID: 1734713099684--> ENDI

