MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-24
***

La partie complémentaire à la définition de fonction. ([[instruction def]])

[[argument]]

***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] quelle est la syntaxe d'un appel de fonction ? Back:  `function_object(arguments)` <br>où <br>- `function_object` est une référence à un objet fonction, <br>- les parenthèses sont l'opérateur d'appel de fonction <br>- `arguments` est une série d'expressions séparées par des virgules. <!--ID: 1729754351999--> ENDI
