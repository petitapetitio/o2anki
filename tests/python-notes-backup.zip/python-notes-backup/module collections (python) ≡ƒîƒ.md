MOC : 
Source :
Projets :
Tags : [[Python|Python]]
Date : 2024-10-03
***

https://docs.python.org/3/library/collections.abc.html#collections-abstract-base-classes

Module : `collections.abc`

Missing sur le schéma : 
- Callable (`__call__`)
- Hashable (`__hash__`)

![[Collection (python)-1.png]]
- La ligne en pointillés sépare les méthodes abstraites des mixins.
- Certains ABC contiennent du comportement et sont + que des interfaces
- Les relations d'héritage me semblent OK mais j'ai détecté des écarts au niveau des mixins listées dans cette image et dans Python in a nutshell. Par exemple pour Mapping, au niveau de `__ne__` et `getitems` : ![[3 RESSOURCES/The developer's brain/Notes/Python/_assets/Collections abc (python) 🌟-1.png]]


***
TARGET DECK: Python
FILE TAGS: collections

- STARTI [Basic] collections : quelles interfaces composent l'interface `Collection` ? Back:  <br>- `Iterable`  (`__iter__`)<br>- `Container` (`__contains__`)<br>- `Sized` (`__len__`)<!--ID: 1729447957631--> ENDI
- STARTI [Basic] collections : quels sont les 3 interfaces principales qui héritent de `Collection` ? Back:  `Sequence`, `Mapping` et `Set` <!--ID: 1729447957646--> ENDI
- STARTI [Basic] collections : quels sont les 3 interfaces built-in qui héritent de `Iterable` ? Back:  `Iterator`, `Reversible` et `Collection` <!--ID: 1729447957653--> ENDI
- STARTI [Basic] collections : quelle méthode spéciale définit un `Iterable` ? Back:  `__iter__` <!--ID: 1729447957657--> ENDI
- STARTI [Basic] collections : quelle méthode spéciale définit un `Container` ? Back:  `__contains__` <!--ID: 1729447957663--> ENDI
- STARTI [Basic] collections : quelle méthode spéciale définit un `Sized` ? Back:  `__len__` <!--ID: 1729447957666--> ENDI
- collections : qu'est-il possible d'appeler sur un`Iterable` ? `iter(obj)`
- collections : qu'est-il possible d'appeler sur un`Container` ? `x in obj`
- collections : qu'est-il possible d'appeler sur un `Sized` ? `len(obj)`


Pour vérifier : 
```python
from collections.abc import Collection, Mapping, Sequence, Set, Reversible, Iterator, Generator  
  
print("Collection", Collection.__bases__)  
print("Sequence", Sequence.__bases__)  
print("Mapping", Mapping.__bases__)  
print("Set", Set.__bases__)  
print("Reversible", Reversible.__bases__)  
print("Iterator", Iterator.__bases__)  
print("Generator", Generator.__bases__)
```
