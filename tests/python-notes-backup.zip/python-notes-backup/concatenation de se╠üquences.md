MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***

***
TARGET DECK: Python
FILE TAGS: std-functions

- STARTI [Basic] Comment concaténer deux séquences du même type `s1` et `s2` ? Back:  `s1 + s2` <!--ID: 1728627767386--> ENDI
- STARTI [Basic] `(4, 2) + (2, 6)` ? Back:  `(4, 2, 2, 6)` (et pas `(6, 8)` !)  ([[gotcha]]) <!--ID: 1728627767390--> ENDI
