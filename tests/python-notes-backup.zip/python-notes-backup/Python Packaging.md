Ressources :
- https://packaging.python.org
- [[PEP 517]]
- [[PEP 518]]



Outils
- [[Poetry]]
- [[flit]]
- [[hatch]]
- [[UV]]
- Liste des packaging tools maintenue par [[Python Packaging Authority (PyPA)]] : https://packaging.python.org/en/latest/key_projects/

Concepts
- https://packaging.python.org/en/latest/glossary
- [[build frontend]]
- [[build backend]]