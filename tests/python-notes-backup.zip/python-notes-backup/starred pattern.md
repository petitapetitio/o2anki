MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***

***
TARGET DECK: Python
FILE TAGS: destructuring

- STARTI [Basic] Qu'est-ce qu'un starred pattern ? Back:  <br>Un motif de [[destructuration]] qui permet soit : <br>- de capturer plusieurs éléments dans une list avec `*name` <br>- d'ignorer plusieurs éléments avec `*_`<!--ID: 1728727115342--> ENDI
