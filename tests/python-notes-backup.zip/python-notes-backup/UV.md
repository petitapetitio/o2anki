MOC : [[SOFTWARE ENGINEERING]]
Source : 
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-29
***


Est une alternative (rapide !) à [[pyenv]] et à [[Poetry]].