MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- https://en.wikipedia.org/wiki/Producer%E2%80%93consumer_problem
- https://realpython.com/intro-to-python-threading/#producer-consumer-using-queue

Solution manuelle deux [[threading.Lock]] avec un cache de 1 élément 
```python
import logging
import threading
from concurrent.futures import ThreadPoolExecutor

SENTINEL = object()


class Pipeline:
    def __init__(self):
        self.message = 0
        self.producer_lock = threading.Lock()
        self.consumer_lock = threading.Lock()
        self.consumer_lock.acquire()

    def get_message(self):
        logging.debug("Consumer about to acquire consumer_lock")
        self.consumer_lock.acquire()
        logging.debug("Consumer have consumer_lock")
        message = self.message
        logging.debug("Consumer about to release producer_lock")
        self.producer_lock.release()
        logging.debug("Consumer released producer_lock")
        return message

    def set_message(self, message):
        logging.debug("Producer about to acquire producer_lock")
        self.producer_lock.acquire()
        logging.debug("Producer have producer_lock")
        self.message = message
        logging.debug("Producer about to release consumer_lock")
        self.consumer_lock.release()
        logging.debug("Producer released consumer_lock")


def producer(pipeline: Pipeline):
    for index in range(5):
        message = index
        logging.info("Produce : create message %s", message)
        pipeline.set_message(message)

    # Send a sentinel message to tell consumer we're done
    pipeline.set_message(SENTINEL)


def consumer(pipeline: Pipeline):
    message = 0
    while message is not SENTINEL:
        message = pipeline.get_message()
        if message is not SENTINEL:
            logging.info("Consumer : store message %s", message)


if __name__ == "__main__":
    logging.basicConfig(format="%(asctime)s: %(message)s", level=logging.INFO, datefmt="%H:%M:%S")
    # logging.getLogger().setLevel(logging.DEBUG)

    p = Pipeline()
    with ThreadPoolExecutor(max_workers=2) as executor:
        executor.submit(producer, p)
        executor.submit(consumer, p)

# run example 
# 13:49:26: Producer : message 0  
# 13:49:26: Producer : message 1  
# 13:49:26: Consumer : store message 0  
# 13:49:26: Producer : message 2  
# 13:49:26: Consumer : store message 1  
# 13:49:26: Producer : message 3  
# 13:49:26: Consumer : store message 2  
# 13:49:26: Producer : message 4  
# 13:49:26: Consumer : store message 3  
# 13:49:26: Consumer : store message 4
```

Solution avec le [[module queue (A synchronized queue class)]] et [[threading.Event]]
```python
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from queue import Queue


def producer(queue: Queue, event: threading.Event):
    index = 0
    while not event.is_set():
        message = index
        logging.info("Producer : message %s", message)
        queue.put(message)
        index += 1

    logging.info("Producer received EXIT event. Exiting")


def consumer(queue: Queue, event: threading.Event):
    while not event.is_set() or not queue.empty():
        message = queue.get()
        logging.info("Consumer : store message %s (queue size=%s)", message, queue.qsize())


if __name__ == "__main__":
    logging.basicConfig(format="%(asctime)s: %(message)s", level=logging.INFO, datefmt="%H:%M:%S")

    q = Queue(5)
    e = threading.Event()
    with ThreadPoolExecutor(max_workers=2) as executor:
        executor.submit(producer, q, e)
        executor.submit(consumer, q, e)

        time.sleep(0.0001)
        logging.info("Main: about to set event")
        e.set()

# 14:14:28: Producer : message 0
# 14:14:28: Producer : message 1
# 14:14:28: Producer : message 2
# 14:14:28: Producer : message 3
# 14:14:28: Producer : message 4
# 14:14:28: Producer : message 5
# 14:14:28: Consumer : store message 0 (queue size=4)
# 14:14:28: Producer : message 6
# 14:14:28: Consumer : store message 1 (queue size=4)
# 14:14:28: Producer : message 7
# 14:14:28: Consumer : store message 2 (queue size=4)
# 14:14:28: Producer : message 8
# 14:14:28: Consumer : store message 3 (queue size=4)
# 14:14:28: Producer : message 9
# 14:14:28: Consumer : store message 4 (queue size=4)
# 14:14:28: Main: about to set event
# 14:14:28: Producer : message 10
# 14:14:28: Consumer : store message 5 (queue size=4)
# 14:14:28: Producer received EXIT event. Exiting
# 14:14:28: Consumer : store message 6 (queue size=4)
# 14:14:28: Consumer : store message 7 (queue size=3)
# 14:14:28: Consumer : store message 8 (queue size=2)
# 14:14:28: Consumer : store message 9 (queue size=1)
# 14:14:28: Consumer : store message 10 (queue size=0)

```
