MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/operator.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Notions de base du développement]]
Date : 2024-09-28
***

Exemple :
![[python-operators.png]]


***
TARGET DECK: Python
FILE TAGS: lexical-structure

- STARTI [Basic] Qu'est-ce qu'un opérateur ? Back: Un symbole qui permet d'effectuer des opérations sur des valeurs (appelées opérandes). <!--ID: 1727542890038--> ENDI
- STARTI [Basic] Quels sont les opérateurs arithmétiques ? Back: `+`, `-`, `*`, `/`, `%`, `**`, `//`. L'opérateur `@` est un opérateur spécial utilisé par NumPy pour la multiplication matricielle mais ne fait pas partie des opérateurs arithmétiques. <!--ID: 1727542890043--> ENDI
- STARTI [Basic] Quels sont les opérateurs de comparaison ? Back: "\==", `!=`, `>`, `<`, `>=`, `<=` <!--ID: 1727542890045--> ENDI
- STARTI [Basic] Quels sont les opérateurs logiques ? Back: `and`, `or`, `not` <!--ID: 1727542890047--> ENDI
- STARTI [Basic] Quels sont les opérateurs bit à bit ? Back: `&`, `|`, `^`, `~` <!--ID: 1727542890052--> ENDI
- STARTI [Basic] Quels sont les opérateurs d'affectation ? Back: "=", `+=`, `-=`, `*=`, `/=`, `%m`, `**=`, `//=` et `:=` ([[expression d'affectation (Walrus operator)]]) <!--ID: 1727542890055--> ENDI
- STARTI [Basic] Quels sont les opérateurs d'appartenance ? Back: `in`, `not in` <!--ID: 1727542890057--> ENDI
- STARTI [Basic] Quels sont les opérateurs d'identité ? Back: `is`, `is not` <!--ID: 1727542890059--> ENDI
- STARTI [Basic] Quels sont les opérateurs unaires ? Back: `-x`, `+x`, `~x` <!--ID: 1727542890061--> ENDI
- STARTI [Basic] Qu’est-ce qu’un opérateur unaire ? Back: un opérateur qui a une seule opérande. Ex: `-x` <!--ID: 1730827064375--> ENDI
- STARTI [Basic] Qu’est-ce qu’un opérateur binaire ? Back: un opérateur qui a deux opérandes. Ex : `a + b` <!--ID: 1730977135847--> ENDI

START
Basic
Quelles sont les grandes familles d'opérateurs ?
Back:
1. Opérateurs d'affectation
2. Opérateurs d'appartenance
3. Opérateurs arithmétiques 
4. Opérateurs bit à bit
5. Opérateurs de comparaison
6. Opérateurs d'identité
7. Opérateurs logiques
<!--ID: 1730827064373-->
END