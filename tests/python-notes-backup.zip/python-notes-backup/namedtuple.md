MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/collections.html#collections.namedtuple
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[module collections (python) 🌟]]
Date : 2024-11-04
***

***
TARGET DECK: Python
FILE TAGS: collections

START
Basic
qu'est-ce qu'un `namedtuple` ?
Back:
Un [[tuple]] dont les champs sont accessibles par nom (comme des attributs) en plus d'être indexables. Ex : 
```python
Point = namedtuple('Point', ['x', 'y'])  
p = Point(100, 200)  
assert p.x == p[0]
```
<!--ID: 1730827063761-->
END

- STARTI [Basic] Quelles méthodes spéciales sont générées pour un namedtuple ? Back:  `__repr__`, `__eq__`, `__hash__` <!--ID: 1730827063764--> ENDI
- STARTI [Basic] Quelles méthodes d'instance sont générées pour un namedtuple ? Back:  <br> `_asdict()` (conversion en dict), <br>`_replace()` (création d'une nouvelle instance avec modifications) <br>`_fields` (tuple des noms de champs) <!--ID: 1730827063767--> ENDI
- STARTI [Basic] Quand préférer un `namedtuple` à une `dataclass` ? Back:  <br>1) Quand l'interopérabilité avec les tuples est souhaitée (indexation, unpacking) <br>2) Pour minimiser l'utilisation mémoire (pas de `__dict__`) <br>3) Pour des données simples, immuables et sans besoins de personnalisation <!--ID: 1730827063770--> ENDI


```python
Point = namedtuple('Point', ['x', 'y'])
p = Point(11, y=22)     # instantiate with positional or keyword arguments
p[0] + p[1]             # indexable like the plain tuple (11, 22)
x, y = p                # unpack like a regular tuple
p.x + p.y               # fields also accessible by name
p                       # readable __repr__ with a name=value style
Point(x=11, y=22)
```