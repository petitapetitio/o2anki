MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/expressions.html#subscriptions
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Notions de base du développement]]
Date : 2024-10-04
***

- an indexing is an index applied to a container

Traduction
- indiçage = indexing
- sélection = subscription

***
TARGET DECK: Python
FILE TAGS: indexing

- STARTI [Basic] Qu'est-ce qu'une sélection ? Back: Une [[expression|expression]] qui permet de référencer un ou plusieurs éléments d'un conteneur. <br>Par exemple : <br>- `s[0]`<br>- `x[1] = 2`<br>- `x[1:3] = [0]`<br>- `d['key']` <!--ID: 1728239137837--> ENDI
- Quelles sont les trois types d'indices les plus courants ? <br>- `s[0]` : [[entier (int)]] pour les séquences <br>- `d['key']` : [[str (chaîne de caractères)]] pour les mappings <br>- `s[1:2]` : [[tranchage (slicing)]] pour les séquences
- STARTI [Basic] à quels objets s'applique la selection (subscription) ? Back: <br>- aux [[sequence]]s<br>- aux [[mapping]]s<br>- à tout objet qui implémente `__getitem__` <!--ID: 1728239137840--> ENDI
- STARTI [Basic] indexing : `[0, 1, 2, 3][1]` ? Back:  `1` <!--ID: 1728627767727--> ENDI
- STARTI [Basic] indexing : `[0, 1, 2, 3][-1]` ? Back:  `3` <!--ID: 1728627767731--> ENDI
- STARTI [Basic] indexing : `[0, 1, 2, 3][100]` ? Back:  `IndexError: list index out of range` <!--ID: 1728627767735--> ENDI
- STARTI [Basic] indexing : `[0, 1, 2, 3][-100]` ? Back:  `IndexError: list index out of range` <!--ID: 1728627767740--> ENDI
- STARTI [Basic] À quoi fait référence `x[i]` ? Back: à l'élément associé à l'index `i` dans l'objet conteneur référencé par le nom `x`. <!--ID: 1728036834571--> ENDI
- STARTI [Basic] À quoi fait référence `x[key]` ? Back:  à l'élément associé à la clé `key` dans l'objet de type mapping référencé par le nom `x`. <!--ID: 1728036834569--> ENDI

