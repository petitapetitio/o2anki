MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-13
***

https://docs.python.org/3/library/statistics.html

```python
print(statistics.mean([1, 1, 5, 5]))               # 3
print(statistics.median([1, 1, 2, 8, 8]))          # 2
print(statistics.kde([1, 1, 2, 8, 8], h=1.5)(1.5)) # 0.15096218997383612
```
