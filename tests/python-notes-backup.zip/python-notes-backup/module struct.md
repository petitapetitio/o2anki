MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

- convertir des données pythons en valeurs [[C]], en [[bytes]]
- applications ? 
	- échange de données entre du code python et du code [[C]] 
	- échange de données entre apps qui se sont accordées sur le format
- ressources
	- https://docs.python.org/3/library/struct.html
	- https://docs.python.org/fr/3.13/library/struct.html#format-characters


Exemple
```python
from struct import pack, unpack, calcsize

format = '>bhl'  # big-endian, signed char, short, long
pack(format, 1, 2, 3) # b'\x01\x00\x02\x00\x00\x00\x03'
unpack(format, b'\x01\x00\x02\x00\x00\x00\x03')  # (1, 2, 3)
calcsize(format)  # 7

pack("b", 100000)  # error("'b' format requires -128 <= number <= 127")
```