MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/profile.html#module-pstats
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-17
***

- analyser, consolider et afficher les fichiers produits par le [[modules profile et cProfile (The Python Profilers)]]
