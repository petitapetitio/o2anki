MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/shelve.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[serialization]]
Date : 2025-01-11
***

Orchestre le [[module pickle (Python object serialization)]] et le [[module dbm (Interfaces to Unix “databases”)]].

Example
```python
import shelve


class ComplexObject:
    def __init__(self):
        self.data = [1, 2, 3]

# Ecriture
with shelve.open('data') as db:
    db['my_object'] = ComplexObject()  # Stockage direct d'objets Python


# Lecture
with shelve.open('data') as db:
    obj = db['my_object']
    print(type(obj), obj.data)  # <class '__main__.ComplexObject'> [1, 2, 3]

```

- la différence avec [[module json (JSON encoder and decoder)]] est que `shelve` permet de stocker des objets spécifiques à Python (comme des instances de class personnalisées)
- la différence avec [[module pickle (Python object serialization)]] est que `shelve`permet un accès sélectif par clé (tandis qu'avec pickle on charge tout d'un coup)
