MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

On appelle *continuation line* les [[ligne physique]] qui viennent après la première ligne physique dans une même [[ligne logique]]. Les règles d'indentation ne s'appliquent pas à ces ligne.
