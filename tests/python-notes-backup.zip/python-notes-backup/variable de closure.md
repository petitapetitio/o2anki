MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/glossary.html#term-closure-variable
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-25
***

Exemple 
```python
def outer():
    x = 10
    def inner():
        print(x)
    return inner

closure = externe()
closure()  # fait appel à la variable de closure `x`
```

***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] Qu'est-ce qu'une variable de closure ? Back: Une variable d’une fonction englobante utilisée par une fonction interne (même après que la fonction englobante a terminé) <!--ID: 1730827064123--> ENDI

