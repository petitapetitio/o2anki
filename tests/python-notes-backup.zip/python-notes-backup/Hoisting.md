MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-17
***

- l'accès à une variable locale est plus rapide que la résolution de méthode ![[Python in a Nutshell-6.png]]
- l'accès aux variables locales est plus rapide que l'accès aux variables globales ![[Python in a Nutshell-5.png]]
