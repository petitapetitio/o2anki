MOC : [[SOFTWARE ENGINEERING]]
Source : [[Younes]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-29
***

Code des outils pour l'écosystème Python en Rust : 
- [[RUFF (fast linter)]]
- [[UV]]