MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/os.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

###### recipes
- savoir si on est sur Windows ou un système unix (mac, linux) ? `os.name` (vaut `nt` pour windows, `unix` pour mac et linux)
- `'file.txt'` accessible en écriture ? `os.access('file.txt', os.W_OK)`
- se déplacer dans le répertoire parent ? `os.chdir('..')`
- autoriser uniquement l'accès en lecture et écriture au propriétaire et au groupe à `'f.txt'` ? `os.chmod('f.txt', 0o660)` ([[permission bits]])
- le répertoire courant ? `os.getcwd()` 
- créer un dossier `test` ? `os.mkdir('test')`
- créer un dossier `x/y/z` ? `os.makedirs('x/y/z')`
- supprimer `f.txt` ? `os.remove('f.txt')` ou `os.unlink('f.txt')`

Comment parcourir l'arborescence de fichiers 
```
walk
├── 1.txt
├── d1
│   └── a.txt
└── d2
    └── a.txt
```
de façon topdown ? 
```python
for x in os.walk('walk'):
    print(x)

# ('walk', ['d1', 'd2'], ['1.txt'])
# ('walk/d1', [], ['a.txt'])
# ('walk/d2', [], ['a.txt'])
```
