MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags :
Date : 2025-01-14
***

[[process]] and [[thread]] scheduling is preemptive.
[[programmation asynchrone]] is cooperative.
