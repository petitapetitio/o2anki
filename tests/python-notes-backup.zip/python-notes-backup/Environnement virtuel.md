MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://peps.python.org/pep-0405/
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

Solutions
- [[venv]]
- [[virtualenv]] ⭐️
- [[pipenv]]

***
TARGET DECK: Python
FILE TAGS: packaging

- STARTI [Basic] Qu'est-ce qu'un environnement virtuel ? Back:  Un environnement Python isolé (interpréteur + packages) que l'on peut activer ou désactiver à la demande.  <!--ID: 1731677487793--> ENDI
- STARTI [Basic] Quels sont les principaux intérêts d'un environnement virtuel ? Back:  <br>- Isoler les dépendances entre projets pour éviter les conflits de version<br>- Faciliter la reproduction de l'environnements de développement <br>- Éviter de polluer l'installation Python du système <!--ID: 1731677487794--> ENDI
- STARTI [Basic] Quels sont les principaux outils pour créer des environnements virtuels Python ? Back:  <br>[[venv]] (bibliothèque standard) <br>[[virtualenv]], [[Poetry]], [[UV]], [[conda]], [[pipenv]] <!--ID: 1731677487795--> ENDI
- STARTI [Basic] Que contient le dossier `bin` d'un environnement virtuel ? Back: <br>- Un interpréteur Python <br>- les scripts d'activation de l'environnement virtuel <br>- les outils standalones installés avec [[pip]] (comme [[black]], [[mypy]]) <!--ID: 1731677487796--> ENDI
- STARTI [Basic] Où sont installées les bibliothèques dans un environnement virtuel ? Back: Dans le dossier `lib/python3.x/site-packages` <!--ID: 1731677487797--> ENDI
- STARTI [Basic] Quel package est pré-installé dans un nouvel environnement virtuel ? Back: [[pip]] <br>![[Environnement virtuel-1.png]]<br>(easy-install, pkg_resources et [[setuptools]] ne sont plus pré-installés) <br><!--ID: 1731677487798--> ENDI
- STARTI [Basic] Est-ce qu'un environnement virtual modifie `PYTHONPATH` et `PYTHONHOME` ? Back:  Non <!--ID: 1731677487799--> ENDI
- STARTI [Basic] Comment nommer un environnement virtuel ? Back:  `<projet>_<python-version>`. Ex : `tamis_310`. Permet une identification claire de l'environnement actif dans le shell. <!--ID: 1731677487800--> ENDI
- STARTI [Basic] Est-ce qu'un environnement virtuel est lié à un projet particulier ? Back: Pas nécessairement - même si c'est souvent le cas en pratique. <!--ID: 1731677487741--> ENDI
- STARTI [Basic] Où placer l'environnement virtuel ? Back:  En dehors du projet. Par exemple dans `~/.venvs/`<br><br>Avantages : <br>1) pas besoin de l'ignorer dans le `.gitignore` (A VERIFIER : Est-ce que je peux quand même accéder au code source des libs de cette façon ?) <br>2) clarifie les recherches dans le code source ? (à tester) <br>3) il est plus simple de recréer le projet si git est corrompu <!--ID: 1731677487801--> ENDI
