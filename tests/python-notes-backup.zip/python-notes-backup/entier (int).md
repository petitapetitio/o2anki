MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***


***
TARGET DECK: Python
FILE TAGS: stdtypes

- STARTI [Basic] Quels sont les 4 types de littéraux entiers ? Back: décimal, binaire, octal ou hexadécimal. <!--ID: 1727939491311--> ENDI
- STARTI [Basic] Quelle est la structure d'un littéral entier décimal ? Back: une suite de chiffres qui commence par un chiffre différent de zéro. Par exemple `42`. <!--ID: 1727939491318--> ENDI
- STARTI [Basic] Quelle est la structure d'un littéral binaire ? Back: `0b` suivi d'une séquence de chiffres `0` ou `1`. Par exemple `0b101`. <!--ID: 1727939491321--> ENDI
- STARTI [Basic] Comment écrire `6` avec un littéral binaire ? Back: `0b110` <!--ID: 1727939491325--> ENDI
- STARTI [Basic] Quelle est la structure d'un littéral octal ? Back: `0o` suivi d'une séquence de chiffres allant de `0` à `7`. Par exemple `0o11` pour représenter neuf. <!--ID: 1727939491329--> ENDI
- STARTI [Basic] Comment écrire `9` avec un littéral octal ? Back: `0o11` <!--ID: 1727939491334--> ENDI
- STARTI [Basic] Quelle est la structure d'un littéral hexadécimal ? Back: `0x` suivi d'une séquence de chiffres hexadécimaux  (`0-9|a-f|A-F`) <!--ID: 1727939693731--> ENDI
- STARTI [Basic] Comment écrire `10` avec un littéral hexadécimal ? Back: `0xA` ou `0xa` <!--ID: 1727939491341--> ENDI
- STARTI [Basic] Comment écrire `21` avec un littéral hexadécimal ? Back: `0x15` <!--ID: 1727939491345--> ENDI
- STARTI [Basic] Quelle est la valeur maximale d'un entier en python 3 ? Back: Les entiers ne sont pas limités. <!--ID: 1727939491350--> ENDI
