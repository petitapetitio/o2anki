Date : 2023-11-22
***

- Web Application Framework pour [[Python]]
- Designé pour être stateless
- Basé sur le modèle de [[Programmation réactive]]
- Concepts importants
	- Callbacks
		- est composé de 3 éléments : Input, Output, State
		- la callback est déclenchée dès qu'une propriété déclarée comme une Input est modifiée
		- il est possible de déclarer plusieurs Inputs, plusieurs Outputs, plusieurs State
	- State
		- permet de récupérer l'état d'une propriété sans que la callbacks soit déclenchée lorsque la valeur change
	- Layout
		- décrit à quoi l'app ressemble (partie HTML)
		- est constitué d'une hiérarchie de composants
	- Composants 
		- les blocs de construction de l'interface
		- a plusieurs propriétés
		- Bibliothèques
			- The Dash HTML Components : composants html de base (a, p, ...)
			- Dash core components (dcc) : composants bas niveau built-in
			- Dash design kit (ddk) : composants haut niveau développé par Dash (payants)
			- Dash bootstrap components (dbc) : composants maintenus par la communauté
		- Tips
			- utiliser des fonctions pures pour créer des composants réutilisables
			- le composant Markdown permet d'afficher du texte au format Markdown :)
	- [[Dash Basic Auth]]
- Points de vigilance
	- Ne pas utiliser de variables globales : 
		- cela affecte les sessions des autres utilisateurs
		- lorsque tu as plusieurs workers, rien ne garanti que ta prochaine requête va s'exécuter sur le même worker
	- 3 options pour stocker de la données
		- dans la session de navigation de l'utilisateur avec dcc.Store
- [[Comment gérer un site multi-pages avec Dash]]


- Ressources : 
	- https://dash.plotly.com/ (user guide)
	- https://dash.plotly.com/reference (reference)
	- https://dash.plotly.com/dash-html-components#full-elements-reference
	- https://dash.plotly.com/dash-core-components (preview des core components)
	- https://dash-bootstrap-components.opensource.faculty.ai/docs/components/
	- https://plotly.com/python/
	- [Clean architecture with Dash](https://towardsdatascience.com/clean-architecture-for-ai-ml-applications-using-dash-and-plotly-with-docker-42a3eeba6233) +  [repo](https://github.com/CzakoZoltan08/dash-clean-architecture-template) (highly deprecated)
	- [[Déploiement et lancement du Dash sur JO classique]]
	- https://github.com/ucg8j/awesome-dash



###### Callbacks de pattern matching avancées

Etant donné un id complexe comme
```python
html.Div(id={"type": "city-filter-dropdown", "index": 1})
html.Div(id={"type": "city-filter-dropdown", "index": 2})
```

Les callbacks se font sous forme de pattern-matching : 
```python
Input({"type": "city-filter-dropdown", "index": ALL}, "value")
```

Comment cela se matérialise dans le HTML ?
```html
<div id='{"type":"city-filter-dropdown","index":1}'></div>
<div id='{"type":"city-filter-dropdown","index":2}'></div>
```