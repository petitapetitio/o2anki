MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[internationalization (i18n)]]
Date : 2025-01-11
***

- https://docs.python.org/3/library/gettext.html
- inspiré par [GNU gettext](https://www.gnu.org/software/gettext/)

see `tools/i18n/pygettext.py` too extract the program's messages
tuto : https://phrase.com/blog/posts/translate-python-gnu-gettext/
