MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/reference/compound_stmts.html#as-patterns
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***


***
TARGET DECK: Python
FILE TAGS: match

- STARTI [Basic] pattern-matching : à quoi sert un **as pattern** ? Back:  À capturer la valeur matchée par un pattern pour la réutiliser dans la garde ou dans la suite de la clause.  <br>- ex avec un [[pattern alternatif (or pattern)]] : `(10 | 20) as x` <br>- ex avec un [[pattern de séquence]] : `("root", ("node", _) as left)` <br><!--ID: 1728727115329--> ENDI
- STARTI [Basic] pattern-matching : comment construire un *as pattern* à partir de `p1` ? Back:  `p1 as name` <!--ID: 1728727115331--> ENDI
- STARTI [Basic] pattern-matching : comment se déroule `p1 as x` ? Back:  si `p1` est matché, python lie la valeur matchée au nom `x` dans l'espace de nom local <!--ID: 1728727115333--> ENDI
- STARTI [Basic] Est-ce que la ligne `case ((0 | 1) as x) | 2: print(x)` est valide ? Back:  Non car il n'est pas garanti que `x` existe dans la suite. Ce code entraîne une `SyntaxError`. <!--ID: 1728727115334--> ENDI
- STARTI [Basic] Est-ce que la ligne `case (1 | 2 | 42) as x: print(x)` est valide ? Back:  Oui. <!--ID: 1728727115336--> ENDI

START
Basic
Qu'affiche
```python
match ("node", ("leaf", 1)):  
	case ("node", ("node", _) as n):  
		print(f"node : {n}")
	case ("node", ("leaf", _) as l):  
		print(f"leaf : {l}")
```
?
Back:  
`leaf : ('leaf', 1)`
<!--ID: 1728729591971-->
END