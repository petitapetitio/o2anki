MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: strings

- String constants
	- https://docs.python.org/3/library/string.html#string-constants
	- STARTI [Basic] les lettres ascii ? Back:  `string.ascii_letters` <!--ID: 1734713099691--> ENDI
	- STARTI [Basic] les lettres ascii minuscules ? Back:  `string.ascii_lowercase` <!--ID: 1734713099692--> ENDI
	- STARTI [Basic] les lettres ascii minuscules ? Back:  `string.ascii_uppercase` ENDI
	- STARTI [Basic] les caractères digits ? Back:  `string.digits` <!--ID: 1734713099693--> ENDI
	- STARTI [Basic] les caractères hexa ? Back:  `string.hexdigits` <!--ID: 1734713099694--> ENDI
	- STARTI [Basic] les caractères de ponctuation ascii ? Back:  `string.punctuation` <!--ID: 1734713099695--> ENDI
	- STARTI [Basic] les caractères de type espace ? Back:  `string.whitespace` <!--ID: 1734713099696--> ENDI
- [[f-string]]
- [[Méthode spéciale __format__ et fonction native format]]
- Conversion de valeur
	- https://docs.python.org/3/library/string.html#grammar-token-format-string-conversion
	- STARTI [Basic] interpoler `repr(x)` dans une f-string ? Back:  `f'{x!r}'` <!--ID: 1734713099697--> ENDI
	- STARTI [Basic] interpoler `str(x)` dans une f-string ? Back:  `f'{x!s}'` <!--ID: 1734713099698--> ENDI
	- STARTI [Basic] interpoler `ascii(x)` dans une f-string ? Back:  `f'{x!a}'` (poke [[fonction native ascii]]) <!--ID: 1734713099699--> ENDI
- [[Spécifications de format]]
- [[Legacy formatting with % (`%`-formatting)]]
