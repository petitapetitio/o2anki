MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/builtins.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-07
***


==quelle différence entre built-ins et module builtins (certains modules builtins comme itertools ne font 
pas partie du module builtins)== (module builtins vs [[modules built-ins]])

***
TARGET DECK: Python
FILE TAGS: programs imports

- STARTI [Basic] de quel module proviennent <br>les constantes natives comme `True`, `None`, <br>les fonctions natives comme `abs`, `sum`, <br>les exceptions natives comme `NameError`, `IndexError`, et <br>les types natifs comme `int`, `float` ? Back:  du module préchargé `builtins`. <!--ID: 1731053653025--> ENDI
- STARTI [Basic] Que contient l'attribut `__builtins__` d'un module ? Back: Une référence au module `builtins` ou à son dictionnaire : ![[module builtins-1.png]]<!--ID: 1731053653026--> ENDI

START
Basic
Comment remplacer la fonction built-in `abs` par une version qui affiche chaque appel dans la console ?
Back: 
```python
import builtins
_abs = builtins.abs
def abs(x):
    print(f'abs({x})')
   return _abs(x)

builtins.abs = abs # override built-in w/wrapper
```
([[tricks]] - il y a moyen de fiche un bon bordel dans le code avec ça)
<!--ID: 1731053653024-->
END
