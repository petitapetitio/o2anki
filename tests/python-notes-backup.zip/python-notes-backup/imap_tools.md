MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : 
Tags : [[Python]]
Date : 2025-01-19
***

- https://github.com/ikvk/imap_tools


```python
import ssl

from imap_tools import MailBox

ssl_context = ssl.create_default_context()

with MailBox('petitapetit.io', ssl_context=ssl_context) as mailbox:
    print("Client info:")
    print(f"{mailbox.client.capabilities=}")
    print(f"{mailbox.client.host=}")
    print(f"{mailbox.client.port=}")

    print("SSL info:")
    print(f"{mailbox.client.sock.cipher()=}")
    print(f"{mailbox.client.sock.version()=}")
    print(f"{mailbox.client.sock.getpeername()=}")
    print(f"{mailbox.client.sock.getpeercert()=}")
```