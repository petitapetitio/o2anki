MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/datamodel.html#object.__setattr__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] Quelles instructions déclenchent `x.__setattr__('attr', value)` ? Back:  <br>- `x.attr = value` <br>- `setattr(x, 'attr', value)` <!--ID: 1730827064451--> ENDI
- STARTI [Basic] quelle est la signature de `__setattr__` ? Back:  `__setattr__(self, name, value)` <!--ID: 1730827064455--> ENDI
- STARTI [Basic] comment éviter la récursivité lorsque tu lie des attributs dans `__setattr__` ? Back:  Plusieurs options :  <br>- `super().__setattr__(name, value)` <br>- `x.__dict__[name] = value` <br>- `x.__slots__[name] = value` <!--ID: 1730827064459--> ENDI
