MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-31
***

***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] par quel appel de méthode spéciale se traduit `for e in elts` ? Back:  `elts.__iter__()` <!--ID: 1730827064043--> ENDI
- STARTI [Basic] par quel appel de méthode spéciale se traduit `iter(elts)` ? Back:  `elts.__iter__()` <!--ID: 1730827064045--> ENDI
- STARTI [Basic] quand est appelé `elts.__iter__()` ? Back:  <br>1) dans une boucle `for e in elts` <br>2) à l'appel de `iter(elts)`<br><!--ID: 1730827064047--> ENDI
- STARTI [Basic] comment est-ce que Python procède lorsque `elts.__iter__` n'est pas fournie ? Back:  Il renvoie `elts[0]`, `elts[1]` jusqu'à rencontrer une `IndexError`. <!--ID: 1730827064049--> ENDI
- STARTI [Basic] Comment Python rend-il un objet itérable si `__iter__` n'est pas défini ? Back:  Si l'objet supporte l'accès séquentiel par index, Python utilise `__getitem__` en commençant par l'index 0 et en l'incrémentant jusqu'à ce qu'une `IndexError` soit levée. <!--ID: 1730827064051--> ENDI
