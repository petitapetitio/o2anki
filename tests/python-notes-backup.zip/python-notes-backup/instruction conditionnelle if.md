MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Maitriser le langage Python]]
Tags : [[Python]]
Date : 2024-10-09
***

if est une [[instruction composée (compound statements)]]



***
TARGET DECK: Python
FILE TAGS: if

- STARTI [Basic] Qu'est-ce qu'un if ? Back:  une instruction conditionnelle <!--ID: 1728627767697--> ENDI
- STARTI [Basic] À quoi sert l'instruction `if` ? Back:  Exécuter du code seulement si une condition est vraie.  <!--ID: 1728627767701--> ENDI
- STARTI [Basic] Quelles clauses peut contenir une instruction conditionnelle `if` ? Back:  `if`, `elif`, `else`.  <!--ID: 1728627767705--> ENDI
- STARTI [Basic] Qu'acceptent un `if` et `elif` comme condition ? Back:  N'importe quelle expression. On dit alors que l'expression est utilisée dans un [[contexte booléen]]. <!--ID: 1728627767710--> ENDI
- STARTI [Basic] Quelles expressions vérifient que `x` *évalue à true* dans un contexte booléen et lesquelles testent que `x` *vaut true* :  <br>`x` <br>`bool(x)` <br>`x is true` <br> `x == true` <br>? Back: <br>Les deux premières testent que `x` évalue à True. Est truthy. <br>Les deux autres testent que `x` vaut True. <!--ID: 1728627767718--> ENDI
- STARTI [Basic] Qu'affiche `if [10] is true: print("ok")` ? Back:  Rien. Une liste non vide **évalue** à True dans un contexte booléen mais ne vaut pas True. <!--ID: 1728627767722--> ENDI

START
Basic  
Quelle est la structure canonique d'un if avec les trois clauses ?
Back:  
```python
if expression:
    instruction(s)
elif expression:
    instruction(s)
else:
	instruction(s)
```
END