MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-28
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] Quelle est l'approche recommandée pour appeler une méthode en amont de la chaîne d'héritage ? Back:  Utiliser `super().f(*args, **kwargs)` comme dans `super().__init__()`. <!--ID: 1730827064665--> ENDI
- STARTI [Basic] Quels sont les 3 intérêts à utiliser `super()` plutôt qu'une référence explicite à la classe parente ? Back:  <br>1. On peut renommer la classe parente sans modifier la méthode <br>2. On peut introduire une classe intermédiaire sans la court-circuiter <br>3. `super()` gère automatiquement l'héritage en diamant.  <!--ID: 1730827064672--> ENDI




START
Basic
`Derived().a` ?
```python
class Base:
	def __init__(self):
	    self.a = 1

class Derived(Base):
	def __init__(self):
	    self.b = 2
```
Back: `AttributeError: 'Derived' object has no attribute 'a'`. La méthode `__init__` de la classe de base n'est pas appelé de façon automatique.
<!--ID: 1730827064659-->
END


START
Basic
Qu'affiche `D().met()` ?
```python
class A:
    def met(self):
        print('A')


class B(A):
    def met(self):
        print('B')
        super().met()

class C(A):
    def met(self):
        print('C')
        super().met()

class D(B, C):
    def met(self):
        print('D')
        super().met()
```
Back:
```
D
B
C
A
```
L'utilisation de `super()` permet de lever les problèmes liés aux héritages en diamant.

Un appel direct produit la séquence `DBACA` ou `A` est appelée deux fois : 
```python
class A:
    def met(self):
        print('A')

class B(A):
    def met(self):
        print('B')
        A.met(self)

class C(A):
    def met(self):
        print('C')
        A.met(self)

class D(B, C):
    def met(self):
        print('D')
        B.met(self)
        C.met(self)

D().met()
```
<!--ID: 1730827064662-->
END

