MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-24
***


***
TARGET DECK: Python
FILE TAGS: paramètres

- STARTI [Basic] à quoi sert le paramètre `*name` dans `f(x, *name)` ? Back:  à collecter les arguments **positionnels** non matchés  <!--ID: 1730827064349--> ENDI
- STARTI [Basic] comment collecter les arguments positionnels non matchés ? Back:  à l'aide du collecteur d'arguments positionnels `*args`. <!--ID: 1730827064351--> ENDI
- STARTI [Basic] étant donné la signature `func(a, *others)`, que vaut `others` dans l'appel de fonction `func(1)` ? Back:  `()` un tuple vide <!--ID: 1730827064353--> ENDI
- STARTI [Basic] étant donné la signature `func(a, *others)`, que vaut `others` dans l'appel de fonction `func(1, 2, 3)` ? Back:  `(2, 3)` <!--ID: 1730827064355--> ENDI
- STARTI [Basic] comment créer une fonction qui accepte un nombre infini d'arguments positionnels et renvoie leur somme ? Back:  `def f(*numbers):` avec le corps `return sum(numbers)` <!--ID: 1730827064357--> ENDI