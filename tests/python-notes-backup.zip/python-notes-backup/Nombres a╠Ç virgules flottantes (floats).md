MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***

Problèmes avec l'arithmétique flottante
- [What Every Computer Scientist Should Know About Floating-Point Arithmetic](https://docs.oracle.com/cd/E19957-01/806-3568/ncg_goldberg.html)
- [Floating-Point Arithmetic: Issues and Limitations (python doc tutorial)](https://docs.python.org/3/tutorial/floatingpoint.html)
- The Perils of Floating Point - Bruce Bush’s

D'où le [[module decimal (Decimal fixed-point and floating-point arithmetic)]]


***
TARGET DECK: Python
FILE TAGS: stdtypes

- STARTI [Basic] Comment écrire "5 fois 10 puissance 3" ? Back: `5e3` <!--ID: 1727939491286--> ENDI
- STARTI [Basic] À quoi correspond `5e3` ? Back: `5 x 10^3` (5000.0) <!--ID: 1729447957688--> ENDI
- STARTI [Basic] Comment écrire "0,21 fois 10 puissance -2" ? Back: `.21e-2` <!--ID: 1729447957693--> ENDI
- STARTI [Basic] À quoi correspond `5e-2` ? Back: `5 / 10^2` (0.05) <!--ID: 1729447957696--> ENDI
- STARTI [Basic] Que vaut `type(5e3)` ? `<class 'float'>` (bien que le résultat 5000.0 peut être représenté sous la forme d'un entier)
- STARTI [Basic] Comment écrire "zéro virgule cinq" en flottant ? Back: `0.5`, `.5` <!--ID: 1727939491295--> ENDI
- STARTI [Basic] Comment créer un 1 flottant de façon littérale ? Back: `1.` <!--ID: 1729447957699--> ENDI

START
Basic
Comment obtenir les informations sur les limites des flottants ?
Back:
`sys.float_info` 

```python
import sys  
print(sys.float_info)

# Affiche : 
# sys.float_info(
#   max=1.7976931348623157e+308,
#   max_exp=1024, max_10_exp=308, 
#   min=2.2250738585072014e-308, 
#   min_exp=-1021, 
#   min_10_exp=-307, 
#   dig=15, 
#   mant_dig=53, 
#   epsilon=2.220446049250313e-16, 
#   radix=2, 
#   rounds=1,
# )

```
<!--ID: 1727939491302-->
END


###### Points de vigilance ([[gotcha]])

Floats are limited in the range of integer values they can store
```python
f = 2 ** 53 + 1  
print(f)         # 9007199254740993
print(float(f))  # 9007199254740992.0
```

Utilise `cmath.isclose` plutôt que == pour comparer deux flottants
```python
1.1 + 2.2 == 3.3        # False
isclose(1.1 + 2.2, 3.3) # True
```

Précise la tolérance absolue quand tu compares à `0`
```python
f = 1.1 + 2.2 - 3.3
print(isclose(0, f))                 # False
print(isclose(0, f, abs_tol=1e-15))  # True
```
