MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/functions.html#import__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-07
***

***
TARGET DECK: Python
FILE TAGS: imports

START
Basic
Comment fonctionne `__import__('m')` ?
Back:
Cherche le module `m` dans :
1. Le cache (`sys.modules['m']`)
2. Les [[modules built-ins]] (`sys.builtin_module_names`)
3. Les chemins de `sys.path`

Si trouvé : renvoie le module 
Sinon : crée un objet module → le met en cache → l'initialise

L'exemple suivant montre la précédence des modules builtins sur les modules utilisateur. Le module utilisateur `sys.py`  est masqué par le module built-in à l'exécution (mais il casse l'auto-complétion) : ![[fonction native __import__ (ordre de recherche des modules)-1.png]]
<!--ID: 1731677487764-->
END

- STARTI [Basic] Qu'est-ce que la fonction native `__import__` ? Back: La fonction utilisée par l'[[instruction import]] (et `importlib.import_module`) pour importer les modules. <!--ID: 1731677487761--> ENDI
- STARTI [Basic] Que permet l'assignation des modules dans `sys.modules` ? Back:  de ne charger les modules qu'une seule fois <!--ID: 1731677487763--> ENDI




Quelles sont les extentions que Python considères lors d'un import ? 
- [[module d'extension]] natifs :
	- Windows : .pyd, .dll
	- Unix : .so
- [[fichier .py]] 
- [[fichier compilé .pyc]] (.pyc)
- Modules package (`__init__.py`)

Pour moi l'ordre reste à déterminer. Dans mes tests, le module package est chargé avant le .py. Cela ne colle pas avec ce qui est écrit dans le livre.

Pourquoi Python vérifie-t-il les [[fichier compilé .pyc]] en dernier ?
Pour la fiabilité :
1. Si le .py existe, Python vérifie si le .pyc est à jour avec le .py source
2. Si le .py n'existe pas, Python utilise le .pyc existant. Cela garantit que le bytecode exécuté correspond toujours au code source le plus récent

