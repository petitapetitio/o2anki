MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Notions de base du développement]]
Date : 2024-09-28
***

Un littéral est une notation directe d'une valeur de donnée dans un programme.

Exemples en [[2 CASQUETTES/Tamis/Tamis/RESSOURCES/Python/Python|Python]]
```python
42                    # Un entier
3.14                  # Un flottant

'hello'               # Une chaîne de caractères
"buddy"               # Une autre chaîne de caractères
"""Good
bye"""                # Une - [[triple-quoted string literal]]

[42, 3.14, "hello"]   # Une liste  
[]                    # Une liste vide

12, 25                # Un tuple
()                    # Un tuple vide

{'x': 42}             # Un dictionnaire
{}                    # Un dictionnaire vide

{1, 2, 3}             # Un set
# Il n'existe pas de littéral pour créer un set vide. Utiliser set()
```

