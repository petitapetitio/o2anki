MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[connection-oriented protocols]]
Date : 2025-01-18
***

![[Python in a Nutshell-9.png]]

Remarques 
- le ack permet ici de synchroniser l'envoi des paquets. Sans le ack, le serveur récupère tous les paquets d'un coup : `received b"1. Accept everything just the way it is2. Do not seek pleasure for it's own sake3. Do not, under any circumstances, depend on a partial feeling" from ('127.0.0.1', 8884)`
- la fermeture de la connection est ici à l'initiative du client

`client.py` : 
```python
import socket

server_host = 'localhost'
server_port = 8884
server_address = server_host, server_port

MESSAGE = """\
1. Accept everything just the way it is
2. Do not seek pleasure for it's own sake
3. Do not, under any circumstances, depend on a partial feeling
"""

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    print(f"Establish connection to {server_address}")
    sock.connect(server_address)

    for line in MESSAGE.splitlines():
        data = line.encode()
        print(f"Send {data}")
        sock.sendall(data)
        response = sock.recv(1024)
        print(f"<--- {response.decode()} from {server_address}")
```

`server.py` : 
```python
import socket
from concurrent.futures import ThreadPoolExecutor

SERVER_HOST = 'localhost'
SERVER_PORT = 8884
SERVER_ADDRESS = SERVER_HOST, SERVER_PORT
WAITING_ROOM_SIZE = 5
MAX_CONCURRENT_CONNECTIONS = 20


def handle_connection(connected_socket, address):
    print(f"Connected from {address}")
    with connected_socket:
        while data := connected_socket.recv(1024):
            print(f"received {data} from {connection.getsockname()}")
            connected_socket.send("ACK".encode())
        print(f"Disconnected from {address} ({data=})")


with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as main_socket:
    main_socket.bind(SERVER_ADDRESS)
    main_socket.listen(WAITING_ROOM_SIZE)

    with ThreadPoolExecutor(MAX_CONCURRENT_CONNECTIONS) as pool:
        while True:
            print("[main] listen connection requests ...")
            connection, client_address = main_socket.accept()
            pool.submit(handle_connection, connection, client_address)

```