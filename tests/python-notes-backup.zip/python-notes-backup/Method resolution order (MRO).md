MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] -  https://docs.python.org/fr/3.13/glossary.html#term-MRO
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-28
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] De quoi MRO est-il l'acronyme ? Back:  Method Resolution Order <!--ID: 1730827064534--> ENDI
- STARTI [Basic] Comment connaître le MRO d'un objet `obj` ? Back:  <br>`type(obj).__mro__` <br>`obj.__class__.__mro__` <!--ID: 1730827064539--> ENDI
- STARTI [Basic] Qu'indique l'attribut de classe `__mro__` ? Back:  L'ordre dans lequel Python parcours les classes parentes pour chercher un attribut de classe (qu'il s'agisse d'une méthode ou d'un autre attribut). <!--ID: 1730827064541--> ENDI
- STARTI [Basic] En quoi le nom MRO est-il piège ? Back:  Le MRO s'applique à toutes les recherches d'attributs de classe, pas seulement aux méthodes <!--ID: 1730827064546--> ENDI
- STARTI [Basic] Quelle logique suit le MRO dans les grandes lignes ? Back:  Parcours les classes parentes de gauche à droite et en profondeur, en ne gardant que la dernière apparition d'une classe. <!--ID: 1730827064549--> ENDI
- STARTI [Basic] `bool.__mro__` ? Back:  `(<class 'bool'>, <class 'int'>, <class 'object'>)` <!--ID: 1730827064551--> ENDI
- STARTI [Basic] Comment connaître l'arbre d'héritage d'une classe `C` de façon dynamique ? Back: Appeler récursivement `C.__bases__`  ou utiliser `C.__mro__` qui donne la chaîne d'héritage (vue linéarisée).<!--ID: 1730827064554--> ENDI






START
Basic
```python
class A: ...  
class B1(A): ...  
class B2(A): ...  
class C(B1, B2): ...
```
Que donne le MRO de `C` ?
Back: `C`, `B1`, `B2`, `A`
<!--ID: 1730827064532-->
END