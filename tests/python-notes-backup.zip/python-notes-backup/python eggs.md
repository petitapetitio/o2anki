MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://packaging.python.org/en/latest/glossary/#term-Egg
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***

pb = plateform-dependent

***
TARGET DECK: Python
FILE TAGS: packaging

- STARTI [Basic] Qu'est-ce qu'un egg ? Back:  Un format de distribution de paquets Python introduit par [[setuptools]]. Il est déprécié depuis 2010 <!--ID: 1731677487775--> ENDI
- STARTI [Basic] Quelle a été la période d'utilisation active des eggs ? Back:  2004-2010 <!--ID: 1731677487776--> ENDI
- STARTI [Basic] Quelle commande était utilisée pour installer les eggs ? Back:  `easy_install` <!--ID: 1731677487777--> ENDI
- STARTI [Basic] Quand la commande `easy_install` a-t-elle été supprimée de `setuptools` ? Back:  2021 (version 58.3 de [[setuptools]]) <!--ID: 1731677487778--> ENDI
- STARTI [Basic] Par quoi ont été remplacés les eggs ? Back:  Par les [[wheel (.whl)]] <!--ID: 1731677487779--> ENDI