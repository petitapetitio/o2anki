MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/datamodel.html#object.__set_name__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-28
***

***
TARGET DECK: Python
FILE TAGS: 

- comment fonctionne `__set_name__` ? Quand une classe définit un attribut qui fournit `__set_name__(self, owner, name)`, Python appelle cette méthode après la création de la classe avec : `owner` est la classe qui contient l'attribut et `name` le nom donné à l'attribut dans la classe.
- quel est l'intérêt de `__set_name__` ? Permet à un [[descripteur]] de connaître la classe qui le définit et son propre nom dans la classe sans avoir à passer ces informations manuellement lors de la création du descripteur

START
Basic
Qu'affiche
```python
class X:
    def __set_name__(self, owner, name):
        print("set name", owner, name)

print("1")
class A:
    x = X()
    print("2")
print("3")

A()
```
?
Back:
```
1
2
set name <class 'A'> x
3
```
<!--ID: 1730827063935-->
END

Exemple : `__set_name__` permet de répondre à [ce case d'usage](https://docs.python.org/fr/3/howto/descriptor.html#managed-attributes), [de cette façon](https://docs.python.org/fr/3/howto/descriptor.html#customized-names)
