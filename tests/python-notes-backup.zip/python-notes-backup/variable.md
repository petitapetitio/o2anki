MOC : 
Source :
Projets :
Tags : 
Date : 2024-11-01
***

Une variable est un symbole qui associe un nom à une valeur. 

Les variables on un type de données déterminé : 
- entier
- chaîne de caractère
- objet

Le type est donné de façon explicite ([[Typage statique]]) ou implicite ([[Typage dynamique]]). 

Lorsque sa valeur peut changer au cours du temps, on dit qu'elle est mutable. 
Lorsque sa valeur ne peut pas changer au cours du temps, on dit qu'elle est immutable ([[Immutabilité]]). 

Analogie : une variable est comme une boîte dans laquelle on peut ranger quelque chose : 

![[Variable-1.png]]

Voici un exemple de variable en Python. 
```python
# On affecte la valeur "panda" à la variable animal
# (en python, le typage est dynamique)
animal = "panda"

# On affiche la valeur de la variable animal : 
# affiche "pandas"
print(animal)  

# On afficher le type de la variable animal
# affiche <class 'str'> (chaîne de caractère)
print(type(animal))  
```


***
TARGET DECK: Python

- STARTI [Basic] Qu'est-ce qu'une variable ? Back:  Un nom lié à un objet. <!--ID: 1728036834551--> ENDI
- STARTI [Basic] Qu'est-ce que créer une variable en python ? Back:  Lier un nom à un objet. <!--ID: 1728036834553--> ENDI
- STARTI [Basic] Que se passe-t-il lors d'une assignation `x = 42` ? Back: Le nom `x` est lié à l'objet `42` <!--ID: 1731677487780--> ENDI
- STARTI [Basic] Est-ce qu'une variable peut faire référence à des objets de types différents au cours de l'exécution ? Back: Oui, c'est une caractéristique du [[Typage dynamique]]. par exemple `x = 1; x = "a"; print(x)` ne pose aucun soucis - et affiche "a". <!--ID: 1728036834555--> ENDI
- STARTI [Basic] Une référence peut-elle être liée à plusieurs variables ? Back:  Oui. L'affectation multiple `a = b = MyClass()` associé la référence à l'instance de `MyClass` à la variable `a` et à la variable `b`. <!--ID: 1728036834558--> ENDI
- STARTI [Basic] Que devient un objet qui n'a plus aucune référence ? Back: ll est automatiquement libéré par le garbage collector. <!--ID: 1728036834560--> ENDI
- STARTI [Basic] Qu'est-ce qu'une variable globale ? Back:  Un attribut d'un module <!--ID: 1728036834562--> ENDI
- STARTI [Basic] Comment accèdes-t-on à l'attribut d'un objet ? Back:  En faisant suivre la référence à l'objet de `.` puis de l'identifiant de l'attribut (par exemple `x.y`, `t[0].y`) <!--ID: 1728036834565--> ENDI
- STARTI [Basic] Comment accéder à aux éléments d'un *item's container* ? Back:  Avec la notation crochet, par *clé* si c'est un Mapping (`x[key]`) ou par *index* si c'est une Sequence (`x[i]`). <!--ID: 1728036834567--> ENDI
- STARTI [Basic] `x = []; x[2]` ? Back:  `IndexError: list index out of range`. L'item n'existe pas. <!--ID: 1728036834573--> ENDI
- STARTI [Basic] `x = []; x.plop` ? Back:  `AttributeError: 'list' object has no attribute 'plop'`. L'attribut qui n'existe pas. <!--ID: 1728036834576--> ENDI
- STARTI [Basic] Que renvoie `a_variable_out_of_nowhere` ? Back:  `NameError: name 'a_variable_out_of_nowhere' is not defined`. Le nom n'est pas défini. <!--ID: 1728036834578--> ENDI

- comment python résout un accès à une variable ? Il cherche dans trois namespaces dans cet ordre : <br>- le namespace local (de la fonction)<br>- le namespace global <br>- l'attribut `__builtins__` du module <br>avant de lever une NameError.