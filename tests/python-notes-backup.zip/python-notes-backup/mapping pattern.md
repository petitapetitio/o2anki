MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/reference/compound_stmts.html#mapping-patterns
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***


***
TARGET DECK: Python
FILE TAGS: match

- STARTI [Basic] À quoi sert un mapping pattern ? Back:  à matcher des objets de type mapping comme les dictionnaires. <!--ID: 1728727115325--> ENDI
- STARTI [Basic] Quelle est la forme d'un mapping pattern ? Back:  `key: pattern` avec <br>- `key` un [[littéral]] ou un [[value pattern]] <br>- `pattern` n'importe quel pattern <!--ID: 1728727115327--> ENDI

START
Basic
Qu'affiche
```python
match {1: "two", "two": 1}:
    case {1: _} as x: 
	    print(x)
```
?
Back:  
`{1: "two", "two": 1}` le sujet complet. Le pattern match la clé `1` et `as x` capture le dictionnaire complet. ([[gotcha]])
<!--ID: 1728729591964-->
END

START
Basic
pattern-matching : comment matcher un dictionnaire qui présente une clé "a" et une clé "b" ?
Back: 
```python
match s:
    case {"a": _, "b": _}:
        ...
```
<!--ID: 1728727115317-->
END

START
Basic
pattern-matching : comment capturer le reste des éléments d'un dictionnaire qui présente la clé "a" ?
Back:
À l'aide d'un double-starred [[capture pattern]] : 
```python
match s:
    case {"a": 2, **other}:
        ...
```
<!--ID: 1728727115320-->
END

START
Basic
Qu'affiche
```python
match {"a": 2}:
    case {"a": 2, **other}:
        print(other)
```
?
Back:
`{}`
<!--ID: 1728727115321-->
END

START
Basic
Qu'affiche
```python
match {"a": 2, "b": 5, "c": 17}:
    case {"a": 2, **other}:
        print(other)
```
?
Back:
`{"b": 5, "c": 17}`
<!--ID: 1728727115323-->
END