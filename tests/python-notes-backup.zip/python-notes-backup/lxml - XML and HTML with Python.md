MOC : [[SOFTWARE ENGINEERING]]
Source : https://lxml.de/
Projet : 
Tags : [[Python]], [[XML]]
Date : 2025-01-19
***

- créé par [[Ian Bicking]] ; maintenu par [[Stefan Behnel]]
- construit avec la volonté de collet au mieux à l'api du [[module xml]]
- why : https://lxml.de/intro.html

