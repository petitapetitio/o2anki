MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/fr/3/library/textwrap.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: strings

- fill
	- STARTI [Basic]  `textwrap.fill("abcdef", 2)` ? Back:  `'ab\ncd\nef'` <!--ID: 1734713099687--> ENDI
	- STARTI [Basic]  `"abcdef" → 'ab\ncd\nef'` ? Back:  `textwrap.fill("abcdef", 2)` <!--ID: 1734713099688--> ENDI
- wrap
	- STARTI [Basic]  `textwrap.wrap("abcde", 2)` ? Back:  `['ab', 'cd', 'e']` <!--ID: 1734713099689--> ENDI
	- STARTI [Basic]  `"abcde" → ['ab', 'cd', 'e']` ? Back:  `textwrap.wrap("abcde", 2)` <!--ID: 1734713099690--> ENDI
- dedent


START
Basic
```python
textwrap.dedent("""
    def hey():
        print("hey") 
""")
```
Back:
```python
== """
def hey():
    print("hey") 
"""
```
<!--ID: 1734710569255-->
END
