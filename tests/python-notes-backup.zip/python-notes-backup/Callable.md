MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/datamodel.html#callable-types
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python|Python]]
Date : 2024-10-04
***


***
TARGET DECK: Python
FILE TAGS: dict

- STARTI [Basic] Qu'est-ce qu'un callable ? Back: Un objet qui supporte l'opérateur d'appel `()` <!--ID: 1728024344562--> ENDI
- STARTI [Basic] Quelles sont les grandes familles de callable ? Back: <br>1) [[fonction]] <br>2) [[méthode]] <br>3) [[classe]] (objet de type [[type]]) <br>4) tout objet qui fournit la [[méthode spéciale __call__]] <br><!--ID: 1728024344566--> ENDI