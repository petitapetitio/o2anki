MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/datamodel.html#object.__new__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-28
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] Comment reproduire `c = C(23)` sans utiliser l'opérateur d'appel sur `C` ? Back:  <br>`c = C.__new__(C, 23)`<br>`c.__init__(23)` <br><!--ID: 1730827064099--> ENDI
- STARTI [Basic] Quelle est la différence entre `__new__` et `__init__` ? Back:  <br>`__new__` est une méthode de classe qui crée une nouvelle instance. <br>`__init__` initialise l'instance nouvellement créée. <br><!--ID: 1730827064103--> ENDI
- STARTI [Basic] Dans quel cas est-il courant d'initialiser dans `__new__` plutôt que dans `__init__` ? Back:  Lorsque l'objet est immutable. <!--ID: 1730827064094--> ENDI


START
Basic
Qu'affiche
```python
class A:  
    def __new__(cls):  
        print("__new__")  
        return super().__new__(cls)  
  
    def __init__(self):  
        print("__init__")  
  
A()
```
Back:
```
__new__
__init__
```
<!--ID: 1734019137959-->
END

- pour quelle raison est-ce que `__new__` prends les arguments de l'appel sur l'objet classe ? Back:  Pour contrôler la création de l'instance et ajuster ou vérifier les arguments avant `__init__`. 