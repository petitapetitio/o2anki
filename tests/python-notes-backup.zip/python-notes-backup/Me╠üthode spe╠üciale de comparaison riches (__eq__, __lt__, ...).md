MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/datamodel.html#basic-customization
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] quelle est l'approche recommandée pour implémenter un ordre total ? Back:  Implémenter `__lt__` et `__eq__` puis décorer la classe avec `functools.total_ordering`. <!--ID: 1730827064417--> ENDI
- STARTI [Basic] comment se traduit `x < x1` ? Back:  par l'appel `x.__lt__(x1)` <!--ID: 1730827064419--> ENDI

