MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/fr/3.13/glossary.html#term-PEP
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

- Python Enhancement Proposals (PEPs)
- Propositions de changement détaillées dans de documents publiques
- La décision finale revient au [[Python Steering Council (PSC)]]

Ressources : 
- https://peps.python.org/


***
TARGET DECK: Python

- STARTI [Basic] Que signifie PEP ? Back: Python Enhancement Proposal <!--ID: 1727542890103--> ENDI