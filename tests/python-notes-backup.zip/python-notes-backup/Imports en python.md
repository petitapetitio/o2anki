


Imports absolus
- utilise le chemin complet depuis la racine du projet
- exemple `from package1.module2 import function1`
- + faciles à lire
- recommandés par PEP8

Imports relatifs
- imports relatifs implicites dépréciés depuis python 3
- avantages  : concision
- inconvénients : manque de clarté


Ressources : 
- https://realpython.com/absolute-vs-relative-python-imports/#a-quick-recap-on-imports