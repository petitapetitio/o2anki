MOC : [[SOFTWARE ENGINEERING]]
Source : https://en.wikipedia.org/wiki/MIME
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2025-01-19
***

- **Multipurpose Internet Mail Extension**
- les informations circulent sur le réseau sous forme d'octets
- MIME est un format d'encodage qui représente des données structurées sous forme de bytes
- conçu pour les e-mails à la base mais aussi utilisé pour le web aujourd'hui ([[HTTP]])
