MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/typing.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***

Ressources : 
- https://docs.python.org/3/library/typing.html
- https://typing.readthedocs.io/en/latest/spec/glossary.html


***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] quel est l'autre noms de *type annotations* ? Back:  *type hints* <!--ID: 1730827064753--> ENDI
- STARTI [Basic] Python est-il typé de façon dynamique ou statique ? Back:  [[Typage dynamique]] <!--ID: 1730827064756--> ENDI
- STARTI [Basic] Dans quelle version de python le module typing a-t-il été introduit ? Back: 3.6 (2016) <!--ID: 1730827064758--> ENDI
- STARTI [Basic] Est-ce que les annotations de types sont vérifiées par Python au runtime ? Back:  Non. Python fournit un système d'annotation, mais la validation passe par des outils tiers. <!--ID: 1730827064760--> ENDI
- STARTI [Basic] Quelle structure Python ne supporte pas les annotations de type ? Back:  Les [[expression lambda]]  <!--ID: 1730827064762--> ENDI
- STARTI [Basic] Est-ce que les [[expression lambda]] supportent les annotations de type ? Back:  Non <!--ID: 1730827064764--> ENDI
- STARTI [Basic] Qu'est-ce qui peut expliqué l'émergence des annotations de type en Python ? Back:  L'utilisation croissante de Python dans des projets d'entreprise, complexes nécessitant plus de robustesse et de maintenabilité. <!--ID: 1730827064766--> ENDI
START
Basic
quels sont les bénéfices des annotations de type ?
Back:
- [[IDE]] :
	- auto-completion
	- refactoring
	- détection des erreurs de type avant l'exécution
- Maintenabilité : 
	- interfaces explicites
	- documentation contextuelle

(Comme le [[Typage statique]] , sans l'avantage des performances)
<!--ID: 1730827064754-->
END


- [[Outils tiers pour la validation des types en python]]
- [[syntaxe de base des annotations de type]]
- [[module typing]]
- [[Ugly type annotations hint at ugly code]]
