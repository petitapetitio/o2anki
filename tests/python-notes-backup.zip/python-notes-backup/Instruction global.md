MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[variable globale]]
Date : 2024-10-24
***

***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] que fait l'instruction `global x` ? Back:  Déclare que `x` fait référence à la variable globale et permet de la modifier. <!--ID: 1729754351993--> ENDI
- STARTI [Basic] est-ce que l'utilisation de l'instruction `global` est recommandé ? Back:  Non. Elle rend les programmes plus difficiles à maintenir. <!--ID: 1729754351988--> ENDI
- STARTI [Basic] quelles sont les alternatives à l'utilisation du mot clé `global` ? Back:  <br>1) mécanisme orienté-objet <br>2) [[closure]]  <!--ID: 1729754351990--> ENDI
- STARTI [Basic] commet réassigner une variable globale `x` depuis une fonction ? Back: Faire précéder les assignations d'une l'instruction `global x` <!--ID: 1729754351992--> ENDI

START
Basic
Que produit l'appel `incr()`
```python
x = 0
def incr():
    x += 1
```
?
Back:
`UnboundLocalError: local variable 'x' referenced before assignment`. Python interprète l'instruction `x += 1` comme une tentative de modifier la variable locale `x`. Or il n'existe pas de variable `x` dans l'espace de nom local
<!--ID: 1729754351985-->
END
