MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-16
***

- https://docs.python.org/3/library/zipapp.html (doc concise)
- permet de packager et distribuer des programmes simples
- il est possible d'embarquer les dépendances dans l'archive
- principale limite : 
	- ne supporte pas les [[module d'extension]]
	- est en général créé pour une version de Python vague (Python 2, Python 3)
- exemples
	- `python -m zipapp src/myapp -m "myapp:main"` (packager)
	- `python myapp.pyz` (exécuter le programme)


***
TARGET DECK: Python
FILE TAGS: packaging

- STARTI [Basic] qu'est-ce que zipapp ? Back:  un module qui permet de packager un programme python dans un fichier .zip, exécutable par l'interpréteur python. <!--ID: 1731749004771--> ENDI
- STARTI [Basic] quelles sont les deux principales limites de zipapp ? Back: <br>1) Ne supporte pas les modules d'extension <br>2) Créé en général pour une version générique (Python 2 ou 3) <!--ID: 1731749004772--> ENDI
- STARTI [Basic] quels sont les cas d'usage de zipapp ? Back:  <br>Application pure Python <br>Scripts utilitaires portables<!--ID: 1731749004773--> ENDI
