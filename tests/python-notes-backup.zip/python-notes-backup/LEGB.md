MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Espace de nom des fonctions]]
Date : 2024-10-25
***

***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] que signifie LEGB ? Back:  Local, Enclosing, Global, Built-in <!--ID: 1730827064583--> ENDI
- STARTI [Basic] que décrit la règle LEGB ? Back:  L'ordre dans lequel python recherche une variable <!--ID: 1730827064586--> ENDI
