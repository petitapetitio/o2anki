MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[fonction native len]]
Date : 2024-10-31
***

***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] `elts.__len__()` ? Back:  Un entier positif qui est le nombre d'éléments que contient `elts`. <!--ID: 1730827064034--> ENDI
- STARTI [Basic] par quel appel de méthode spéciale se traduit `len(elts)` ? Back:  `elts.__len__()` <!--ID: 1730827064036--> ENDI
- STARTI [Basic] quand est appelé `elts.__len__()` ? Back: <br>1) Lors d'un appel à `len(elts)` <br>2) Dans un contexte booléen quand `elts` ne fournit pas `__bool__` <br><!--ID: 1730827064039--> ENDI

START
Basic
`len(A())` ?
```python
class A:  
    def __len__(self):  
        return -1
```
Back:
`ValueError: __len__() should return >= 0`
[[gotcha]]
<!--ID: 1730827064032-->
END
