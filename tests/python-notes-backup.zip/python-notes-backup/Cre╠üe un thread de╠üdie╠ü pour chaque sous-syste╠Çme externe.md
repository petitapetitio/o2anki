MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[(multi)threading]], [[3 RESSOURCES/The developer's brain/Notes/Software Design|Software Design]]
Date : 2025-01-14
***

- [[3 RESSOURCES/The developer's brain/Notes/Software Design|Software Design]]
- see Threaded Program Architecture dans [[Python in a Nutshell]]
- Me rappelle l'approche suivie par [[Ayoub El Khallioui]] pour notifier
