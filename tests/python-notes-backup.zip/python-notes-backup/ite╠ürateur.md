MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/glossary.html#term-iterator
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***


***
TARGET DECK: Python
FILE TAGS: iterators

- STARTI [Basic] Qu'est-ce qu'un itérateur ? Back:  Un objet qui représente un flux de données. `next(iterateur)` renvoie l'élément suivant ou lève une `StopIteration` lorsque l'itérateur est épuisé. <!--ID: 1728749077412--> ENDI
- STARTI [Basic] Comment renvoyer une valeur par défaut lorsque l'itérateur `i` est épuisé plutôt que de lever une exception ? Back:  `next(i, default)`. <!--ID: 1728749077414--> ENDI
- STARTI [Basic] Quelle est la différence entre un itérateur et un [[itérable]] ? Back:  Un itérateur se consomme et ne peut être parcouru qu'une seule fois. <!--ID: 1728749077422--> ENDI

START
Basic
Qu'affiche
```python
iterable = [1, 2]
for i in iterable:
    for j in iterable:
        print(i, j)
```
?
Back:
```
1 1
1 2
2 1
2 2
```
<!--ID: 1728749077404-->
END

START
Basic
Qu'affiche
```python
iterator = iter([1, 2])
for i in iterator:
    for j in iterator:
        print(i, j)
```
?
Back:
```
1 2
```
<!--ID: 1728749077408-->
END

