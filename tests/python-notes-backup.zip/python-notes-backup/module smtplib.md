MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-18
***

- https://docs.python.org/3/library/smtplib.html
- [[SMTP (Simple Mail Transfer Protocol)]]
- classes
	- `SMTP`
	- `SMTP_SSL`
- fonctions principales d'une instance
	- `connect(host, port)`
	- `login(user, password)`
	- `quit()`
	- `sendemail(from_addr, to_addr, msg_string)`
	- `send_message(msg)`
