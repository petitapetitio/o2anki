MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] 
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-14
***

- https://github.com/pjeby
- an obsidian user and contributor : https://github.com/ophidian-lib

![[Phillip J. Eby-1.png]]