MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[XML]]
Date : 2025-01-19
***

- https://docs.python.org/3/library/xml.html
- ElementTree
	- https://docs.python.org/3/library/xml.etree.elementtree.html
	- https://docs.python.org/3/library/xml.etree.elementtree.html#tutorial
- Classes
	- class `Element`
		- représente un noeud
		- attributs : `attrib`, `tag`, `tail`, `text`
		- mapping-like methods (+ performants que `attrib`) : `clear`,  `get`, `items`, `keys`, `set`
		- méthodes : `append`, `extend`, `find`, `findall`, `findtext`, `insert`, `iter`, `iterfind`, `itertext`, `remove`
	- class `ElementTree`
		- représente le document XML complet
		- méthodes : `parse(source)`, `write(file, ...)`, `getroot()`

###### Parser et modifier un XML
```python
from urllib import request
from xml.etree import ElementTree as et

content = request.urlopen("http://www.w3schools.com/xml/simple.xml")
tree = et.parse(content)

# Ajouter un aliment au menu
menu = tree.getroot()
toast = et.SubElement(menu, 'food')
tcals = et.SubElement(toast, 'calories')
tcals.text = '180'
tname = et.SubElement(toast, 'name')
tname.text = 'Buttered Toast'

# Supprimer les aliments qui contiennent des berry
for e in menu.findall('food'):
    if 'berry' in e.find('name').text.lower():
        menu.remove(e)

# Afficher les calories des aliments du menu
for e in tree.findall('food'):
    calories = e.find('calories').text
    name = e.find('name').text
    print(f"{name: >30}: {calories} calories")

"""
               Belgian Waffles: 650 calories
                  French Toast: 600 calories
           Homestyle Breakfast: 950 calories
                Buttered Toast: 180 calories
"""

```

###### Créer un XML from scratch
```python
from xml.etree import ElementTree as et

menu = et.Element('menu')
tree = et.ElementTree(menu)
for food_name, calories in [('bread', 50), ('butter', 100)]:
    food = et.SubElement(menu, 'food')
    name = et.SubElement(food, 'name')
    name.text = food_name
    calt = et.SubElement(food, 'calories')
    calt.text = str(calories)

et.indent(tree)
print(et.tostring(tree.getroot(), encoding='unicode'))

"""
<menu>
  <food>
    <name>bread</name>
    <calories>50</calories>
  </food>
  <food>
    <name>butter</name>
    <calories>100</calories>
  </food>
</menu>
"""
```

###### Parser sans construire tout l'arbre 
```python
from xml.etree import ElementTree as et

# ATTENTION : 
#   le fichier est quand même entièrement chargé au départ
#   seul l'arbre XML est construit au fur et à mesure
#   pour du vrai streaming, regarder `xml.sax`

def parsing_memory_optimized():
    root = None
    for event, elem in et.iterparse("menu.xml", ["start", "end"]):
        match event:
            case "start":
                if root is None:
                    root = elem
            case "end":
                if elem.tag == "food":
                    calories = int(elem.find("calories").text)
                    name = elem.find("name").text
                    yield calories, name
                    root.remove(elem)
        print(et.tostring(root))


for c, n in parsing_memory_optimized():
    print(c, n)
```


[[lxml - XML and HTML with Python|lxml.etree]] et `xml.etree.ElementTree` offrent une api similaire : 
```python

try:
	from lxml import etree as et
except ImportError:
	from xml.etree import ElementTree as et
```
