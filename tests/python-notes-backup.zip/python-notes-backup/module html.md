MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-19
***

##### module html.parser (Simple HTML and XHTML parser)

- https://docs.python.org/3/library/html.parser.html#module-html.parser
- quite impracticable IMO
- utilise le [[Template Method Pattern]]

```python
from html.parser import HTMLParser


class MyHTMLParser(HTMLParser):
    def handle_starttag(self, tag, attrs):
        print("Encountered a start tag:", tag)

    def handle_endtag(self, tag):
        print("Encountered an end tag :", tag)

    def handle_data(self, data):
        print("Encountered some data  :", data)


parser = MyHTMLParser()
parser.feed("""\
<html>
<head>
<title>Test</title>
</head>
</html>
""".translate({ord('\n'): None}))

# Encountered a start tag: html
# Encountered a start tag: head
# Encountered a start tag: title
# Encountered some data  : Test
# Encountered an end tag : title
# Encountered an end tag : head
# Encountered an end tag : html
```
