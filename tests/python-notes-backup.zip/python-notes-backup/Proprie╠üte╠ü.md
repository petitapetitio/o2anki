MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/functions.html#property
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] qu'est-ce que le type built-in `property` ? Back:  Un data-descriptor utilisé pour créer des propriétés.   <!--ID: 1730827064342--> ENDI
- STARTI [Basic] quelle est la signature du type natif `property` ? Back:  `property(fget=None, fset=None, fdel=None, doc=None)` <!--ID: 1730827064344--> ENDI
- STARTI [Basic] quelle est l'intérêt des propriétés ? Back: Contrôler l'accès en lecture, en écriture et en suppression d'un attribut d'une façon + simples et rapides que via `__getattr__`, `__setattr__` et `__delattr__`. <!--ID: 1730827064346--> ENDI


START
Basic
Comment créer un attribut `area` en lecture seul ?
```python
class Rectangle:
    def __init__(self, w, h):  
        self.w = w  
        self.h = h
```
Back: 
```python
class Rectangle:
    ...
	@property
	def area():
	    """L'aire du rectangle"""
	    return self.w * self.h
```
<!--ID: 1730827064334-->
END


START
Basic
Comment créer la même classe avec un appel explicite au type built-in `property` ?
```python
class Rectangle:
	@property
	def area():
	    """L'aire du rectangle"""
	    ...
```
Back:
```python
class Rectangle:
	def area(): 
	    ...
	
	area = property(area, doc="L'aire du rectangle")
```
<!--ID: 1730827064336-->
END


START
Basic
Comment modifier `Base` pour que ce code affiche 42 
```python
class Base:  
    def f(self):
        return 23 
    g = property(f)

class C(Base):
    def f(self):
        return 42 

print(C().g)
```
?
Back: 
```python
class Base:  
    def f(self):
        return 23
        
    def _f_get(self):  
        return self.f()  
    
    g = property(_f_get)
```
Just add [[One more level of indirection]].
<!--ID: 1730827064338-->
END

START
Basic
Est-ce que `'g' in Base().__dict__` ?
```python
class Base:  
    def f(self):
        return 23 
    g = property(f)
```
Back: 
Non. Mais le nom `g` est dans le dictionnaire de la classe. `'g' in Base.__dict__`.
<!--ID: 1730827064340-->
END
