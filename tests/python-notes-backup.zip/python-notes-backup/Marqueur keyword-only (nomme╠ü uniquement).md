MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-24
***

***
TARGET DECK: Python
FILE TAGS: paramètres

- STARTI [Basic] quel caractère est le marqueur "nommé-uniquement" ? Back:  `*` <!--ID: 1734166731051--> ENDI
- STARTI [Basic] params : comment appelle-t-on le marqueur `*` ? Back: le marqueur keyword-only (nommé uniquement). <!--ID: 1734166731052--> ENDI
- STARTI [Basic] quel est l'effet du paramètre `*` ? Back: Force les arguments suivants à être nommés. <!--ID: 1730827064570--> ENDI
- STARTI [Basic] dans quelle version de Python a été introduit le collecteur d'arguments positionnels `*` ? Back:  3.8 <!--ID: 1730827064574--> ENDI
- STARTI [Basic] comment forcer tous les arguments de `f(x, y)` à être passés de façon nommée ? Back:  Préfixer la liste des paramètres par le marqueur keyword-only : `f(*, x, y)` <!--ID: 1730827064572--> ENDI
- STARTI [Basic] étant donné la signature `func(a, *, b)`, que vaut `b` dans l'appel de fonction `func(1)` ? Back:  L'appel produit une `TypeError` car il manque l'argument nommé `b`. <!--ID: 1730827064576--> ENDI
- STARTI [Basic] étant donné la signature `func(a, *, b)`, que vaut `b` dans l'appel de fonction `func(1, b=2)` ? Back:  `2` <!--ID: 1730827064579--> ENDI
- STARTI [Basic] étant donné la signature `func(a, *, b)`, que vaut `b` dans l'appel de fonction `func(1, 2, b=3)` ? Back:  L'appel produit une `TypeError` car `func` prends exactement un argument positionnel. <!--ID: 1730827064581--> ENDI
