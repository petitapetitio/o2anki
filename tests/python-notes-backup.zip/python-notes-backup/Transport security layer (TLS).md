MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://en.wikipedia.org/wiki/Transport_Layer_Security
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[COMPUTER NETWORKS]]
Date : 2025-01-18
***

- Contexte
	- depuis 1999
	- successeur de [[Secure Sockets Layer (SSL)]]
	- actuellement en version 1.3 (2018)
- Mission
	- prévenir les écoutes intempestives et la falsification
	- privacy and data integrity over [[Transmission Control Protocol (TCP)|TCP]]/[[Internet Protocol (IP)|IP]]
- Fonctionnement
	- TLS handshake
		- Le client contact le serveur 
		- Le serveur répond avec son certificat (nom, certificate authority (CA), sa clé publique)
		- Le client confirme la validité du certificat (HOW ?)
		- Se mettre d'accord sur une **clé** (via un algo comme RSA, Ephemeral Diffie Hellman) 
		- Se mettre d'accord sur un **algo de chiffrement** (ChaCha20, AES GCM)
	- Secure connection (with the session key)
	- https://en.wikipedia.org/wiki/Transport_Layer_Security#Protocol_details
- Utilisé pour 
	- [[HTTPS]]
	- [[SMTP (Simple Mail Transfer Protocol)|SMTPS]]
	- [[IMAP|IMAPS]]
	- [[connection-oriented protocols]]
- en python : [[module ssl]]

Remarques
- Une version modifiée de TLS, DTLS est conçue pour fonctionner avec [[User Data Protocol (UDP)]]
- TLS 1.3 est une version optimisée de 1.2 (mais les core concepts restent les même)
- Le [[Certificat digital (certificate authority (CA)]] permet d'authentifier le serveur
- forward secrecy : même si la clé privée du serveur est compromise, les il n'est pas possible de remonter aux clés de sessions
