MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

- https://docs.python.org/3/library/argparse.html
- https://docs.python.org/3/howto/argparse.html

***
TARGET DECK: Python
FILE TAGS: 


- STARTI [Basic] `sys.argv[0]` pour `python main.py --check` ? Back:  `main.py` <!--ID: 1734710569124--> ENDI
- STARTI [Basic] argparse : quelle est la valeur par défaut de `parser.parse_args()` ? Back:  `sys.argv` <!--ID: 1734710569127--> ENDI
- STARTI [Basic] argparse : parser une flag `--formal` avec un nom court `-f` ? Back:  `parser.add_argument('--formal', '-f', action='store_true')` <!--ID: 1734710569130--> ENDI
- action
	- STARTI [Basic] argparse : un flag booléen `--formal` ? Back:  `parser.add_argument('--formal', action='store_true')` <!--ID: 1734710569132--> ENDI
	- STARTI [Basic] argparse : un champs `--file` tel que l'argument puisse être passé plusieurs fois `python main.py --file 1.txt --file 2.txt` ? Back:  `parser.add_argument("--file", action="append")` <!--ID: 1734710569134--> ENDI
- choices
	- STARTI [Basic] argparse : un champ `--type` qui accepte uniquement `a` ou `b` comme valeur ? Back:  `parser.add_argument("--type", choices=["a", "b"])` <!--ID: 1734710569138--> ENDI
- nargs
	- STARTI [Basic] argparse : comment passer les modes `"a"` et `"b"` pour `parser.add_argument("--mode", nargs='*')` ? Back:   `python main.py --mode a b` <!--ID: 1734710569140--> ENDI
	- STARTI [Basic] argparse : au moins un entier pour `--ints`" ? Back:  `parser.add_argument("--ints", nargs='+', type=int)` <!--ID: 1734710569142--> ENDI
	- STARTI [Basic] argparse : nargs = `1` ? Back: Exactement 1 (valeur par défaut) <!--ID: 1734710569144--> ENDI
	- STARTI [Basic] argparse : nargs = `*` ? Back: Zéro ou plusieurs <!--ID: 1734710569146--> ENDI
	- STARTI [Basic] argparse : nargs = `?` ? Back: Zéro ou un<!--ID: 1734710569148--> ENDI
- dest
	- STARTI [Basic]  argparse : récupérer un argument positionnel dans le champ "message" ? Back:  `parser.add_argument(dest="message")` <!--ID: 1734710569149--> ENDI
- required
	- STARTI [Basic]  argparse : un argument `--file` obligatoire ? Back:  `parser.add_argument("--file", required=True)` <!--ID: 1734710569151--> ENDI
- help
	- STARTI [Basic]  argparse : afficher la valeur par défaut de façon dynamique dans l'aide ? Back:  `%(default)s` <br> Exemple complet : `parser.add_argument('bar', default=42, help='the bar (default: %(default)s)')` affiche "the bar (default: 42)" <!--ID: 1734710569152--> ENDI



```python
parser = ArgumentParser()
parser.add_argument('--foo', required=True)
parser.parse_args(['--foo', 'BAR'])  # pour un appel manuel
parser.parse_args()  # utilise sys.argv

```
