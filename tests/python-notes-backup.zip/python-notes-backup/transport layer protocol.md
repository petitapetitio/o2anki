MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-18
***

Les plus courants en 2024 : 
- [[Transmission Control Protocol (TCP)|TCP]]/[[Internet Protocol (IP)|IP]] pour [[connection-oriented protocols]]
-  [[User Data Protocol (UDP)|UDP]]/[[Internet Protocol (IP)|IP]] pour [[connectionless protocols (datagrams)]]