MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/simple_stmts.html#grammar-token-python-grammar-nonlocal_stmt
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-25
***

***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] Que fait l'instruction `nonlocal x` ? Back: Déclare que `x` fait référence à la variable de la fonction englobante et permet de la modifier (depuis la fonction interne).<!--ID: 1730827064205--> ENDI

START
Basic
Que renvoie `outer() `
```python
def outer():  
    x = 42  
    def inner():  
        x += 1
        return x
    return inner()
```
?
Back:
`UnboundLocalError`
Une [[variable libre]] est accessible en lecture mais pas directement en écriture. 

Python interprète ici `x += 1` comme une tentative de modifier une variable locale. Il cherche `x` dans l'espace de nom local mais comme `x` n'est pas initialisée, une `UnboundLocalError` est levée. 

Pour modifier `x` dans la `inner`, il est ici faut indiquer à Python que `x`provient d'une fonction englobante à l'aide de l'instruction `nonlocal`.
<!--ID: 1730827064192-->
END


START
Basic
Qu'affiche
```python
def outer1():
	x = 1
	def outer2():
		def inner():
			nonlocal x
			x *= 10
			print(x)
		inner()
	outer2()
outer1()
````
?
Back:
`10`
`nonlocal x` cherche `x` dans les fonctions englobantes.
<!--ID: 1730827064195-->
END


START
Basic
Qu'affiche
```python
x = 0
def outer():
	def inner():
		nonlocal x
		x += 1
		print(x)
	inner()
outer()
````
?
Back:
`SyntaxError: no binding for nonlocal 'x' found`. 
`nonlocal x` cherche uniquement dans les fonctions englobantes, pas dans l'espace global.
<!--ID: 1730827064198-->
END


START
Basic
Donner un intérêt du mot clé `nonlocal` ?
Back:
Créer une [[closure]] avec un state mutable 
```python
def make_counter(): 
	count = 0
	def counter(): 
		nonlocal count
		count += 1
		return count

c = make_counter(); print(c(), c(), c())  # 1, 2, 3
```
<!--ID: 1730827064201-->
END
