MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-29
***

- Figures
	- [[Guido van Rossum]]
	- [[Python Steering Council (PSC)]]
		- Barry Warsaw
		- Gregory P. Smith
		- Pablo Galindo Salgado
		- Brett Cannon
		- Emily Morehouse
		- Carol Willing
		- Thomas Wouters
		- Alyssa Coghlan
		- Victor Stinner
	- Core Developers
	- [[Alex Martelli]]
	- [[Timothy Crosley]]
	- Tim Peters 
		- Inventeur du timsort
		- Grand gontributeur à Python
	- Carol Willing
		- one of the core dev
- Package authors
	- [[Ian Bicking]]
	- Philip J Ebi
	- [[Sébastien Eustace]]
- Entreprises
	- [[Astral]]
- Dans mon entourage
	- Vincent Poulailleau
