MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-04
***

***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] comment déclarer qu'une classe ne peut pas être héritée ? Back:  avec le décorateur `@final` <!--ID: 1730827063744--> ENDI
- STARTI [Basic] Que signifie le décorateur `@final` appliqué à une classe ? Back:  Que la classe ne peut être héritée <!--ID: 1730827063746--> ENDI
- STARTI [Basic] comment déclarer une méthode ne peut pas être surchargée ? Back:  avec le décorateur `@final` <!--ID: 1730827063748--> ENDI
- STARTI [Basic] Que signifie le décorateur `@final` appliqué à une méthode ? Back:  Que la méthode ne peut être redéfinie (surchargée) dans une classe fille <!--ID: 1730827063750--> ENDI
- STARTI [Basic] Comment indiquer qu'un nom `x: int` ne peut pas être réassigné ? Back:   `x: Final[int]` <!--ID: 1730827063752--> ENDI
- STARTI [Basic] Quelle est la différence entre `@final` et `Final` ? Back:  `@final` empêche l'héritage/surcharge, `Final` empêche la réassignation <!--ID: 1730827063757--> ENDI

START
Basic
Que signifie le typage `Final[int] = 10` ?
Back:
Que le nom ne peut pas être réassignée.

Exemple avec une [[variable globale]] : 
```python
TIMEOUT: Final[int] = 10  
TIMEOUT = 5 # ❌
```

Exemple avec un [[attribut de classe]] : 
```python
class A:
	x: Final[int] = 10
	
	def __init__(self):  
		A.x = 0 # ❌

class B(A):
    x = 20 # ❌
```

Exemple avec un [[attribut]] :
```python
class A:
	def __init__(self):  
		self._x: Final[int] = 10

	def f():
	    self._x: = 0 # ❌

```
<!--ID: 1730827063754-->
END

Ressources : 
- https://docs.python.org/fr/3.13/library/typing.html#typing.Final
- https://docs.python.org/fr/3.13/library/typing.html#typing.final