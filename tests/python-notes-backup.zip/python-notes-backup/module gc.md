MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/gc.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Garbage collection]]
Date : 2025-01-12
***


- purpose : gérer les [[mutual reference loop (cyclic garbage collections)]]
- implements the [generational pattern](<https://en.wikipedia.org/wiki/Tracing_garbage_collection#Generational_GC_(ephemeral_GC)>)
- fonctions
	- collect (force la collection des [[mutual reference loop (cyclic garbage collections)]] maintenant)
- tips
	- peut être désactivé pour améliorer les performances
	- pour savoir si ça vaut le coup, faire un benchmark avec/sans
	- ==désactiver gc affecte uniquement la collection des collections cycliques==

#### Désactiver gc affecte uniquement la collection des collections cycliques
```python
import gc
import sys
import weakref


class TraceableObject:
    def __init__(self, name):
        self.finalizer = weakref.finalize(self, lambda n: print(f"{n} a été détruit"), name)


gc.disable()
print("GC désactivé")

# Test 1 : objet simple (reference counting)
# Malgré que gc soit désactivé, x va être détruit lorsque ses références tombent à 0
print("\nTest 1: Reference counting simple")
x = TraceableObject("x")
print(f"Références vers x: {sys.getrefcount(x) - 1}")
del x

# Test 2 : Références cycliques
# Lorsque gc est désactivé, les références cycliques ne sont pas recherchées
print("\nTest 2: Références cycliques")
a = TraceableObject("a")
b = TraceableObject("b")
a.ref = b
b.ref = a
print(f"Références vers a: {sys.getrefcount(a) - 1}")
print(f"Références vers b: {sys.getrefcount(b) - 1}")
del a, b  # Ne seront PAS détruits à cause du cycle

print("\nForcer la collection des collections cycliques")
gc.collect()

gc.enable()
print("\nGC réactivé")

# GC désactivé  
#  
# Test 1: Reference counting simple  
# Références vers x: 1  
# x a été détruit  
#  
# Test 2: Références cycliques  
# Références vers a: 2  
# Références vers b: 2  
#  
# Forcer la collection des collections cycliques  
# a a été détruit  
# b a été détruit  
#  
# GC réactivé
```

#### La gc.callbacks permet de monitorer les déclenchements du gc
```python
import gc  
import sys  
import weakref  
  
  
class TraceableObject:  
def __init__(self, name):  
self.finalizer = weakref.finalize(self, lambda n: print(f"{n} a été détruit"), name)  
  
  
gc.callbacks.append(lambda phase, info: print(phase, info))  
  
a = TraceableObject("a")  
b = TraceableObject("b")  
a.ref = b  
b.ref = a  
print(f"Références vers a: {sys.getrefcount(a) - 1}")  
print(f"Références vers b: {sys.getrefcount(b) - 1}")  
del a, b

# Références vers a: 2  
# Références vers b: 2  
# b a été détruit  
# a a été détruit  
# start {'generation': 2, 'collected': 0, 'uncollectable': 0}  
# stop {'generation': 2, 'collected': 4, 'uncollectable': 0}
```
