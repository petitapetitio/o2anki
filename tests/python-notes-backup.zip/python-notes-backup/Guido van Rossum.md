
- A longtemps eu le dernier mot sur les développements (avec le titre de Benevolent Dictator For Life (BDFL))
- was a contributor of the ABC language
- son of architect and designer ? (à vérifier)


![[Guido van Rossum-1.png]]