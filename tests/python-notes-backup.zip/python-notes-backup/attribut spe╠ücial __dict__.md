MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-26
***

- https://docs.python.org/3/reference/datamodel.html#object.__dict__
- https://docs.python.org/3/reference/datamodel.html#type.__dict__


***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] quelle fonction built-in renvoie le `__dict__` d'un objet ? Back: la [[fonction native vars]] : `vars(obj)` <!--ID: 1730827064282--> ENDI
- STARTI [Basic] class : `c.__dict__` ? Back: Le dictionnaire nom-valeur des **attributs de l'instance** (qui inclut les attributs d'instance hérités) <!--ID: 1730827064284--> ENDI


START
Basic
Qu'affiche `print(B().__dict__)`
```python

class A:
    cx = 'x'
    
    def __init__(self):
        self.x = 1
    
    def f(self):
        pass


class B(A):
    cy = 'y'
    
    def __init__(self):
        super().__init__()
        self.y = 2

    def g(self):
        pass
```
?
Back:
`{'x': 1, 'y': 2}`
<!--ID: 1730827064279-->
END

START
Basic
Qu'affiche `pprint(B.__dict__)`
```python

class A:
    cx = 'x'
    
    def __init__(self):
        self.x = 1
    
    def f(self):
        pass


class B(A):
    cy = 'y'
    
    def __init__(self):
        super().__init__()
        self.y = 2

    def g(self):
        pass
```
?
Back:
```python
mappingproxy({
  '__doc__': None,
  '__init__': <function B.__init__ at 0x1030c5080>,
  '__module__': '__main__',
  'cy': 'y',
  'g': <function B.g at 0x1030c5120>
})
```
<!--ID: 1734019137974-->
END
