MOC : [[SOFTWARE ENGINEERING]]
Source :
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python|Python]], [[sequence]], [[itérable]]
Date : 2024-09-27
***

- interest : avoid error prone use of index to extract element


***
TARGET DECK: Python
FILE TAGS: unpacking

- STARTI [Basic] unpacking : Comment traduit-on l'*unpacking* en français ? Back:  dissociation, déballage, séparation <!--ID: 1728239137653--> ENDI
- STARTI [Basic] unpacking : Avec quel type de données fonctionne l'*unpacking* ? Back:  Avec toute donnée itérable <!--ID: 1728239137657--> ENDI
- STARTI [Basic] unpacking : Quels sont les cas d'usage de la dissociation (*unpacking*) ? Back:  <br>1) Assignation parallèle (`x, y = [4, 6]`). <br>2) Swapping de variables (`a, b = b, a`). <br>3) Appel de fonction `t = (20, 8); divmod(*t)`. <!--ID: 1728239137661--> ENDI
- STARTI [Basic] unpacking : Qu'affiche `a = 0; b = 1; a, b = b, a; print(a, b)` ? Back:  `1 0`  <!--ID: 1728239137665--> ENDI

START
Basic
Qu'affiche
```python
x = [0, 1]
i = 0
i, x[i] = 1, 2
print(x)
```
Back:
`[0, 2]` (et pas `[2, 1]`) - le passage _à l'intérieur_ des collections de variables que l'on assigne intervient de la gauche vers la droite et pas de façon simultanée ([[gotcha]])
<!--ID: 1730827063897-->
END
 
- STARTI [Basic] `a, b, *tail = range(5); print(a, b, tail)` ? Back:  `0 1 [2, 3, 4]` <!--ID: 1728239137673--> ENDI
- STARTI [Basic] `a, b, *tail = range(3); print(a, b, tail)` ? Back:  `0 1 [2]` <!--ID: 1728239137678--> ENDI
- STARTI [Basic] `a, b, *tail = range(2); print(a, b, tail)` ? Back:  `0 1 []` <!--ID: 1728239137682--> ENDI
- STARTI [Basic] `a, b, *tail = range(1); print(a, b, tail)` ? Back:  ValueError : not enough value to unpack (expected at least 2, got 1) <!--ID: 1728239137688--> ENDI
 
- STARTI [Basic] `a, *body, c = range(5); print(a, body, c)` ? Back:  `0 [1, 2, 3] 4` <!--ID: 1728239137692--> ENDI
- STARTI [Basic] `*head, b, c = range(5); print(head, b, c)` ? Back:  `[0, 1, 2] 3 4` <!--ID: 1728239137697--> ENDI
 
- STARTI [Basic] `*range(4), 4` (à partir de 3.5) ? Back:  `(0, 1, 2, 3, 4)` (on a bien `(*range(4), 4) == (0, 1, 2, 3, 4)`) <!--ID: 1728239137701--> ENDI
- STARTI [Basic] `[*range(4), 4]` ? Back:  `[0, 1, 2, 3, 4]` (à partir de 3.5) <!--ID: 1728239137705--> ENDI
- STARTI [Basic] `{*range(4), 4, *(5, 6, 7)}` ? Back:  `{0, 1, 2, 3, 4, 5, 6, 7}` (à partir de 3.5)  <!--ID: 1728239137710--> ENDI
 
- STARTI [Basic] Qu'affiche `a, (b, c) = "tokyo", (0, 1); print(a, b, c)` ? Back:  `'tokyo' 0 1` (dissociation imbriquée, aka nested unpacking) <!--ID: 1728239137715--> ENDI
- STARTI [Basic] Comment réécrire l'affectation `first, *middle, last = x` avec des indexations et des slices ? Back:  `first, middle, last = x[0], x[1:-1], x[-1]` <!--ID: 1728239137719--> ENDI
- STARTI [Basic] `a, b, c = 0` ? Back:  `TypeError`. L'affectation attends un itérable (ici d'exactement trois éléments). <!--ID: 1728239137723--> ENDI
 

START
Basic
Qu'affiche
```python
>>> def fun(a, b, c, d, *rest):
...     return a, b, c, d, rest
...
>>> fun(*[1, 2], 3, *range(4, 7))
```
Back:  
`(1, 2, 3, 4, (5, 6))` (à partir de 3.5)
<!--ID: 1730972172929-->
END