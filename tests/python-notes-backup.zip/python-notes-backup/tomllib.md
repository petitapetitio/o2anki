MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/tomllib.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-15
***

***
TARGET DECK: Python
FILE TAGS: stdlib


- STARTI [Basic] dans quelle version apparaît `tomlib` ? Back:  3.11 <!--ID: 1731677487725--> ENDI
- STARTI [Basic] que permet `tomlib` ? Back:  lire des fichiers `.toml` comme [[pyproject.toml]] <!--ID: 1731677487726--> ENDI

