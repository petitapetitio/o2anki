MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-24
***

***
TARGET DECK: Python
FILE TAGS: paramètres

- STARTI [Basic] à quoi sert le paramètre `**name` ? Back:  à collecter les arguments **nommés** non matchés  <!--ID: 1730827064360--> ENDI
- STARTI [Basic] comment collecter les arguments nommés non matchés ? Back:  `**name` <!--ID: 1730827064362--> ENDI
- STARTI [Basic] quelle est la différence entre les paramètres `*name` et `**name` ? Back:  `*name` collecte les arguments positionnels tandis que `**name` collecte les arguments nommés . <!--ID: 1730827064364--> ENDI
- STARTI [Basic] étant donné la signature `func(a=0, **others)` que vaut `others` dans l'appel de fonction `func(b=1, c=2)` ? Back:  `{'b': 1, 'c': 2}` <!--ID: 1730827064366--> ENDI
- STARTI [Basic] étant donné la signature `func(a=0, **others)` que vaut `others` dans l'appel de fonction `func(a=1)` ? Back:  `{}`. Un dictionnaire vide car tous les arguments nommés ont été matchés. <!--ID: 1730827064368--> ENDI
- STARTI [Basic] que signifie `kwargs` dans `**kwargs` ? Back: "keyword arguments"<br>(aka arguments nommés) <!--ID: 1730827064370--> ENDI

