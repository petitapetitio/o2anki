MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[big-O]]
Date : 2025-01-17
***

[[list]]
- implémentées avec des array (pas des listes chaînées)
- complexité des opérations
	- `l1 + l2` : `O(len(l1) + len(l2))`
	- `l * n` : `O(len(l) * n)`
	- `l[i]` / `l[i] = x` : `O(1)`
	- `len(l)` : `O(1)`
	- `l[n:m]` / `l[n:m] = range(n, m)` : `O(m-n)`
	- rebinding with a slice of different slice at a different position : 
		- longueur du slice cible + longueur du nouveau slice + nombre d'éléments de la liste cible qui se retrouvent après le slice inséré. Par exemple `[0, 1, 2, 3][1:2] = ['a', 'b', 'c']` donne `O(len([1]) + len(['a', 'b', 'c']) + len([2, 3])) = O(1 + 3 + 2)`
	- `count`, `index`, `remove`, `reverse` : `O(N)`
	- `sort` : `O(NlogN)`

[[str (chaîne de caractères)]]
- mostly O(N)
- `len(s)` : `O(1)`
- tips : use translate

[[dict]]
- implémenté avec des tables de hachage
- `get`, `setdefault`, `popitem`, `in` : O(1)
- `d1.update(d2)` : `O(len(d2))`
- `len(d)` : `O(1)`
- performances impactées par les performances de `__hash__`et de `__eq__` des clés

[[set (et frozenset)]]
- implémenté avec des tables de hachage
- ajout, suppression, test de présence : `O(1)`
- `len(s)` : `O(1)`
- performances impactées par les performances de `__hash__`et de `__eq__` des clés



![[Python in a Nutshell-3.png|400]]
