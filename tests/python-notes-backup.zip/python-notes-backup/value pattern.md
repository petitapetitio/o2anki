MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - 
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***

Reférences : 
- https://peps.python.org/pep-0634/#patterns
- https://docs.python.org/3/reference/compound_stmts.html#grammar-token-python-grammar-value_pattern

Un value pattern représente une valeur tandis qu'un [[capture pattern]] capture une valeur.

***
TARGET DECK: Python
FILE TAGS: match

- STARTI [Basic] matching : qu'est-ce qu'un value pattern ? Back: Un motif qui représente une valeur dynamique. Il prends la forme d'un nom qualifié (ex : `math.pi, Color.RED`) <!--ID: 1732172979344--> ENDI
- STARTI [Basic] matching : comment représenter une valeur dynamique dans un pattern ? Back:  avec un nom qualifié (ex : `obj.attr`) <!--ID: 1728727115308--> ENDI
- STARTI [Basic] matching: que fait un [[nom qualifié]] dans un pattern ? Back:  il représente une valeur <br>(tandis qu'un [[identifiant (nom)]] **non**-qualifié capture la valeur) <!--ID: 1728727115313--> ENDI
- STARTI [Basic] matching : comment matcher n'importe quel triplet `t` dont le premier élément vaut `x` ? Back:  `case t0, _, _ if t0 == x:` <!--ID: 1728727115315--> ENDI

START
Basic
Comment accéder à la variable globale `v` dans un pattern matching de sujet `x` ? 
Back:  
```python
import sys

...

g = sys.modules[__name__]
match x:
    case g.v:
        ...
```
[[tricks]]
<!--ID: 1728729591957-->
END
