Date : 2024-03-04
***

- équivalent de [[pyenv]] pour windows
- très pratique en vrai
- prends la version la plus récente par défaut


Commandes utiles
```shell
py        # lance la dernière version de installée
py -3     # lance la dernière version de Python 3 installée
py -3.x   # lance la version de Python 3.x (en 64 bits si installée, sinon 32)
py --list
py -h
```
