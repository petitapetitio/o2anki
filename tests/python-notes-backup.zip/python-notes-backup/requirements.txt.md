Date : 2024-01-31
***

- Fichier utilisé par pip
- Commentaires avec `#`

Ressources : 
- https://pip.pypa.io/en/latest/reference/requirements-file-format/
- https://peps.python.org/pep-0508/ (Dependency specification)

***
TARGET DECK: Python
FILE TAGS: packaging

Cartes suggérées par claude 

Q : Quel est le fichier modern standard pour décrire un projet Python et ses dépendances ? 
R : [[pyproject.toml]] (défini par PEP 518 et PEP 621)

Q : Quel est l'usage de requirements.txt en 2024 ? 
R : Approche simple pour lister les dépendances, encore utilisée pour des cas basiques mais remplacée par [[pyproject.toml]] pour les projets modernes

Q : Quelle est la différence principale entre [[1 PROJETS/The developer's brain/Notes/Python/requirements.txt|requirements.txt]] et [[pyproject.toml]] ? 
R : requirements.txt liste uniquement les dépendances, tandis que pyproject.toml décrit le projet complet (métadonnées, build, dépendances, etc.)
