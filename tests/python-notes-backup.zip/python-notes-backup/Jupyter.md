MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

- Peux être utilisé pour produire des livres interactifs très stylés (ex : https://goodresearch.dev/, https://github.com/patrickmineault/codebook, https://executablebooks.org/en/latest/)
