MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-17
***

Principes
- N'en vaut en général pas la peine.
- [[Réévalue les optimisations fine-tuning pour chaque version du langage]]

Techniques
- [[Mémoïsation]]
- [[Precomputed lookup table]]
- [[Avoid string concatenation (in Python)]]
- Searching and sorting
	- use a dict or a set if you need a lot of `x in container`
	- use attrgetter and itemgetter rather than lambda as key functions with [[fonction native sorted]]
	- consider [[module functools.heapq]] with Decorate-sort-undecorate (DSU) idiom
- Évite `from ... import *`
- [[fonctions natives exec, eval et compile]]
	- éviter d'utiliser `exec` et `eval`
	- use an explicit dict
	- compile if used more than once (same advice for eval)
- Utilise les short-circuit operators intelligemment (`if fast_function() and slow_function():`)
- Utilise des générateurs ([[Expression génératrice (Generator expression)]])
- Utilise le [[Hoisting]] pour optimiser l'accès aux attributs / méthodes dans des boucles
- Si le bottleneck est le CPU ([[CPU-bound]]), considère le [[module multiprocessing (Process-based parallelism)]]
- Si le programme est [[IO-bound]]
	- Ne récupère que ce dont tu as besoin (réduit le volume des échanges)
	- File at a time IO is fine as long as the file's data fit very comfortably in physical RAM
	- N'utilise pas `readline` sur mais loop over the file object (ps : `writelines` est ok)
	- Considère le [[module mmap (Memory-mapped file)]] for large binary files
	- Considère [[(multi)threading]] (dedicate some workers to IO, some to computations, w/ queue)
	- Considère la [[programmation asynchrone]]
