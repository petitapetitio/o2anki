MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-16
***

- STARTI [Basic] que signifie `heapq` ? Back:  heap queue <!--ID: 1734710569186--> ENDI
- STARTI [Basic] que contient le module `heapq` ? Back:  des fonctions pour manipuler des listes à la façon de tas. <!--ID: 1734710569197--> ENDI
- STARTI [Basic] quand est-ce que heapq est utile ? Back:  Maintenir une liste triée dynamiquement et accéder fréquemment au plus petit (ou plus grand). Ex : implémenter une file de priorité <!--ID: 1734710569201--> ENDI
- STARTI [Basic] quelle est la propriété intéressante d'un tas ? Back:  Le plus petit élément est toujours le premier  <!--ID: 1734710569203--> ENDI


Récupérer les k=10 plus petits élts d'une liste non triée de longueur n
```python
import heapq  
import random  
  
items = [random.randint(0, 100000) for x in range(1000)]  
heapq.nsmallest(10, items)   # O(n.log(k))
sorted(items)[:10]           # O(n.log(n))
np.partition(items, 10)[:10] # O(n) (mais nécessite numpy)
```


START
Basic
Comment implémenter une heapq avec un ordre personnalisé ? 
Back:
Utiliser l'approche DSU (decorate, sort, undecorate) : 
```python
import heapq

class KeyHeap(object):
    def __init__(self, alist, /, key):
        self.heap = [(key(o), i, o) for i, o in enumerate(alist)]
        heapq.heapify(self.heap)
        self.key = key
        if alist:
            self.nexti = self.heap[-1][1] + 1
        else:
            self.nexti = 0

    def __len__(self):
        return len(self.heap)

    def push(self, o, /):
        heapq.heappush(self.heap, (self.key(o), self.nexti, o))
        self.nexti += 1

    def pop(self):
        return heapq.heappop(self.heap)[-1]
```
<!--ID: 1734710569156-->
END
