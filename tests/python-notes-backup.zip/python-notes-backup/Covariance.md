MOC : [[SOFTWARE ENGINEERING]]
Source : [Claude](https://claude.ai/chat/d082ed21-2f65-4d99-9c54-f52afd4783be)
Projets :
Tags : 
Date : 2024-11-04
***

***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] Qu'est-ce que la covariance ? Back:  La covariance signifie que si `A` est un sous-type de `B`, alors `Container[A]` est un sous-type de `Container[B]`. <!--ID: 1730827063787--> ENDI
- STARTI [Basic] Dans quel cas la covariance est appropriée ? Back:  Pour des producteurs ou des conteneurs en lecture seule. <!--ID: 1730827063790--> ENDI
- STARTI [Basic] Comment indiquer qu'un type est covariant ? Back: `TypeVar('T', bound=Sequence, covariant=True)` <!--ID: 1733126035379--> ENDI

START
Basic
Est-il possible d'utiliser un type covariant comme paramètre ?
Back:
Non car on ne peut pas écrire de façon sûre dans un type covariant. 

Illustration : 
```python
class Box[+T]:
    def set(self, value: T): 
        ...  
            
dog_box: Box[Dog] = Box[Dog]()
animal_box: Box[Animal] = dog_box  # OK (covariance)
animal_box.set(Cat())              # écrirait un Cat dans une Box[Dog] !
```
<!--ID: 1730827063794-->
END


Ressources : 
- https://mypy.readthedocs.io/en/stable/common_issues.html#invariance-vs-covariance