MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/simple_stmts.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

Une instruction simple est une instruction composée d'une seule [[ligne logique]].

Il est possible de mettre plusieurs instructions simples sur une seule ligne avec le [[délimiteur]] `;` mais ce n'est pas dans les conventions du langage. Et [[black]] ne va pas te laisser faire.

Principales instructions simples : 
- [[expression-instruction]]
- [[affectation]]

***
TARGET DECK: Python
FILE TAGS: lexical-structure instructions

- STARTI [Basic] qu'est-ce qu'une instruction simple ? Back:  une instruction composée d'une seule [[ligne logique]] <!--ID: 1731772677680--> ENDI
- STARTI [Basic] est-il possible de mettre plusieurs instructions simples sur une seule ligne ? Back:  Oui en utilisant le séparateur `;`. Par exemple `x = 0; print(x)` mais ce n'est pas dans les conventions du langage. <!--ID: 1731772677684--> ENDI
