MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

***
TARGET DECK: Python
FILE TAGS: 

https://docs.python.org/3/library/functions.html#sum
- STARTI [Basic] `sum([1, 2], 10)` ? Back:  `13` <!--ID: 1734678007442--> ENDI
- STARTI [Basic] `sum([], 10)` ? Back:  `10` <!--ID: 1734678007443--> ENDI
- STARTI [Basic] `sum(["a", "b"])` ? Back:  <!--ID: 1734678007444--> ENDI
