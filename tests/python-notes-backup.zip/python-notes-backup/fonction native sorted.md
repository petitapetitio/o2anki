MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/functions.html#sorted
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***


***
TARGET DECK: Python

- STARTI [Basic] Comment trier une liste `l` par copie ? Back:  `sorted(l)` <!--ID: 1728627767345--> ENDI
- STARTI [Basic] Comment trier une liste `l` de façon décroissante par copie (2 façons) ? Back:  `sorted(l, reverse=True)` ou `reversed(sorted(l))` <!--ID: 1728627767353--> ENDI
- STARTI [Basic] `type(sorted((1,)))` ? Back:  `<class 'list'>` - sorted renvoie une liste quelque soit le type de l'itérable d'entrée <!--ID: 1728627767358--> ENDI ([[list]])

