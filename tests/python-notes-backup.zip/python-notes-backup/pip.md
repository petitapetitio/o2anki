MOC : 
Source : https://pip.pypa.io/en/stable/
Tags : [[Python|Python]]
Date : 2024-06-22
***

Commandes utiles : 
```shell
pip search <package-name>
pip install <package-name>
pip upgrade <package-name>
pip uninstall <package-name>

pip install "project[extra1,extra2]"
pip install "splinter[django,flask,selenium]"

# Màj les requirements
pip install --upgrade -r requirements.txt
```


- https://pip.pypa.io/en/latest/topics/vcs-support/#git

## Commandes pour [[$P - Tamis]]

Pour utiliser pip avec [[pyproject.toml]]
```
python -m pip install . --index-url https://si-devops-mirror.edf.fr/repository/pypi.python.org/simple
```

Pour utiliser pip avec le proxy EDF, utiliser 
```
--index-url https://si-devops-mirror.edf.fr/repository/pypi.python.org/simple
```

Upgrader pip
```
py -m pip install --upgrade pip --index-url https://si-devops-mirror.edf.fr/repository/pypi.python.org/simple
```

***
TARGET DECK: Python
FILE TAGS: packaging

- STARTI [Basic] Que signifie pip ? Back:  Package Installer for Python <!--ID: 1731677487782--> ENDI
- STARTI [Basic] Qui a créé pip et quand ? Back:  Ian Bicking en 2008 <!--ID: 1731677487783--> ENDI
- STARTI [Basic] Pourquoi pip a-t-il été créé ? Back:  Adresser les limites de `easy_install` ([[setuptools]]) et du manque de fonctionnalités de [[distutils]] <!--ID: 1731677487784--> ENDI
- STARTI [Basic] Qui maintient pip ? Back:  [[Python Packaging Authority (PyPA)]] (depuis 2011) <!--ID: 1731677487785--> ENDI
- STARTI [Basic] Quelle est l'outil standard pour installer des [[package]]s ? Back:  [[pip|pip]] (depuis 2013, [PEP 543](https://peps.python.org/pep-0453/)) <!--ID: 1731677487786--> ENDI
- STARTI [Basic] Quelles sont les principales alternatives à pip ? Back:  [[Poetry]], [[UV]], [[conda]], [[pipenv]] <!--ID: 1731677487787--> ENDI
- STARTI [Basic] Quelles sont les différentes sources d'installation possibles avec pip ? Back:  <br>- [[PyPI]] (par défaut) <br>- Dépôt Git (`git+https://github.com/user/project.git`)<br>- Fichier local (`--no-index --find-links=/chemin`)<br>- Index alternatif (`--index-url`, `--extra-index-url`) <!--ID: 1731677487788--> ENDI
- STARTI [Basic] Comment installer un package depuis un fichier local avec pip ? Back:  `pip install --no-index --find-links=/tmp/mypack` <!--ID: 1731677487789--> ENDI

***

PB : `AttributeError: module 'pkgutil' has no attribute 'ImpImporter'. Did you mean: 'zipimporter'?`
Solution : `python -m ensurepip --upgrade`