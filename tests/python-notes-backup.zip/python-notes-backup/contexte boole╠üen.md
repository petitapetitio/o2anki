MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-16
***



***
TARGET DECK: Python

- STARTI [Basic] Qu'est-ce qu'un contexte booléen ? Back:  un contexte dans lequel une expression est évaluée de façon booléenne. Par exemple dans le contexte d'un `if`, `if x:` équivaut à `if bool(x):`. <!--ID: 1728627767714--> ENDI