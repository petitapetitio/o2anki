MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-09
***


***
TARGET DECK: Python
FILE TAGS: match

- STARTI [Basic] pattern-matching : qu'est-ce qu'un pattern littéral ? Back:  Un pattern composé uniquement de littéraux <!--ID: 1728627767670--> ENDI
- STARTI [Basic] pattern-matching : est-ce que `[10, *_]` est un pattern littéral ? Back:  Non, c'est un [[pattern de séquence]]. <!--ID: 1728627767674--> ENDI

START
Basic
Qu'affiche
```python
match 42.0:
    case 42: print("integer")
    case 42.0: print("float")
```
?
Back:  
`integer` <br>Un pattern littéral est testé par égalité. <br>La comparaison entre un flottant et un entier commence par élever l'entier en flottant et le premier cas se trouve validé. Pour vérifier le type :  [[class pattern]].
<!--ID: 1728729591896-->
END

START
Basic
```python
def http_error(status):
    match status:
        case 400:
            return "Bad request"
        case 404:
            return "Not found"
        case 418:
            return "I'm a teapot"
        case _:
            return "Something's wrong with the internet"
```
Que renvoie `http_error(777)` ?
Back:  
`"Something's wrong with the internet"`
<!--ID: 1728729591900-->
END
