MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-10
***

- https://docs.python.org/3/library/getpass.html
- demander un mot de pass à l'utilisateur ? `getpass.getpass('Password: ')`
