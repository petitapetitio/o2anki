MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/datamodel.html#object.__getattr__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: classes dunders

- STARTI [Basic] `x.__getattr__('attr')` ? Back:  La valeur de l'attribut ou lève une `AttributeError` si l'attribut n'existe pas. <!--ID: 1730827064475--> ENDI

START
Basic
Quelle est la différence entre `__getattribute__` et `__getattr__` ?
Back:
`__getattribute__` est appelé en premier. 
`__getattr__` est appelé en dernier recours.

Ex : 
```python
class A:
    def __getattribute__(self, item):
        print("__getattribute__")
        raise AttributeError

    def __getattr__(self, item):
        print("__getattr__")
        return 1

A().x
# Affiche : 
# __getattribute__
# __getattr__
```
<!--ID: 1730827064473-->
END
