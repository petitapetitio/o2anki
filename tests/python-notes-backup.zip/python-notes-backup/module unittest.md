MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Testing]]
Date : 2025-01-14
***

- https://docs.python.org/3/library/unittest.html#module-unittest
- inspiré du framework développé par [[Kent Beck]] pour Smalltalk
- concepts clé
	- test fixture
	- test case 
	- test suite
- TestCase
	- assert*
	- setUp / tearDown / addCleanup 
	- subTest (renvoie un context manager)
	- fail
