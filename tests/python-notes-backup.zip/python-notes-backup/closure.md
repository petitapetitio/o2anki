MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-25
***

Exemple
```python
def outer():
    x = 10  # Variable capturée par la closure
    def inner():
        print(x)  # Accès à la variable capturée
    return inner

closure = externe()
closure()
```

***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] qu'est-ce qu'une closure ? Back: Une fonction interne qui garde accès aux variables d'une fonction englobante, même après que celle-ci a terminé. <!--ID: 1730827064262--> ENDI

START
Basic
qu'est-ce qu'un cas d'usage typique des closures ?
Back:
Créer une fonctions avec des paramètres prédéfinis.
```python
def multiplieur(x):
    def multiplier(n):
        return n * x
    return multiplier

doubler = multiplieur(2) # fixe x à 2
print(doubler(5))        # 10
```
<!--ID: 1730827064264-->
END