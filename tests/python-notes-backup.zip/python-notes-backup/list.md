MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/stdtypes.html#list
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***

Une liste est une séquence mutable ordonnée d'éléments - de type arbitraire et pouvant être différents.

***
TARGET DECK: Python
FILE TAGS: list

- STARTI [Basic] Qu'est-ce qu'un objet de type `list` ? Back: Une séquence mutable d'éléments de types arbitraires. (`list` implémente l'interface `MutableSequence`) <!--ID: 1728024344657--> ENDI
- STARTI [Basic] Comment créer une liste vide ? Back:  `[]` ou `list()` <!--ID: 1728024344660--> ENDI
- STARTI [Basic] Comment créer une liste avec un seul élément `100` ? Back:  `[100]` <!--ID: 1728024344663--> ENDI
- STARTI [Basic] Que donne `list('wow')` ? Back:  `['w', 'o', 'w']` : lorsque `x` est itérable, `list(x)` renvoie une liste dont les éléments sont les mêmes que ceux de `x`. <!--ID: 1728024344667--> ENDI
- STARTI [Basic] Est-ce que la liste `[1, 'hello', true]` est littérale ? Back:  Oui - car elle est entièrement constituée de littéraux. <!--ID: 1728024344671--> ENDI
- STARTI [Basic] Est-ce que la liste `[1, x, true]` est littérale ? Back:  Non - car la variable `x` n'est pas un littéral. <!--ID: 1728024344676--> ENDI


tri en place
- STARTI [Basic] Comment trier une liste `l` en place ? Back:  `l.sort()` <!--ID: 1728627767680--> ENDI
- STARTI [Basic] Comment trier une liste `l` en place de façon décroissante ? Back:  `l.sort(reverse=True)` <!--ID: 1728627767684--> ENDI
- STARTI [Basic] Comment fonctionne `l.sort(key=f)` ? Back:  Le tri compare `f(x)` et `f(y)` plutôt que `x` et `y`.  <!--ID: 1728627767688--> ENDI
- STARTI [Basic] Est-ce que `l.sort(reverse=true)` et `list(reversed(sorted(l)))` produisent  le même résultat ? Back:  Pas toujours.<br><br>Ex : `l = [y_1, y_2]` où `y_1 == y_2` mais `id(y_1) != id(y_2)`. <br><br>`l.sort(reverse=True)` produit `[y_1, y_2]` (le tri est stable)<br>`list(reversed(sorted(l)))` produit `[y_2, y_1]` <br>([[gotcha]]) <!--ID: 1728627767692--> ENDI

