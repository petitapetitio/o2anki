MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/functions.html#max
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***


***
TARGET DECK: Python
FILE TAGS: std-functions

- STARTI [Basic] le maximum de `1`, `3` et `2` ? Back:  `max(1, 3, 2)` <!--ID: 1728627767423--> ENDI
- STARTI [Basic] le maximum de la liste numérique `x = [1, 3, 2]` ? Back:  `max(x)` <!--ID: 1728627767427--> ENDI
- STARTI [Basic] `max([1, 2, 3], [2], [1])` ? Back:  `[2]`. L'ordre sur les listes est l'ordre lexicographique. <!--ID: 1728627767431--> ENDI
- STARTI [Basic] le max des listes `l1`, `l2` et `l3` par longueur ? Back:  `max(l1, l2, l3, key=len)` <!--ID: 1728627767435--> ENDI
- STARTI [Basic] le max des entiers `1`, `2` et `-4` en fonction de leur carré ? Back:  `max(1, 2, -4, key=lambda e: e ** 2)` <!--ID: 1728627767439--> ENDI
- STARTI [Basic] `max([])` ? Back:  `ValueError: max() iterable argument is empty` <!--ID: 1728627767444--> ENDI
- STARTI [Basic] Comment renvoyer une valeur par défaut lorsque l'argument de `max` est un itérable vide ? Back:  `max([], default=0)` <!--ID: 1728627767449--> ENDI


START
Basic
Comment calculer le maximum entre `p1`, `p2`, et `p3` de type `Point` ? 
```python
class Point:
    def __init__(self, x, y):
        self._x = x
        self._y = y

    def length(self):
        return sqrt(self._x * self._x + self._y * self._y)

    def __repr__(self):
        return f"Point({self._x}, {self._y})"
```
Back:  
`max([p1, p2, p3], key=Point.length)`<br>ou <br>`max(p1, p2, p3, key=Point.length)`
<!--ID: 1728627767418-->
END
