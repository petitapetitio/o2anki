MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/sqlite3.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-11
***

- driver python pour [[SQLLite]]
- référence
	- fonctions principales
		- connect
		- register_adapter
		- register_converter
	- Connection
		- create_function
		- isolation_level (readonly)
		- commit/rollback automatiquement lorsqu'utilisé comme [[Context Manager]]
	- Row
