MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/stdtypes.html#set
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***

Un set est une collections d'éléments uniques. Les éléments peuvent être de types différents. Les éléments doivent être *hashable* - et donc immutables.

***
TARGET DECK: Python
FILE TAGS: set

- STARTI [Basic] Qu'est-ce qu'un set ? Back: une collections d'éléments uniques de types arbitraires. <!--ID: 1728024344639--> ENDI
- STARTI [Basic] Quelle est la condition à remplir pour qu'un élément soit placé dans un `set` ? Back: Il doit être hashable. <!--ID: 1728024344641--> ENDI
- STARTI [Basic] Quelle est la principale différence entre un `set` et un `frozenset` ? Back:  Un `frozenset` est immutable. <!--ID: 1728024344643--> ENDI
- STARTI [Basic] Quelles sont les deux façons de créer un ensemble vide ? Back:  `set()`. Il n'y en a qu'une. Le littéral `{}` crée un dictionnaire vide. ([[gotcha]]) <!--ID: 1728024344645--> ENDI
- STARTI [Basic] `{1} == {1,}` ? Back: Oui. Les deux littéraux crée le même `set` singleton `{1}`. La virgule de fin est optionnelle. <!--ID: 1728024344648--> ENDI
- STARTI [Basic] `{1, 2} == {2, 1}` ? Back:  Oui - la comparaison de deux sets ne tient pas compte de l'ordre d'insertion. <!--ID: 1728024344650--> ENDI
- STARTI [Basic] `{[1, 2, 2]}` ? Back:  `TypeError` car le type `list` n'est pas hachable. ([[gotcha]])  <!--ID: 1728024344653--> ENDI



opérations non mutatives
- STARTI [Basic] sets : comment obtenir une copie superficielle de `s` ? (2 façons) Back:  <br>`s.copy()` <br>`set(s)` / `frozenset(s)` <br><!--ID: 1728627767511--> ENDI
- STARTI [Basic] sets : quels sont les éléments qui sont dans `s1` mais pas dans `s2` ? (2 façons) Back:  `s1.difference(s2)` ou `s1 - s2` <!--ID: 1728627767515--> ENDI
- STARTI [Basic] `{1, 2} - {2, 3}` ? Back:  `{1}` <!--ID: 1728627767519--> ENDI
- STARTI [Basic] sets : quels sont les éléments qui sont à la fois dans `s1` et dans `s2` ? (2 façons) Back:  `s1.intersection(s2)` ou `s1 & s2` <!--ID: 1728627767523--> ENDI
- STARTI [Basic] `{1, 2} & {2, 3}` ? Back:  `{2}` <!--ID: 1728627767527--> ENDI
- STARTI [Basic] sets : quels sont les éléments qui sont au moins dans `s1` ou dans `s2` ? (2 façons) Back:  `s1.union(s2)` ou `s1 | s2` <!--ID: 1728627767531--> ENDI
- STARTI [Basic] `{1, 2} | {2, 3}` ? Back:  `{1, 2, 3}` <!--ID: 1728627767535--> ENDI
- STARTI [Basic] sets : quels sont les éléments qui sont dans `s1` ou dans `s2` mais pas dans les deux ? (2 façons) Back:  `s1.symmetric_difference(s2)` ou `s1 ^ s2`. <!--ID: 1728627767541--> ENDI
- STARTI [Basic] `{1, 2} ^ {2, 3}` ? Back:  `{1, 3}` <!--ID: 1728627767547--> ENDI
- STARTI [Basic] sets : comment savoir si l'intersection de `s1` et `s2` est vide ? Back:  `s1.isdisjoint(s2)` <!--ID: 1728627767551--> ENDI
- STARTI [Basic] sets : comment savoir si tous les éléments de `s1` sont dans `s2` ? Back:  `s1.issubset(s2)` ou `s1 <= s2` <!--ID: 1728627767555--> ENDI
- STARTI [Basic] sets : comment savoir si `s1` contient tous les éléments de `s2` ? Back:  `s1.issuperset(s2)` ou `s1 >= s2` <!--ID: 1728627767561--> ENDI
- STARTI [Basic] `{0} <= {1}` ? Back:  `False` : `{0}` n'est pas un sous-ensemble de `{1}` ([[gotcha]])<!--ID: 1728627767558--> ENDI

opérations mutatives
- STARTI [Basic] sets : comment ajouter l'élément `x` à `s` (en place) ? Back:  `s.add(x)` <!--ID: 1728627767567--> ENDI
- STARTI [Basic] `s = {1, 2, 3}; s.add(4); s` ? Back:  `{1, 2, 3, 4}` <!--ID: 1728627767570--> ENDI
- STARTI [Basic] `s = {1, 2, 3}; s.add(3); s` ? Back:  `{1, 2, 3}` -  `s` n'est pas modifié car l'élément était déjà présent <!--ID: 1728627767573--> ENDI
- STARTI [Basic] sets : comment vider `s` ? Back:  `s.clear()` <!--ID: 1728627767576--> ENDI
- STARTI [Basic] `s = {1, 2, 3}; s.clear(); s` ? Back:  `set()` - (remember that `{}` est un dictionnaire) <!--ID: 1728627767579--> ENDI
- STARTI [Basic] sets : comment retirer `x` de `s` sans lever d'exception si `x` n'est pas dans `s` ? Back:  `s.discard(x)` <!--ID: 1728627767583--> ENDI
- STARTI [Basic] `s = set(); s.discard(1); s` ? Back:  `set()` <!--ID: 1728627767588--> ENDI
- STARTI [Basic] sets : comment retirer `x` de `s` en levant une exception si `x` n'est pas dans `s` ? Back:  `s.remove(x)` <!--ID: 1728627767592--> ENDI
- STARTI [Basic] `s = set(); s.remove(1); s` ? Back:  `KeyError` <!--ID: 1728627767596--> ENDI
- STARTI [Basic] sets : comment retirer un élément arbitraire de `s` et récupérer la valeur ? Back:  `s.pop()` <!--ID: 1728627767600--> ENDI
- STARTI [Basic] `{3, 2, 7}.pop()` ? Back:  renvoie un élément arbitraire de l'ensemble. (même daprès 3.7 : https://docs.python.org/3/library/stdtypes.html#frozenset.pop) <!--ID: 1728627767604--> ENDI
- STARTI [Basic] `set().pop()` ? Back:  `KeyError` <!--ID: 1728627767608--> ENDI
- STARTI [Basic] sets : que produit `s.add(5)` dans une boucle `for x in s` ? Back:  `RuntimeError` : on ne peut pas ajouter ou supprimer des éléments d'un ensemble alors qu'on itère dessus.  <!--ID: 1728627767613--> ENDI
- STARTI [Basic] sets : comment ajouter dans `s1` les éléments de `s2` (en place) ? (2 façons) Back:  `s1.update(s2)` ou `s1 |= s2` <!--ID: 1728627767617--> ENDI
- STARTI [Basic] Sets : comment ne conserver dans `s1` que les éléments qui sont aussi présents dans `s2` ? (2 façons) Back:  `s1.intersection_update(s2)` ou `s1 &= s2` <!--ID: 1728627767621--> ENDI
- STARTI [Basic] Sets : comment ne conserver dans `s1` que les éléments qui ne sont pas présents dans `s2` ? (2 façons) Back:  `s1.difference_update(s2)` ou `s1 -= s2` <!--ID: 1728627767625--> ENDI
- STARTI [Basic] Sets : comment mettre dans `s1` les éléments qui sont dans `s1` ou dans `s2` mais pas dans les deux ? (2 façons) Back:  `s1.symmetric_difference_update(s2)` ou `s1 ^= s2` <!--ID: 1728627767630--> ENDI
- STARTI [Basic] `s1 = {1, 2}; s1.update({2, 3}); s1` ? Back:  `{1, 2, 3}` <!--ID: 1728627767634--> ENDI
- STARTI [Basic] `s1 = {1, 2}; s1.intersection_update({2, 3}); s1` ? Back:  `{2}` <!--ID: 1728627767638--> ENDI
- STARTI [Basic] `s1 = {1, 2}; s1.difference_update({2, 3}); s1` ? Back:  `{1}` <!--ID: 1728627767643--> ENDI
- STARTI [Basic] `s1 = {1, 2}; s1.symmetric_difference_update({2, 3}); s1` ? Back:  `{1, 3}` <!--ID: 1728627767647--> ENDI
- STARTI [Basic] `s1 = {1, 2}; s1 |= {2, 3}; s1` ? Back:  `{1, 2, 3}` <!--ID: 1728627767652--> ENDI
- STARTI [Basic] `s1 = {1, 2}; s1 &= {2, 3}; s1` ? Back:  `{2}` <!--ID: 1728627767656--> ENDI
- STARTI [Basic] `s1 = {1, 2}; s1 -= {2, 3}; s1` ? Back:  `{1}` <!--ID: 1728627767660--> ENDI
- STARTI [Basic] `s1 = {1, 2}; s1 ^= {2, 3}; s1` ? Back:  `{1, 3}` <!--ID: 1728627767664--> ENDI
- STARTI [Basic] `s1 = {1, 2}; s1 += {2, 3}; s1` ? Back:  `TypeError` : l'opérateur de concaténation augmentée n'a pas de sens pour les ensembles. On utilise `|=` ([[gotcha]]) <!--ID: 1731772677667--> ENDI
- STARTI [Basic] Quels sont les 4 opérateurs d'assignation augmentées pour les sets ? Back:  <br>`s |= other`    union en place<br>`s &= other`    intersection en place<br>`s -= other`    différence en place<br>`s ^= other`    différence symétrique en place <br><!--ID: 1731772677672--> ENDI


START
Basic  
Quel es l'intérêt de l'approche destructive
```python
while s:
    item = s.pop()
    ...
```
par rapport à l'approche non destructive
```python
for item in s:
	...
```
Back:  
1) l'approche destructive consomme moins de mémoire
2) l'approche destructive permet des opérations de modification comme `s.add`
END
