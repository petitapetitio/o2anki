MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

- Un fichier `.py` est un fichier texte qui contient du code python.
- Peut être à la fois un [[script python]] et un [[module]].
- Contient des [[variable]], [[Fonctions]], [[classe]]
- une suite d' [[instruction simple (simple statement)]] et d'[[instruction composée (compound statements)

***
TARGET DECK: Python

STARTI [Basic] Quel est l'encodage attendu par défaut par l'interpréteur python ? Back: UTF-8 <!--ID: 1727542890126--> ENDI