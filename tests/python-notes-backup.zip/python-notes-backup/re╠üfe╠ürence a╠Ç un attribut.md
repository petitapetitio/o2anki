MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-28
***

***
TARGET DECK: Python
FILE TAGS: classes

STARTI [Basic] Qu'est-ce qu'une référence à un attribut ? Back:  Back:  une expression de la forme `x.name` où `x` est une expression et `name` est un [[identifiant (nom)]] appelé nom de l'attribut. <!--ID: 1730827064322--> ENDI ENDI


START
Basic
Quel est l'algorithme de résolution d'une demande d'accès à **attribut de classe** `C.attr` ?
Back:
Python regarde dans les dictionnaires de classe en remontant la chaîne d'héritage ([[Method resolution order (MRO)]]) jusqu'à trouver l'attribut ou lever une AttributeError.
<!--ID: 1730827064319-->
END

```mermaid
flowchart TD
    A[C.name] --> B{"name in C.#95;#95;dict__ ?"}
    B -->|Oui| C["v = C. #95;#95;dict__[name]"]
    B -->|Non| D[Regarder dans les classes de base]
    C --> E{v fournit #95;#95;get__ ?}
    E -->|Oui| F["← type(v).#95;#95;get__(v, None, C)"]
    E -->|Non| G["← v"]
```


START
Basic
Quel est l'algorithme de résolution d'une demande d'accès à **attribut d'instance** `c.attr` ?
Back:
Python cherche d'abord dans l'instance (`c.__dict__`, `c.__slots__`), puis remonte les dictionnaires de classe en suivant la chaîne d'héritage ([[Method resolution order (MRO)]]), jusqu'à trouver l'attribut ou lever une erreur.
<!--ID: 1730827064320-->
END

STARTI [Basic] La création d'un attribut suit-elle un algorithme de résolution comme l'accès à un attribut ? Back:  Non - l'attribut est directement créé dans le dictionnaire de la cible (sauf interception par  `__setattr__`ou descripteur). <!--ID: 1730827064325--> ENDI

