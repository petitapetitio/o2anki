MOC : [[SOFTWARE ENGINEERING]]
Source : https://flit.pypa.io/en/stable/
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-15
***

- focus = simplicité
- fonctionnalités : build and upload (sans utiliser ni [[setuptools]] ni [[twine]])
- https://pypi.python.org/pypi/flit
- https://packaging.python.org/en/latest/key_projects/#flit