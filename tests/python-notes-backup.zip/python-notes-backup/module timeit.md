MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/timeit.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[benchmarking]]
Date : 2025-01-17
***

###### Exemple : comparer les performances de `x=x+1` vs `x+=1`

Dans le terminal
```
python -m timeit -s 'x=0' 'x=x+1'
python -m timeit -s 'x=0' 'x+=1'
```

Dans le code
```python
# Avec exec  
time = timeit.timeit('x+1', setup='x=0', number=10000)

# Avec des lambdas
# ATTENTION à l'overhead avec les lambdas
x = 0 # to satisfy the compiler  
time = timeit.timeit(lambda: x+1, setup='x=0', number=10000)
```
