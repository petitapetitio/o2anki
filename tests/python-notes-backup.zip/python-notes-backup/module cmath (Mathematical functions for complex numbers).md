MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- https://docs.python.org/3/library/cmath.html
- [[module math (Mathematical functions)]] mais pour les [[nombres complexes (complex)]]
