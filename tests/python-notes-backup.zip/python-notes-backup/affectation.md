MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Notions de base du développement]]
Date : 2024-09-28
***

- "assignement"
- assigne une valeur à une variable

Exemple d'affectation en python
```python
a = 1
```

[[instruction d'assignation]]