MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://en.wikipedia.org/wiki/Berkeley_sockets
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-18
***

- contexte
	- créé dans les années 80
	- aka Berkeley Socket Interface (aka Socket)
	- aka BSD Sockets
- pipelines between independent endpoints using a [[transport layer protocol]] to move info
- une implémentation du [[Client-Server networking]]
- like [[module queue (A synchronized queue class)]], but over a network
- principales familles 
	- internet sockets ([[Transmission Control Protocol (TCP)|TCP]]/[[Internet Protocol (IP)|IP]], [[User Data Protocol (UDP)|UDP]]/[[Internet Protocol (IP)|IP]] communications)
		- endpoints identifiées par : adresse IP, port number, protocol
		- les connected sockets sont aussi associées à un "remote endpoint"
	- unix sockets (sur une même machine)
	- **botch support connectionless and connection-oriented networking**
