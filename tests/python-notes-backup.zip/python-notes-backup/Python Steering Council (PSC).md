MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

Ressources : 
- https://realpython.com/lessons/python-steering-council/
- https://hugovk.github.io/python-steering-council/
- https://stackoverflow.blog/2023/07/21/what-its-like-to-be-on-the-python-steering-council-ep-592/