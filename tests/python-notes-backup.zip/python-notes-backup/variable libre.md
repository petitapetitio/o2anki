MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/fr/3/glossary.html#term-free-variable
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Espace de nom des fonctions]]
Date : 2024-10-25
***

***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] Qu'est-ce qu'une variable libre ? Back: Une variable d'une fonction englobante qui est accessible depuis une fonction interne. <!--ID: 1730827064121--> ENDI

START
Basic
`outer()` ?
```python
def outer():  
    x = 42  
    def inner():  
        return x
    return inner()
```
?
Back:
`42` 
La fonction interne `inner` lire la variables libre `x` de sa fonction englobante.
<!--ID: 1730827064119-->
END


