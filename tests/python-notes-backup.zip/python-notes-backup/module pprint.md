MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/pprint.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: strings

- STARTI [Basic] afficher un grand dictionnaire de façon lisible dans la console ? Back:  `pprint.pprint(d)` <!--ID: 1734713099685--> ENDI
- STARTI [Basic] récupérer la chaîne de caractère produite par `pprint` ? Back:  `pprint.pformat(d)` <!--ID: 1734713099686--> ENDI

