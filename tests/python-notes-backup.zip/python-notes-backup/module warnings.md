MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/warnings.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-15
***

- classe Warning
	- étend la classe `Exception` (et sont techniquement des [[exceptions built-in]])
	- sous-classes principales
		- DeprecationWarning : features which are still supplied for backward compatibility
		- RuntimeWarning
		- SyntaxWarning
		- UserWarning
- fonctions
	- émettre un warning
		- `warn`
		- `@deprecated("Use g instead")`
	- `formatwarning` : customiser le formattage d'un warning
	- `showwarning` : fonction appelée en interne pour afficher (peut être redéfinie)
- filtres
	- déterminent si un warning doit être affiché ou non
	- ajouter un filtre : 
		- `filterwarnings`
		- `simplefilter`
		- option `-W` ([exemples](https://docs.python.org/3/library/warnings.html#describing-warning-filters))
		- variable d'env `PYTHONWARNINGS`
	- réinitialiser les filtres : `resetwarnings`
- tips
	- pour rediriger vers le [[module logging]], utiliser `logging.captureWarnings(True)`
	- il est possible de catcher les warnings via un context manager ([doc](https://docs.python.org/3/library/warnings.html#temporarily-suppressing-warnings))
	- il est possible de capturer les warnings pour les tester ([doc](https://docs.python.org/3/library/warnings.html#testing-warnings))
	- il est possible d'émettre au nom de l'appelant : `warnings.warn(message, DeprecationWarning, stacklevel=2)`
