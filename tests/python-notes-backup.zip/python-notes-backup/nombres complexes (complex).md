MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***


***
TARGET DECK: Python
FILE TAGS: stdtypes

- STARTI [Basic] Comment sont constitués les complexes ? Back: Ils sont constitué des deux flottants : un pour la partie imaginaire et un pour la partie réelle. <!--ID: 1727939491266--> ENDI
- STARTI [Basic] Comment écrire `1i` avec un littéral complexe ? Back: `1j`  <!--ID: 1727939491275--> ENDI
- STARTI [Basic] Qu'affiche `1 + 2j` ? Back: `(1+2j)` <!--ID: 1727939491280--> ENDI
