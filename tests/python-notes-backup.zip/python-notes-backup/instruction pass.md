MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***


***
TARGET DECK: Python
FILE TAGS: pass

- STARTI [Basic] Est-ce que le corps d'une instruction composée peut-être vide ? Back:  Non, il doit toujours contenir au moins une instruction. <!--ID: 1728749077204--> ENDI
- STARTI [Basic] Que fait l'instruction `pass` ? Back:  Rien. <!--ID: 1728749077213--> ENDI
- STARTI [Basic] À quoi sert l'instruction `pass` ? Back: placer une instruction qui ne fait rien dans les cas où la syntaxe exige une instruction. Ex : créer une classe vide, une def vide, un `case` avec une suite qui ne fait rien. <!--ID: 1728749077219--> ENDI


START
Basic
Comment créer une fonction vide ?
Back: 
```python
def do_nothing():
	pass
```
<!--ID: 1728749077180-->
END

START
Basic
Comment créer une classe vide ?
Back: 
```python
class A:
    pass
```
ou 
```python
class A:
    """
    Une classe vide
    """
```
(approche recommandée)
<!--ID: 1728749077194-->
END
