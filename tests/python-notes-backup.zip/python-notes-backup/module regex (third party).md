MOC : [[SOFTWARE ENGINEERING]]
Source : https://pypi.org/project/regex/
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Regular Expression]]
Date : 2025-01-14
***

étend les fonctionnalités du [[module re]] : 
- multithreading
- full unicode support
- nested sets
