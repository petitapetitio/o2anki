MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://www.pypa.io
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-14
***


***
TARGET DECK: Python
FILE TAGS: packaging

- STARTI [Basic] Que signifie PyPA ? Back:  Python Packaging Authority <!--ID: 1731677487748--> ENDI
- STARTI [Basic] Qu'est-ce que Python Packaging Authority ? Back: Une organisation déléguée par le [[Python Steering Council (PSC)]] pour standardiser et maintenir l'écosystème de packaging et de distribution Python, via des PEPs et des outils de référence.  <!--ID: 1731677487749--> ENDI
- STARTI [Basic] Quand PyPA a-t-il été créé ? Back:  2011 <!--ID: 1731677487750--> ENDI
- STARTI [Basic] Pourquoi est-ce que PyPA a-t-il été créé initialement ? Back:  Prendre en charge la maintenance de [[pip]] et de [[virtualenv]] <!--ID: 1731677487751--> ENDI
- STARTI [Basic] Quels sont les 3 projets majeurs maintenus par PyPA ? Back: <br>[[pip]], [[virtualenv]] et [[setuptools]] <br>(la liste complète est disponible [ici](https://packaging.python.org/en/latest/key_projects/#pypa-projects)) <br><!--ID: 1731677487753--> ENDI



Ressources : 
- https://www.pypa.io/en/latest/history/
- https://packaging.python.org/en/latest/key_projects/#pypa-projects