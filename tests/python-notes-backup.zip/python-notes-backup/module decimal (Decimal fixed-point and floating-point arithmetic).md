MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- https://docs.python.org/3/library/decimal.html
- https://docs.python.org/3/library/decimal.html#recipes
- idéal pour les opérations sur la monnaie

```python

# Créer un décimal

Decimal(1)      # Decimal('1')
Decimal('3.3')  # Decimal('3.3')
Decimal((3, 3)) # Decimal('3.3')

Decimal(1.1)    # Decimal('1.100000000000000088817841970012523233890533447265625')
Decimal(1.1).quantize(Decimal('.00')) # Decimal('0.10')

Decimal((0, (3, 1, 4), -2)) # Decimal('3.14')
Decimal((1, (3, 1, 4), -2)) # Decimal('-3.14')


# Les arrondis se font au chiffre le plus proche qui est pair

round(Decimal('1.5')) == 2
round(Decimal('2.5')) == 2  # et pas 3 ! 


# Opérations

Decimal('1.33') * 3 == Decimal('3.99')
Decimal('1.33') + Decimal('1.27') == Decimal('2.60')

Decimal('4.00') / 3 == Decimal('1.333333333333333333333333333')
(Decimal('4.00') / 3).quantize(Decimal('.00')) == Decimal('1.33')
```
