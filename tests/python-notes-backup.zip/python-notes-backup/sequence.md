MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[module collections (python) 🌟]]
Date : 2024-10-05
***

Référence : 
- https://docs.python.org/fr/3.13/glossary.html#term-sequence
- https://docs.python.org/fr/3.13/library/collections.abc.html#collections.abc.Sequence

***
TARGET DECK: Python
FILE TAGS: sequence

- STARTI [Basic] Qu'est-ce qu'une séquence ? Back: Une collection d'éléments <br>- de type arbitraire <br>- indexés par des entiers consécutifs de 0 à `len(seq)-1` <br>- accessibles directement via leur index<!--ID: 1728024344797--> ENDI
- STARTI [Basic] Quelles sont les séquences concrètes built-in ? Back: <br>[[str (chaîne de caractères)]], <br>[[bytes]], [[bytearray]], <br>[[tuple]], <br>[[list]] <br><!--ID: 1728024344800--> ENDI


![[sequence-1.png|400]]