MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***

***
TARGET DECK: Python
FILE TAGS: break

- STARTI [Basic] Que fait l'instruction break ? Back:  Elle termine la boucle (sans exécuter la clause `else` lorsqu'il y en a une). <!--ID: 1728749077278--> ENDI
- STARTI [Basic] Où peut-on utiliser l'instruction break ? Back: Dans le corps d'une boucle ([[instruction for]], [[instruction while]]). <!--ID: 1728749077284--> ENDI

START
Basic
Comment implémenter une structure "loop and a half" en Python ?
Back: 
```python
while True:
    ...
    if condition:
        break
    ...
```
RQ : le nom loop and a half vient de Donald Knuth
<!--ID: 1728749077271-->
END

START
Basic
Qu'affiche 
```python
for i in [0, 1, 2, 3, 4]:  
	if i % 2 == 1:  
		break  
	print(i)
```
?
Back:
```
0
```
L'instruction `break` termine l'instruction `for` intérieure dès que `i` passe à `1`.
<!--ID: 1728749077274-->
END
