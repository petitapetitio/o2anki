MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- peut survenir lorsque tu utilises des [[threading.Lock]]
- comment les prévenir en Python
	- utiliser les context manager (pour ne pas oublier de release le [[threading.Lock]])
	- utilise [[threading.RLock]] (pour permette à un même thread de prendre plusieurs fois le même lock)


##### Exemple de deadlock
```python
import threading  
  
l = threading.Lock()  
print("before first acquire")  
l.acquire()  
print("before second acquire")  
l.acquire()  
print("acquired lock twice")  
  
# before first acquire  
# before second acquire
```

Utiliser [[threading.RLock]] résout le problème ici : 
```python
import threading

l = threading.RLock()
print("before first acquire")
l.acquire()
print("before second acquire")
l.acquire()
print("acquired lock twice")

# before first acquire
# before second acquire
# acquired lock twice
```