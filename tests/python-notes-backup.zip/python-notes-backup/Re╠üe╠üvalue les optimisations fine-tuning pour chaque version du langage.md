MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-17
***

Les performances du benchmark suivant varient avec les versions de python
```python
import operator
import timeit


def slow(asequence):
    result = []
    for x in asequence:
        result.append(-x)
    return result


def middling(asequence):
    return list(map(operator.neg, asequence))


def fast(asequence):
    return [-x for x in asequence]


for afunc in slow, middling, fast:
    timing = timeit.repeat(
        'afunc(big_seq)',
        setup='big_seq=range(500*1000)',
        globals={'afunc': afunc},
        repeat=5,
        number=100,
    )
    for t in timing:
        print(f'{afunc.__name__},{t}')
```
![[Python in a Nutshell-7.png]]
