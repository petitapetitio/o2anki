MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/functions.html#any
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

***
TARGET DECK: Python
FILE TAGS: 

- STARTI [Basic] `any([0, False, None])` ? Back:  `False` <!--ID: 1734678007474--> ENDI
- STARTI [Basic] `any([1, False, None])` ? Back:  `True` <!--ID: 1734678007475--> ENDI
- STARTI [Basic] Est-il possible de passer une fonction d'évaluation à `any` ? Back:  Non <!--ID: 1734678007476--> ENDI

