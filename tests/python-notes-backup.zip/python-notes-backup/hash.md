MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[set (et frozenset)]]
Date : 2024-10-26
***


***
TARGET DECK: Python
FILE TAGS: hachage


https://docs.python.org/fr/3/glossary.html#term-hashable

- STARTI [Basic] qu'est-ce qu'un hash ? Back:  un entier calculé à partir d'un objet. Python l'utilise pour retrouver et comparer rapidement des objets (notamment dans les sets et les dicts). <!--ID: 1730827063866--> ENDI
- STARTI [Basic] qu'est-ce qu'un objet hashable ? Back: un objet dont le hash est constant toute la durée de vie de l'objet.<br>Ex : les objets immutables.  <!--ID: 1730827063869--> ENDI
- STARTI [Basic] que peut un élément hashable ? Back: <br>- être placé dans un [[set (et frozenset)]] <br>- être utilisé comme clé d'un [[dict]]. <!--ID: 1730827063870--> ENDI

Exemples
- STARTI [Basic] hash : est-ce que `"hello"` est hashable ? Back:  Oui <!--ID: 1730827063873--> ENDI
- STARTI [Basic] hash : est-ce que `True` est hachable ? Back:  Oui  <!--ID: 1730827063875--> ENDI
- STARTI [Basic] hash : est-ce que `[1, 2]` est hachable ? Back:  Non : les collections built-in mutables ne sont pas hachables. <!--ID: 1730827063877--> ENDI
- STARTI [Basic] hash : est-ce que `(1, 2)` est hachable ? Back:  Oui : les collections built-in immutables sont pas hachables si leurs éléments sont hachables.  <!--ID: 1730827063879--> ENDI
- STARTI [Basic] hash : est-ce que `(1, [2])` est hachable ? Back:  Non : les collections built-in immutables ne sont pas hachables que si leurs éléments sont hachables.  <!--ID: 1730827063882--> ENDI

START
Basic
hash : est-ce qu'une instance d'une classe définie par l'utilisateur est hashable par défaut ?
Back:
Oui 
(et il est calculé à partir de son `id`)
```python
class A: pass
print(hash(A())) # 270927678
```
<!--ID: 1730827063884-->
END
