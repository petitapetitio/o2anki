MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/stdtypes.html#context-manager-types
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-05
***

***
TARGET DECK: Python
FILE TAGS: exceptions

- STARTI [Basic] Qu'est-ce qu'un context manager ? Back:  Un objet qui gère l'ouverture et la fermeture de ressources. Il fournit les méthodes `__enter__`, `__exit__` et est utilisé avec `with`. Ex : `with open('file.txt'): ...` <!--ID: 1730827063603--> ENDI
- STARTI [Basic] Quel valent les arguments de `__exit__(exc_type, exc_instance, exc_traceback)` lorsque le contexte termine sans exception ? Back:  `None` <!--ID: 1730827063605--> ENDI
- STARTI [Basic] quelle est la particularité des noms de classe de context manager ? Back:  Ils on souvent des noms en snake_case <!--ID: 1730827063608--> ENDI


START
Basic
Comment implémenter un context manager avec une simple fonction ?
Back: 
```python
@contextlib.contextmanager
def mon_context(param):
    print(f'Enter: mon_context({param})')
    try:
        yield
    except Exception as e: 
        print(f'Exit: mon_context({param}) : erreur')
	    raise # re-propager si nécessaire
    else:
        print(f'Exit: mon_context({param}) : all good')
```
<!--ID: 1730827063601-->
END

START
Basic
Comment créer un context manager `timer` qui mesure le temps d'exécution (et rend accessible cette valeur dans un attribut `duration`) ?
Back:
```python
class timer:
    def __enter__(self):
        self._start = time.time()
        return self
        
    def __exit__(self, *args):
        self.duration = time.time() - self._start


# Usage
with Timer() as t:
    time.sleep(1)
print(t.duration)  # ~1.0
```
<!--ID: 1732866734220-->
END