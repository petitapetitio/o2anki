MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/typing.html#typing.TypeVar
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-04
***

***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] Comment contraindre `T = TypeVar("T")` d'implémenter l'interface `MyInterface` ? Back:  `T = TypeVar("T", bound=MyInterface)` <!--ID: 1730827063813--> ENDI
- STARTI [Basic] Comment contraindre `T = TypeVar("T")` d'être parmi les types `int`, `float`, `str` ? Back:  `T = TypeVar("T", int, float, str)` <!--ID: 1730827063815--> ENDI
- STARTI [Basic] Quels sont les trois cas d'usages de `TypeVar` ? Back:  définir des classes génériques,  des fonctions génériques et des alias de type génériques. <!--ID: 1730827063818--> ENDI
- STARTI [Basic] Quelles sont les deux façons de créer un `TypeVar` ? Back:  <br>1) Manuelle. Ex : `T = TypeVar('T')`<br>2) Via la syntaxe dédiée à partir de `3.12` (approche recommandée) <!--ID: 1730827063820--> ENDI

START
Basic
Quels sont les 3 cas d'usage de `TypeVar` avec des fonctions génériques ?
Back: 
1. Préserver le type : `first(lst: List[T]) -> T`
2. Forcer deux éléments du même type : `swap(a: T, b: T) -> tuple[T, T]`
3. Borner un type sans perdre le type : 
```python
NumT = TypeVar('NumT', bound=Number)
def square(x: NumT) -> NumT: ... # préserve int / float
```
<!--ID: 1730827063810-->
END


Concepts liés
- [[Covariance]]
- [[Contravariance]]

Exemples
```python
# Avant 3.12
K = TypeVar("K")
V = TypeVar("V")
class Dict(Generic[K, V]): ...

# Maintenant
class Dict[K, V]: ...
```