MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/pdb.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-17
***

- pour le lancer
	- utiliser la fonction native `breakpoint()`
	- `pdb.run(code)`
	- `pdb.pm`
- configuration 
	- `.pdbrc`
- comandes
	- `help` (`h`) ; `help CMD`
	- remarks
		- empty line repeat the previous command
		- commands are case sensitive 
		- pdb command take precedence over expressions
	- inspection
		- `args` (`a`) : les arguments de la fonction dans laquelle on est arrêté
		- `list (l)` : affiche le code autour du bp
			- `list`
			- `list` (x2)
			- `list .`
			- `list . 50`
			- `list 40 50`
		- `ll` : affiche toutes les lignes de la frame actuelle
		- `print EXPRESSION` (`p`) / `EXPRESSION` : affiche le résultat d'une expression
		- `!` : échapper un identifiant python (ex : `!h` où `h`est un nom et pas la commande aide)
		- `where` (`w`) : affiche la stack
	- navigation
		- `up` (`u`) / `down` (`d`) : move up / down one frame in the stack
		- `continue` (`cont`, `c`) : continue execution up to the next breakpoint
		- `jump line-number` (`j`)
		- `next` (`n`) : avance d'une ligne (sans entrer)
		- `step` (`s`) : avance d'un pas (et entre)
		- `quit`, `q` : interromps le programme (et quitte pdb)
	- gestion des breakpoints
		- `break` (`b`) : afficher la liste des breakpoints / ajouter un breakpoint
		- `tbreak LOCATION CONDITION` : place un bp éphémère (1 passage)
		- `clear` (`cl`) : remove a breakpoint / all breakpoints
		- `disable` : disable a breakpoint / all breakpoints
		- `ignore breakpoint-number n` : ignore les `n` prochaines passages sur le bp
	- gestion globale
		- alias
			- `alias` : liste les alias
			- `alias NAME : affiche la définition de l'alias `name`
			- `alias NAME CMD %1 %2` : crée un alias pour CMD avec deux paramètres

Alternatives : 
- [[ipdb]]
- [[pudb]]
