MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/stdtypes.html#modules
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-08
***

***
TARGET DECK: Python
FILE TAGS: imports

- STARTI [Basic] Quelle est la différence entre un module physique (`module.py`) et un objet module ? Back: L'objet module est l'instance en mémoire du module physique. <!--ID: 1731053652999--> ENDI
- STARTI [Basic] Est-ce qu'un objet module peut être renvoyé par une fonction ? Back:  Oui. Les modules sont des [[first-class objects]] <!--ID: 1731053653001--> ENDI
