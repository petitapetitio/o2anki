MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/logging.html?module-logging=
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***

***
TARGET DECK: Python
FILE TAGS: exceptions


- STARTI [Basic] Quels sont les niveaux de criticité par défaut du module logging ? Back:  `debug`, `info`, `warning`, `error`, `critical` <!--ID: 1730972172888--> ENDI
- STARTI [Basic] Comment convertir `logging.debug('foo is %r' % foo)` pour formatter le log de façon lazy, c'est à dire uniquement si le niveau de criticité affiche les messages de debug ? Back:  `logging.debug('foo is %r', foo)` <!--ID: 1730972172891--> ENDI
- STARTI [Basic] Quelle méthode est appelée pour le format specifier `%s` (dans l'ancien système de formatage des chaînes de caractères) ? Back:  `__str__` <!--ID: 1730972172893--> ENDI
- STARTI [Basic] Quelle méthode est appelée pour le format specifier `%r` (dans l'ancien système de formatage des chaînes de caractères) ? Back:  `__repr__` <!--ID: 1730972172896--> ENDI
- STARTI [Basic] Quel est le niveau de logs par défaut du module logging ? Back:  warning <!--ID: 1730972172898--> ENDI
- STARTI [Basic] Quelle est la règle d'or pour configurer le module logging ? Back: Appeler `logging.basicConfig()` avant le premier log. <!--ID: 1730972172903--> ENDI

START
Basic
Vers quelle sortie sont dirigés les logs par défaut ?
Back:
`sys.stderr` 
(le flux de l'erreur standard)

Démo avec le programme `main.py` : 
```python
import logging  
logging.basicConfig()  
logging.warning("hey")
```
`python main.py` affiche "WARNING:root:hey"
`python main.py 2>/dev/null` n'affiche rien.
<!--ID: 1730972172901-->
END


START
Basic
Exemple de configuration complète du module logging ?
Back: 
```python
logging.basicConfig(
    format='%(asctime)s %(levelname)8s %(message)s',
    filename='/tmp/logfile.txt', 
    filemode='w'
)
```
<!--ID: 1730972172886-->
END
