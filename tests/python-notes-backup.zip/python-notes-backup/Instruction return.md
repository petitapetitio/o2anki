MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[fonction]]
Date : 2024-10-24
***


***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] que se passe-t-il lorsqu'une instruction `return` est exécutée ? Back:  La fonction termine et renvoie la valeur donnée (ou `None`) <!--ID: 1729754352031--> ENDI
- STARTI [Basic] que renvoie une fonction qui termine en atteignant la fin de son corps ? Back:  `None` <!--ID: 1729754352032--> ENDI
- STARTI [Basic] que renvoie une fonction qui termine sur une instruction `return` (sans valeur) ? Back:  `None` <!--ID: 1729754352034--> ENDI
