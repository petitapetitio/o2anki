MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-05
***

***
TARGET DECK: Python

- STARTI [Basic] Le types numériques built-in sont-ils mutables ou immutables ? Back:  Immutables.  <!--ID: 1728239137889--> ENDI

START
Basic
Combien valent `n2`et `n3` ?
```python
n1 = sys.getrefcount(4)  
  
x = 4  
n2 = sys.getrefcount(4)  
  
x += 1  
n3 = sys.getrefcount(4)
```
Back:  
```
n2 == n1 + 1
n3 == n1
```
Les types numériques natifs sont immutables. L'incrémentation lie à `x` l'objet `5` et ne modifie pas l'objet `4`.
<!--ID: 1734678007483-->
END

- STARTI [Basic] Que produit `z.imag = 4` ? Back:  Une exception `AttributeError: readonly attribute` <!--ID: 1728239137894--> ENDI
- STARTI [Basic] `-2 ** 2` ? Back:  `-4` : `**` a une priorité plus élevée que l'opérateur unaire `-`. ([[gotcha]]) <!--ID: 1728239137898--> ENDI
 
Conversions
- STARTI [Basic] Que se passe-t-il quand on compare un `int` avec un `float` (ie `1 < 1.0`) ? Back:  l'entier est implicitement convertit en flottant avant d'être comparé <!--ID: 1728239137902--> ENDI
- STARTI [Basic] Que se passe-t-il quand on compare un `int` avec un `complexe` (ie `1 == 1j`) ? Back:  l'entier est implicitement convertit en complexe avant d'être comparé  <!--ID: 1728239137906--> ENDI
- STARTI [Basic] `int(9.8)` ? Back:  `9` ([[gotcha]]) <!--ID: 1728239137910--> ENDI
- STARTI [Basic] `int(-9.8)` ? Back:  `-9` ([[gotcha]]) <!--ID: 1731677487790--> ENDI
- STARTI [Basic] `int(1j)` ? Back:  `TypeError` : convertir un complexe en int est ambigüe. <br>Même si la partie imaginaire est nulle ! ![[Opérations numériques-1.png]]([[gotcha]]) <!--ID: 1728239137914--> ENDI
- STARTI [Basic] `float(1j)` =  ? Back: ` TypeError` : convertir un complexe en flottant est ambigüe. ([[gotcha]])<!--ID: 1728239137918--> ENDI
- STARTI [Basic] `complex(1)` = ? Back:  `(1+0j)` <!--ID: 1728239137922--> ENDI
- STARTI [Basic] `complex(1.5)` = ? Back:  `(1.5+0j)` <!--ID: 1728239137927--> ENDI
- STARTI [Basic] Comment convertir `"101"` en base `2` ? Back:  `int("101", 2)`. <!--ID: 1728239137931--> ENDI
- STARTI [Basic] `int(101, 2)` Back: `TypeError: int() can't convert non-string with explicit base`. La forme attendue est `int("101", 2)` ([[gotcha]]) <!--ID: 1731677487791--> ENDI
- STARTI [Basic] `int("101", 2)` ? Back:  `5` <!--ID: 1728239137935--> ENDI
- STARTI [Basic] `int("ff", 16)` ? Back:  `255` (`15 x 16^1 + 15 x 16^0`) <!--ID: 1731677487792--> ENDI
- STARTI [Basic] `int("FF", 16)` ? Back:  `255` (`15 x 16^1 + 15 x 16^0`)<!--ID: 1728239692365--> ENDI

Opérations arithmétiques
- STARTI [Basic] `4 / 0` ? Back:  `ZeroDivisionError` <!--ID: 1728239137944--> ENDI
- STARTI [Basic] `4 // 0` ? Back:  `ZeroDivisionError` <!--ID: 1728239137949--> ENDI
- STARTI [Basic] `4 % 0` ? Back:  `ZeroDivisionError` <!--ID: 1728239137953--> ENDI
- STARTI [Basic] `5.99 // 2` ? Back:  `2.0` (et pas `2` !) ([[gotcha]]) <!--ID: 1728239137957--> ENDI
- STARTI [Basic] `5.0 // 2` ? Back:  `2.0` (et pas `2` !) ([[gotcha]]) <!--ID: 1728239137961--> ENDI
- STARTI [Basic] `5.0 / 2` ? Back:  `2.5` <!--ID: 1728239137965--> ENDI
- STARTI [Basic] `5 / 2` ? Back:  `2.5` - la division de deux entier produit un résultat flottant si le reste n'est pas nul ([[gotcha]]) <!--ID: 1728239137970--> ENDI
- STARTI [Basic] Quelle est la formule de la division entière et du reste ? Back:  `(x // y) * y + (x % y) == x` <!--ID: 1728239137973--> ENDI
- STARTI [Basic] `-5 / 2` ? Back:  `-2.5` <!--ID: 1728239137978--> ENDI
- STARTI [Basic] `(-5) // 2` ? Back:  `-3` -- et pas `-2` ! On dit aussi que `//` performe une *floor division*. ([[gotcha]]) <!--ID: 1728239137982--> ENDI
- STARTI [Basic] `divmod(5, 2)` ? Back:  `(2, 1)` (quotient, reste) <!--ID: 1728239137985--> ENDI

Comparaisons
- STARTI [Basic] `(1j) > (2j)` ? Back:  `TypeError` les opérations de comparaison impliquant un ordre ne sont pas implémentés pour les complexes. <!--ID: 1728239137989--> ENDI
