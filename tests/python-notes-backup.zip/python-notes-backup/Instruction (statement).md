MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/fr/3.13/glossary.html#term-statement
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***


- [[instruction simple (simple statement)]]
- [[instruction composée (compound statements)]]
- quelle est la différence entre une instruction et une [[expression|expression]] ? 