MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

Une expression est une instruction lorsqu'elle constitue l'intégralité d'une [[ligne logique]].

On croise ce cas de figure : 
- en mode interactif (par exemple `>>> 1 + 2`)
- pour appeler des fonctions qui ont des effets de bord (par exemple `print("hello")`)

Liens 
- [[expression]]
- [[instruction simple (simple statement)]]