MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/reference/datamodel.html#object.__init_subclass__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-01
***

***
TARGET DECK: Python
FILE TAGS: 

- STARTI [Basic] à quoi `__init_subclass__` peut être une alternative ? Back:  A l'écriture d'une [[métaclasse]] personnalisée (dans certains cas simples). <!--ID: 1730827063941--> ENDI

START
Basic
quand est appelé `C.__init_subclass__` ?
```python
print("A ...")
class A:
    print("A body ...")
    def __init_subclass__(cls):
        print("__init_subclass__")
    print("A body.")

print("B ...")

class B(A):
    print("B body ...")
    x = 0
    print("B body.")

print("B() ...")
B()
print("B().")
```
Back:
À la fin de l’exécution du corps de chaque sous-classe de `C` (ici après `print("B.")`)

Le code affiche 
```
A ...
A body ...
A body.
B ...
B body ...
B body.
__init_subclass__
B() ...
B().
```
<!--ID: 1730827063937-->
END

Exemple d'utilisation pour créer un dataclass avec uniquement des attributs protégés : 
```python
from dataclasses import dataclass

class Private:
    def __init_subclass__(cls):
        for name in cls.__dict__['__annotations__']:
            if not name.startswith('_'):
                raise AttributeError(f'Champs {name} non privé')

@dataclass
class A(Private):
    _x: int
    y: int
    print("End of A body")

A(0, 0)  # AttributeError: Champs y non privé
```


