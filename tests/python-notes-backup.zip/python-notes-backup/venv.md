MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/venv.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-15
***


Commandes utiles
```sh
# Créer
python -m venv /path/to/new/virtual/environment 

# Activer
source /path/to/new/virtual/environment/bin/activate
. venv/Scripts/activate  # (sur Windows)
```


***
TARGET DECK: Python
FILE TAGS: venvs

- STARTI [Basic] dans quelle version et en quelle année est apparu le module `venv` ? Back: [[Python 3.3]] (2012) <!--ID: 1731677487732--> ENDI
- STARTI [Basic] comment créer un environnement virtuel (avec la stdlib) ? Back:  `python -m venv ENV` <!--ID: 1731677487733--> ENDI
- STARTI [Basic] comment afficher les options de `venv` ? Back: `python -m venv -h` ![[venv-1.png]]<!--ID: 1731677487734--> ENDI
- STARTI [Basic] comment activer un environnement virtuel sur Unix ? Back: `source ENV/bin/activate` <!--ID: 1731677487735--> ENDI
- STARTI [Basic] comment activer un environnement virtuel sur Windows ? Back: `. ENV/bin/activate` <!--ID: 1734337009028--> ENDI
- STARTI [Basic] que fait principalement l'activation d'un environnement virtuel ? Back:  <br>- ajoute le dossier `bin` au debut de la variable `PATH` du shell<br>- défini une commande `deactivate` qui permet de sortir de l'environnement virtuel<br>- modifie le prompt du shell afin d'afficher le nom de l'environnement<br>- crée la variable d'environnement `$VIRTUAL_ENV` avec le chemin vers la racine de l'environnement virtuel <!--ID: 1731677487736--> ENDI
- STARTI [Basic] comment afficher le chemin vers l'environnement virtuel actif ? Back:  `echo $VIRTUAL_ENV` <!--ID: 1731677487737--> ENDI
- STARTI [Basic] comment sortir d'un environnement virtuel ? Back:  exécuter la commande `deactivate` <!--ID: 1731677487738--> ENDI
- STARTI [Basic] comment supprimer un environnement virtuel ? Back:  `rm -rf ENV` <!--ID: 1731677487739--> ENDI
- STARTI [Basic] venv : sur Unix, comment est-ce que l'interpréteur python est intégré à l'environnement virtuel par défaut ? Back: par un lien symbolique (et non par copie). <!--ID: 1731677487740--> ENDI

