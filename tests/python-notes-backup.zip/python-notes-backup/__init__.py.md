MOC : [[Python|Python]]
Source :
Projets :
Tags : 
Date : 2023-10-20
***

- est utilisé pour indiquer qu'un dossier est un package
- est exécuté lorsque le package est importé

```
import os  
import sys  
sys.path.insert(0, os.getcwd())
```
