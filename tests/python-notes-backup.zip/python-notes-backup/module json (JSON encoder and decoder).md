MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : https://docs.python.org/3/library/json.html
Tags : [[Python]], [[JSON]], [[serialization]]
Date : 2025-01-11
***

- sérialisation de types natifs (tuple, list, dict, int, str)
- possibilité de sérialiser ses propres types avec `JSONEncoder` et `JSONDecoder` 🌟

```python
import json

data = {
    "a": [0, 1, 2],
    "b": True,
}

print(json.dumps(data))  # {"a": [0, 1, 2], "b": true}

with open("test.json", "w") as file:
    json.dump(data, file)

```
