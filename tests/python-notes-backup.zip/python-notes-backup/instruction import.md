MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-07
***


***
TARGET DECK: Python
FILE TAGS: programs imports

- STARTI [Basic] Que signifie importer en Python ? Back: Rendre accessible un module et son contenu dans le code actuel. Ex : `import math` permet d'utiliser les fonctions de `math` <!--ID: 1730972172802--> ENDI
- STARTI [Basic] comment importer un fichier python `hello.py` comme module ? Back:  `import hello` <!--ID: 1730972172805--> ENDI
- STARTI [Basic] comment se déroule une instruction `import hello` ? Back:  L'instruction résout l'import puis lie l'objet module à l'identifiant `hello`. <!--ID: 1730972172807--> ENDI
- STARTI [Basic] comment lier un module `datetime` au nom `dt` plutôt qu'au nom `datetime` ? Back:  `import datetime as dt` <!--ID: 1730972172810--> ENDI

