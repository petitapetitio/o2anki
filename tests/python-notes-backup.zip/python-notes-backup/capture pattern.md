MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/reference/compound_stmts.html#grammar-token-python-grammar-capture_pattern
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***


***
TARGET DECK: Python
FILE TAGS: match

- STARTI [Basic] Comment appele-t-on un [[nom qualifié|nom non-qualifié]] comme `x` dans un pattern ? Back: Un motif de capture. <!--ID: 1728727115362--> ENDI
- STARTI [Basic] Que fait un [[nom qualifié|nom non-qualifié]] dans un pattern ? Back:  il match n’importe quelle valeur et la capture (l'objet matché est lié au nom dans l'espace de noms local). <!--ID: 1728727115363--> ENDI


START
Basic
`is_fifty_five(10)` ?
```python
def is_fifty_five(p):  
	match 55:  
		case p: 
		    return True
	return False
```
Back:  
`True`

Car `p` est un [[nom qualifié|nom non-qualifié]] et agit comme un capture pattern.

Une première solution est d'envelopper le paramètre `p` dans une classe : 
```python
class ValueWrapper:  
	def __init__(self, value):  
		self.value = value  
  
def is_fifty_five(p):  
	x = ValueWrapper(p)  
	match 55:  
		case x.value: 
		    return True
	return False
```
Alors on obtient bien `not is_fifty_five(10)`

Une autre solution est d'utiliser une garde que `p` fasse référence au paramètre (et ne soit pas interprété comme un pattern de capture)
```python
def is_fifty_five(p):  
	match p:  
		case _ if p == 55: return True  
		case _: return False
```
<!--ID: 1728729591978-->
END
