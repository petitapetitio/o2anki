MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: 


- `ascii('banana 😀')` vs `'banana 😀'.encode('ascii')` ? `'banana 😀'.encode('ascii')` lève une exception, tandis que `ascii('banana 😀')` échappe les caractères non ASCII using `\x`, `\u`, or `\U` escapes.