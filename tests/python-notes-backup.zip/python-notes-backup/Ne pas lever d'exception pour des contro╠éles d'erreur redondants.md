MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Exception]]
Date : 2024-11-05
***

Use the raise statement only to raise additional exceptions for cases that would normally be OK but that your specification defines to be errors.
```python
def head(elts: list):
    if len(lst) < 1:         # Don't : it's just code polution
        raise IndexError     # This raise is redundant with Python behavior
	return elts[-1]
```
