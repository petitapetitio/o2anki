MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2025-01-17
***

- quel est le but de l'optimisation ? assurer des performances acceptables
- quelles sont les étapes de l'optimisation
	1. [[benchmarking]] : mesurer les performances afin de voir s'il y a un problème (maybe not)
	2. [[profiling]] : instrumenter le programme afin d'identifier les [[contrainte (bottleneck)]]
	3. optimiser : supprimer le bottleneck (d'abord en python, puis via des extension modules)

Principes
- [[Attends d'avoir une solution fonctionnelle et stable avant d'optimiser — First make it work. Then make it right. The make it fast (the golden rule of programming)]]
- [[Identifie le bottlneck avant d'optimiser (Premature optimization)]]
- Focus on large scale optimizations (big-O)
	- [[big-O]], [[20-80]]
	- [[big-O times for operations on Python built-in types]]
- [[Small scale optimization (fine-tuning)]]

Usual suspects
- IO ([[IO-bound]])
	- network traffic
	- database access
	- interactions with the os
- calculs ([[CPU-bound]])
	- app architecture
- mémoire

