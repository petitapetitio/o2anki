MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***

- chaque objet a un type
- le type d'un objet détermine les opérations que tu peux appliquer à l'objet, ses attributs, son caractère mutable ou immutable
- la fonction type(obj) renvoie un type object qui est le type de l'objet
	- `type(1)` renvoie `<class 'int'>`
	- `type(type(1))` renvoie `<class 'type'>`
- `isinstance(obj, type)` est vrai si obj est de type "type" ou une sous-classe de "type"



***
TARGET DECK: Python

- STARTI [Basic] quel objet n'a pas de type ? Back: Aucun, tous les objets ont un type. Même `None` est de type `NoneType`. <!--ID: 1727939491356--> ENDI
- STARTI [Basic] comment déterminer le type de l'objet `obj` ? Back: avec la [[fonction native type]] : `type(obj)`<!--ID: 1727939491361--> ENDI
- STARTI [Basic] que détermine le type d'un objet ? Back: <br>- ses [[attribut]]s <br>- les opérations que tu peux lui appliquer <br>- son caractère mutable ou immutable <!--ID: 1727939491365--> ENDI
- STARTI [Basic] `type(1)` ? Back: `<class 'int'>` <!--ID: 1727939491369--> ENDI`
- STARTI [Basic] `type(type(x))` ? Back: `<class 'type'>` <!--ID: 1727939491373--> ENDI`
- STARTI [Basic] `isinstance(1, int | float)` Back: `True` : `1` est bien de type entier ou flottant. <!--ID: 1727939491377--> ENDI
- STARTI [Basic] Comment vérifier que `x` est de type entier ou flottant ? Back: `isinstance(x, int | float)` <!--ID: 1730827064126--> ENDI

START
Basic
```python
class Father:
	pass

class Child(Father):
	pass
```
`isinstance(Child(), Father)` ?
Back:  `True`
<!--ID: 1731053653027-->
END
