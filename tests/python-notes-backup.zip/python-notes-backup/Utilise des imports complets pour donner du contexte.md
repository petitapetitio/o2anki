MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[3 RESSOURCES/The developer's brain/Notes/Software Design|Software Design]], [[3 RESSOURCES/The developer's brain/Notes/Clean Code/Clean Code|Clean Code]]
Date : 2025-01-12
***

```python
# Recommandé
import math
math.sqrt(5)

# À éviter
from math import sqrt
sqrt(5)
```
