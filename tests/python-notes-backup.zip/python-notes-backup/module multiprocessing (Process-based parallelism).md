MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- Permet d'exécuter un programme dans différents [[process]] 
- Fournit les mêmes objets que le [[module threading (Thread-based parallelism)]] - ce qui facilite le portage depuis des programme multithreadés
- `ProcessPoolExecutor` est l'équivalent de [[ThreadPoolExecutor]]

Ressources : 
- https://docs.python.org/3/library/multiprocessing.html
- https://pymotw.com/3/multiprocessing/index.html
- chapitre 15 de [[Python in a Nutshell]]
