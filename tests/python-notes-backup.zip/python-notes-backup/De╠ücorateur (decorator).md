MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/fr/3.13/glossary.html#term-decorator
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-01
***

***
TARGET DECK: Python
FILE TAGS: 

- STARTI [Basic] qu'est-ce qu'un décorateur de fonction ? Back: Une fonction qui prends une fonction en entrée et renvoie une fonction. Les décorateurs sont des [[higher-order function]]. <!--ID: 1730827063976--> ENDI
- STARTI [Basic] qu'est-ce qu'un décorateur de classe ? Back: Une fonction qui prends une classe en entrée et renvoie une classe. <!--ID: 1734019137950--> ENDI
- STARTI [Basic] À quelles instructions s'applique un décorateur ? Back: [[instruction def]], [[instruction class]] <!--ID: 1730827063982--> ENDI

START
Basic
à quoi *sert* le décorateur `functools.wraps` ?
Back:
Préserver les métadonnées de la fonction décorée (nom, docstring, etc.) qui seraient autrement remplacées par celles du wrapper.

Exemple :
```python
from functools import wraps
import time

def log_time(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        print(f"Temps d'exécution : {time.time() - start}")
        return result
    return wrapper

@log_time
def hello(name):
    """Dit bonjour"""
    print(f"Bonjour {name}")


hello.__name__  # == 'hello' (et pas wrapper)
hello.__doc__   # == 'Dit bonjour (et pas None)
```
 ([doc](https://docs.python.org/3/library/functools.html#functools.wraps))
<!--ID: 1730827063984-->
END
