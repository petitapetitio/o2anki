MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***

***
TARGET DECK: Python
FILE TAGS: operateurs

- STARTI [Basic] À quoi sert l'opérateur `in` ? Back:  À effectuer un test de présence. `x in [0, 1]` renvoie `True` si `x` vaut `0` ou `1`. <!--ID: 1729447957669--> ENDI
- STARTI [Basic] Est-il possible de réaliser un test de présence sur un object qui n'est pas un `Container` et qui ne fournit pas la méthode spéciale `__contains__` ? Back:  Oui. Si l'objet fournit la méthode `__getitem__()`, Python peut l'utiliser pour itérer sur l'objet et réaliser le test de présence. <!--ID: 1729447957672--> ENDI
- STARTI [Basic] `1 in {'a': 1}` ? Back:  `False`. Le test de présence est effectué sur les clés du [[dict]]. ([[gotcha]]) <!--ID: 1728627767364--> ENDI
- STARTI [Basic] `'a' in {'a': 1}` ? Back:  `True`. Le test de présence est effectué sur les clés du dictionnaire. <!--ID: 1728627767368--> ENDI
- STARTI [Basic] Comment tester si `"jaune"` est présent dans la chaîne de caractère `s` ? Back:  `"jaune" in s` <!--ID: 1728627767372--> ENDI
- STARTI [Basic] `"jaune" in "le soleil est jaune"` ? Back:  Oui <!--ID: 1728627767376--> ENDI
- STARTI [Basic] `[1, 2] in [3, 4, 1, 2, 4]` ? Back:  Non. <br>Par contre `[1, 2] in [3, 4, [1, 2], 4]`. <!--ID: 1728627767380--> ENDI

START
Basic
Comment Python évalue-t-il `x in elts` ?
Back:
1. Il appelle `elts.__contains__(x)` si la méthode existe
2. Sinon, si `elts.__getitem__` existe, il l'appelle avec 0, 1, 2, ... jusqu'à trouver `x` ou rencontrer une `IndexError`

Liens : [[méthode spéciale __contains__]], [[méthode spéciale __getitem__]]
<!--ID: 1730827064131-->
END

START
Basic
Comment tester la présence d'une sous-séquence `[1, 2]` dans une séquence `[3, 4, 1, 2, 4]` ?
Back: 
```python
def is_subsequence(sub, seq) -> bool:
    return any(
        sub == seq[i:i + len(sub)] 
        for i in range(len(seq) - len(sub) + 1)
    )
```
<!--ID: 1731677487781-->
END
