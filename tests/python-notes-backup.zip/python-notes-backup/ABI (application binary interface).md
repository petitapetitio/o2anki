MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-16
***

- is the machine-level interface Python offers to extensions 
- ex : [[CPython]] 3.8
