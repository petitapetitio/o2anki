MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

- un token est un composant lexical élémentaire
- une [[ligne logique]] est une séquence de tokens
- types de tokens : 
	- [[identifiant (nom)]]
	- [[keyword]]
	- [[opérateur]]
	- [[délimiteur]]
	- [[littéral]]


***
TARGET DECK: Python
FILE TAGS: lexical-structure


- STARTI [Basic] Quels sont les 5 types de tokens qui peuvent composer une ligne logique ? Back: [[identifiant (nom)]], [[keyword]], [[opérateur]], [[délimiteur]], [[littéral]] <!--ID: 1727542890085--> ENDI
