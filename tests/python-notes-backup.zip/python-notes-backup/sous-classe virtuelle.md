MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/abc.html#abc.ABCMeta.register
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-06
***


***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] qu'est-ce qu'une sous-classe virtuelle ? Back: Une classe `A` qui passe le test `issubclass(A, B)` sans hériter explicitement de `B`. <!--ID: 1733561161854--> ENDI
- STARTI [Basic] Comment faire de `A` une sous-classe virtuelle de `B` ? Back: <br>a) L'enregistrer via `B.register(A)` <br>b) Faire de `B` une `ABC` et implémenter la [[méthode spéciale __subclasshook__]] sur `B`<!--ID: 1733561161862--> ENDI

