MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-08
***

***
TARGET DECK: Python
FILE TAGS: imports

- STARTI [Basic] Pourquoi éviter les imports circulaires ? Back: Ils peuvent casser selon l'ordre d'import ce qui rend le code fragile et source d'erreurs. <!--ID: 1731053653018--> ENDI
- STARTI [Basic] Est-ce que python supporte les imports circulaires ? Back:  Oui - mais le problème des [[dépendance circulaire (circular dependency)]] reste entier. <!--ID: 1731053653019--> ENDI

