MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-07
***

***
TARGET DECK: Python
FILE TAGS: programs

- STARTI [Basic] Qu'est-ce qu'un module extension ? Back:  Un module python écrit dans un autre langage (C, C++, Java, C#, Rust, ..) <!--ID: 1730972172813--> ENDI
- STARTI [Basic] Quel est l'intérêt principal des extension modules ? Back: Améliorer les performances en implémentant des parties critiques dans des langages compilés <!--ID: 1730972172816--> ENDI
- STARTI [Basic] Y-a-t-il un différence entre importer un module codé en python et un module d'extension codé en C pour le code client ? Back:  Non <!--ID: 1730972172819--> ENDI
