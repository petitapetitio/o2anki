MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-13
***

- https://docs.python.org/3/library/fractions.html
- immutable

```python

# Créer une faction 
# Les 4 expressions suivantes créent Fraction(1, 10)
Fraction(1, 10)
Fraction(2, 20)
Fraction('1/10')
Fraction(Decimal('0.1'))

# Ne pas créer de fractions à partir de flottant ([[gotcha]])
Fraction(0.1) == Fraction(3602879701896397, 36028797018963968)
# ou alors appliquer une limite au dénominateur
Fraction(0.1).limit_denominator(10000000) == Fraction(1, 10)

# Opérations
Fraction(2, 7) * Fraction(11, 15) == Fraction(22, 105)
```
