MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-19
***

- for [[Templating]]
- Un "Jinja" est un "temple"  japonais (temple ~ template)
- https://pypi.org/project/Jinja2/
- https://jinja.palletsprojects.com/en/stable/
- integrates with [[Flask]], [[Django]]
- Objets
	- `jinja2.Environment`
		- en général un seul, nommé `env`
		- loader (ex : `loader=jinja2.FileSystemLoader('/path/to/templates')`)
		- `env.get_template(name)`
		- `env.loader(name)` (pour récupérer le template brute)
	- `jinja2.Template`
		- `t.render(...) -> str`

###### Exemple

```python
import jinja2
from jinja2 import FileSystemLoader

env = jinja2.Environment(
    loader=FileSystemLoader("templates"),
    trim_blocks=True,
    lstrip_blocks=True,
    autoescape=True,
)

print(env.list_templates())
t = env.get_template("table_template.html")
s = t.render(s_of_s=(
    ('foo', 'g>h', 'g&h'),
    ('zip', 'zap', 'zop'),
))

# <table>
#     <tr>
#         <td>foo</td>
#         <td>g&gt;h</td>
#         <td>g&amp;h</td>
#     </tr>
#     <tr>
#         <td>zip</td>
#         <td>zap</td>
#         <td>zop</td>
#     </tr>
# </table>
```

avec dans `templates/table_template.html` : 
```html
<table>
    {% for s in s_of_s %}
    <tr>
        {% for item in s %}
        <td>{{item}}</td>
        {% endfor %}
    </tr>
    {% endfor %}
</table>
```
