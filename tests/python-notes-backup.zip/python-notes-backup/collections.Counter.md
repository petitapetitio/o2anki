MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/collections.html#collections.Counter
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: counter

- STARTI [Basic] `dict(collections.Counter("ball"))` ? Back:  `{'b': 1, 'a': 1, 'l': 2}` <!--ID: 1734710569242--> ENDI
- STARTI [Basic] `isinstance(collections.Counter("ball"), dict)` ? Back:  `True` <!--ID: 1734710569244--> ENDI
- subtract
	- STARTI [Basic]  `c = collections.Counter("ball"); c.subtract('baby'); dict(c)` ? Back:   `{'b': -1, 'a': 0, 'l': 2, 'y': -1}` <!--ID: 1734710569246--> ENDI
- elements
	- STARTI [Basic]  `list(collections.Counter("ball").elements())` ? Back:  `['b', 'a', 'l', 'l']` <!--ID: 1734710569248--> ENDI
- most_common
	- STARTI [Basic]  `collections.Counter("abbccc").most_common()` ? Back:  `[('c', 3), ('b', 2), ('a', 1)]` <!--ID: 1734710569250--> ENDI
	- STARTI [Basic]  `collections.Counter("abbccc").most_common(2)` ? Back:  `[('c', 3), ('b', 2)]` <!--ID: 1734710569252--> ENDI

