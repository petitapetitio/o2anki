MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- un des principal problème avec les programmes multi-threadés
- quand : lorsque plusieurs threads tentent de modifie une même donnée

###### Exemple de race condition (exagéré pour bien voir)
```python
import logging
import time
from concurrent.futures import ThreadPoolExecutor


class FakeDatabase:
    def __init__(self):
        self.value = 0

    def update(self, name):
        logging.info("Thread %s: starting update", name)
        local_copy = self.value
        local_copy += 1
        time.sleep(0.1)
        self.value = local_copy
        logging.info("Thread %s: finishing update", name)


if __name__ == "__main__":
    logging.basicConfig(format="%(asctime)s: %(message)s", level=logging.INFO, datefmt="%H:%M:%S")

    database = FakeDatabase()
    logging.info("Testing update. Starting value is %d.", database.value)
    with ThreadPoolExecutor(max_workers=2) as executor:
        for index in range(2):
            executor.submit(database.update, index)
    logging.info("Testing update. Ending value is %d.", database.value)

# 11:32:53: Testing update. Starting value is 0.  
# 11:32:53: Thread 0: starting update  
# 11:32:53: Thread 1: starting update  
# 11:32:53: Thread 0: finishing update  
# 11:32:53: Thread 1: finishing update  
# 11:32:53: Testing update. Ending value is 1.
```

RQ : une race condition peut intervenir sur `x = x + 1`

Ce problème peut être résolu avec des [[threading.Lock]] ([[threading.Lock#preventing race conditions]])
