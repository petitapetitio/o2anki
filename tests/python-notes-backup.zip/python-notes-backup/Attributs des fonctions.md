MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]], https://docs.python.org/3/reference/datamodel.html#user-defined-functions
Tags : [[Python]], [[Function]]
Date : 2024-10-24
***

- [[Docstring]]


***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] fonctions : `f.__name__` ? Back:  `'f'` (le nom de la fonction) <!--ID: 1729754352038--> ENDI
- STARTI [Basic] fonctions : que renvoie `f.__defaults__` lorsque la signature de `f` est `f(a, b=1, c=2)` ? Back:  `(1, 2)` <!--ID: 1729754352039--> ENDI
- STARTI [Basic] fonctions : comment accéder aux annotations de `f` ? Back:  `f.__annotations__` <!--ID: 1729754352041--> ENDI
- STARTI [Basic] fonctions : est-il possible de lier des attributs de façon dynamique à une fonction ? Back:  Oui <!--ID: 1729754352043--> ENDI
- STARTI [Basic] fonctions : pourquoi est-il possible de lier des attributs de façon dynamique à une fonction ? Back:  Les fonctions sont des objets de première classe. Il est possible de leur attribuer des propriétés comme tu le ferais avec une instance de classe. <!--ID: 1729754352044--> ENDI
- STARTI [Basic] fonctions : Comment est-ce que python traite les annotations de fonction ? Back:  Il évalue les expressions d'annotation et à construit l'attribut `__annotations__` de la fonction (mais ne procède pas à des vérifications) <!--ID: 1729754352046--> ENDI
- STARTI [Basic] fonctions : Que vaut `f.__annotations__` pour `f(a: int) -> bool` ? Back:  `{'a': <class 'int'>, 'return': <class 'bool'>}` <!--ID: 1729754352048--> ENDI


START
Basic
Comment compter le nombre d'appels à une fonction en utilisant un attribut local ?
Back: 
```python
def f():  
	if not hasattr(f, "calls_counter"):  
		f.calls_counter = 0  
	f.calls_counter += 1
```
<!--ID: 1729754352036-->
END
