MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/tutorial/datastructures.html#list-comprehensions
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[list]]
Date : 2024-10-12
***

***
TARGET DECK: Python
FILE TAGS: list

- STARTI [Basic] Quelle est le diminutif de "liste en compréhension" ? Back:  listcomp <!--ID: 1728749077320--> ENDI
- STARTI [Basic] Quelle est la différence entre une boucle `for` et une liste par compréhension ? Back:  <br>`for` est une instruction (composée) <br>la liste en compréhension est une expression  <!--ID: 1728749077329--> ENDI
- STARTI [Basic] Quelle est la syntaxe complète d'une liste en compréhension non imbriquée ? Back:  `[expression for target in iterable if condition]` <!--ID: 1728749077335--> ENDI
- STARTI [Basic] Dans quels cas ne pas utiliser de listcomps ? Back:  1) si tu peux utiliser un générateur à la place, et 2) si tu ignore la liste produite et que tu ne te sers de cette forme que pour boucler sur une seule ligne (`[proc(x) for x in seq]`) <!--ID: 1728749077339--> ENDI
- STARTI [Basic] Que produit la liste en compréhension `[(x, y) for x in [1, 2, 3, 4] if x % 2 == 0 for y in ["a", "b", "c"] if y == "b"]` ? Back:  `[(2, 'b'), (4, 'b')]`. Les clauses sont ordonnées comme dans une boucle imbriquée. <!--ID: 1728749077347--> ENDI
- STARTI [Basic] Qu'affiche `[x for x in [1, 2]]; print(x)` ? Back:  `NameError: name 'x' is not defined`. Le nom cible de l'expression `for` est défini uniquement dans la portée de l'expression. <!--ID: 1728749077352--> ENDI

START
Basic
Comment réécrire le code suivant à l'aide d'une liste en compréhension ?
```python
result = []
for x in range(100):
	if x > 23:
	    result.append(x + 1)
```
Back:
```python
result = [x + 1 for x in range(100) if x > 23]
```
<!--ID: 1728749077316-->
END

