MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/numbers.html#the-numeric-tower
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-01
***

***
TARGET DECK: Python
FILE TAGS: abc numbers

START
Basic
Qu'est-ce que la tour des classes numériques ?
Back:
Une hiérarchie de classes des types numériques : 
`Integral` → `Rational` → `Real` → `Complex` → `Number`.
<!--ID: 1730827064007-->
END

START
Basic
Que permet la tour des classes numériques ?
Back:
Une hiérarchie dans la comparaison des types :
```python
# isinstance
isinstance(5, float) # False
isinstance(5, Real)  # True
```
<!--ID: 1734019137983-->
END

- STARTI [Basic] Dans quel module est définie la tour des nombres ? Back: `numbers` <!--ID: 1734019137988--> ENDI
- STARTI [Basic] Comment `Decimal` s'intègre-t-il dans la tour des nombres ? Back:  `Decimal` est une - [[sous-classe virtuelle]] de `Number` mais n'hérite d'aucune autre ABC de la tour. <!--ID: 1730827064019--> ENDI





