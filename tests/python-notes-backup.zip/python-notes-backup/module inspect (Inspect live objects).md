MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/inspect.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Debugging]]
Date : 2025-01-14
***

Principaux services
- `getmembers` (similaire à la [[fonction native dir]] mais renvoie le dictionnaire nom-valeur)
- `isbuiltin`, `isclass`, `ismethod`, `ismodule`, `isdatadescriptor`, `isabstract`, `isframe`
- [examiner le code source d'un objet](https://docs.python.org/3/library/inspect.html#retrieving-source-code)
	- `getdoc(obj)`
	- `getcomments(obj)`
	- `getmodule(obj)`
- [inspecter la signature d'un callable](https://docs.python.org/3/library/inspect.html#introspecting-callables-with-the-signature-object) ([[Callable]])
	- `signature(f)`
- [inspecter les classes et les fonctions](https://docs.python.org/3/library/inspect.html#classes-and-functions)
	- `getmro(c)`
	- `getclosurevars(func)`
- [inspecter la traceback](https://docs.python.org/3/library/traceback.html)

###### Afficher le nom de la fonction appelante à l'aide de stack()
```python
import inspect


def caller():
    callee()


def callee():
    caller_name = inspect.stack()[1].function
    # inspect.stack()[0] concerne cette fonction
    # inspect.stack()[2] concerne l'appelant de `caller`
    print(caller_name) # caller


caller()
```

###### Afficher des informations sur un objet
```python
def show_obj_methods(obj, name, show=sys.stderr.write):
    show(f'{name} is type {type(obj).__name__}({obj!r})\n')
    show(f"{name}'s methods are: \n")
    for n, v in inspect.getmembers(obj, callable):
        show(f'\t{n}\n')
    show('\n')

# b is type B(<__main__.B object at 0x105d10b30>)
# b's methods are: 
# 	__class__
# 	__delattr__
# 	__dir__
# 	__eq__
# 	...
# 	__sizeof__
# 	__str__
# 	__subclasshook__
# 	f
# 	g
# 	h
```
