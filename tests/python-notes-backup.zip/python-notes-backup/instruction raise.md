MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-05
***

- [[instruction simple (simple statement)]]

***
TARGET DECK: Python
FILE TAGS: exceptions

raise expr
- STARTI [Basic] Comment lever une exception de type `Exception` sans message ? Back:  `raise Exception` ou  `raise Exception()` <!--ID: 1730827063611--> ENDI
- STARTI [Basic] Comment lever une exception de type `Exception` avec le message "oups" ? Back:  `raise Exception('oups')` <!--ID: 1730827063614--> ENDI

raise expr from e
- STARTI [Basic] Comment chaîner explicitement deux exceptions ? Back:  `raise nouvelle_exception from exception_originale` <!--ID: 1730827063616--> ENDI
- STARTI [Basic] Comment masquer une exception sous-jacente ? Back:  `raise nouvelle_exception from None` <!--ID: 1730827063619--> ENDI
- STARTI [Basic] Quelle est la différence entre `raise Exception` et `raise Exception()` ? Back:  Le premier passe la classe, le second crée une instance. Python instanciera automatiquement dans le premier cas <!--ID: 1730827063622--> ENDI
- STARTI [Basic] Comment inspecter la cause d'une exception chaînée ? Back:  Via l'attribut `__cause__` pour un chaînage explicite (from) ou `__context__` pour un chaînage implicite <!--ID: 1730827063624--> ENDI
- STARTI [Basic] Quelle est la différence entre chaînage implicite et explicite ? Back:  <br>Implicite : une exception survient pendant le traitement d'une autre (ex : `int('abc')` dans le corps d'un `except`). <br>Explicite : le développeur indique qu'une exception est la cause d'une autre (ex : `raise ValueError('Invalid input') from e`) <!--ID: 1730827063626--> ENDI

plain raise
- STARTI [Basic] Dans quel contexte est-il possible d'utiliser `raise` sans aucune expression ? Back:  dans le contexte d'un exception handler <!--ID: 1730827063629--> ENDI
- STARTI [Basic] Que fait un *plain* `raise` ? Back: Re-propage l'exception en cours de traitement.  <!--ID: 1730827063631--> ENDI
- STARTI [Basic] Quand utiliser un 'plain' `raise` dans un handler ? Back:  Quand on ne peut pas gérer l'exception et qu'on souhaite laisser les handlers parents terminer le traitement. <!--ID: 1730827063634--> ENDI


