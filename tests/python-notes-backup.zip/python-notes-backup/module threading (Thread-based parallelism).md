MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[(multi)threading]]
Date : 2025-01-14
***

https://docs.python.org/3/library/threading.html
https://github.com/python/cpython/blob/main/Lib/threading.py
https://realpython.com/intro-to-python-threading/

- [[thread]]
- Multithreading (travailler avec plusieurs threads)
	- [[ThreadPoolExecutor]]
	- [[module queue (A synchronized queue class)]]
	- Problèmes courants
		- [[race condition]] → [[threading.Lock]]
		- [[deadlock]] → [[Context Manager]], [[threading.RLock]]
		- [[Producer-consumer problem]] → [[module queue (A synchronized queue class)]]
	- synchronization primitives
		- [[threading.Lock]]
		- [[threading.RLock]]
		- threading.Condition (wraps Lock ou RLock)
		- [[threading.Event]]
		- [[threading.Semaphore]]
		- threading.Barrier
- [[threading.Timer]]
