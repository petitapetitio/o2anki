MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/simple_stmts.html#assignment-statements
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-04
***


- [[dissociation de séquences et d'itérables (unpacking)]]


***
TARGET DECK: Python
FILE TAGS: assignment

- STARTI [Basic] Qu'est-ce qu'une assignation ? Back:  Une opération qui lie une cible à un objet (ou à un nouvel objet). Ex : `a = list()` lie la variable `a` à la liste nouvellement créé. <!--ID: 1728239137754--> ENDI
- STARTI [Basic] Une ré-assignation peut-elle modifier l'objet précédemment liée ? Back:  Non <!--ID: 1728239137762--> ENDI
- STARTI [Basic] Quelles sont les cibles possibles d'une assignation ? Back:  un [[identifiant (nom)]], une [[référence à un attribut]] ou une [[sélection (subscription)]] <!--ID: 1728239137767--> ENDI
- STARTI [Basic] Quelle est la forme d'une instruction d'assignation simple ? Back:  `target = expression` <!--ID: 1728239137772--> ENDI
- STARTI [Basic] Comment appelle-t-on la partie à gauche de `target = expression` ? Back:  Lefthand side (LHS) <!--ID: 1728239137776--> ENDI
- STARTI [Basic] Comment appelle-t-on la partie à droite de `target = expression` ? Back:  Righthand side (RHS)  <!--ID: 1728239137781--> ENDI
- STARTI [Basic] Est-ce que l'instruction `a = 42` peut être refusée ? Back:  Non. <br>L'assignation à une [[variable]] est toujours autorisée. <!--ID: 1728239137785--> ENDI
- STARTI [Basic] Est-ce que l'instruction `p.x = 0` peut être refusée ? Back:  Oui. <br>L'assignation à un attribut passe par la [[méthode spéciale __setattr__]] et peut être refusée par l'objet. <!--ID: 1728239137789--> ENDI
- STARTI [Basic] Est-ce que l'instruction `t[1] = 0` peut être refusée ? Back:  Oui. <br>L'assignation via [[sélection (subscription)]] passe par la [[méthode spéciale __setitem__]] et peut être refusée par l'objet conteneur. <!--ID: 1728239137794--> ENDI
- STARTI [Basic] Est-ce que l'instruction `t[1:5] = [0]` peut être refusée ? Back:  Oui. L'assignation via un slicing passe par la [[méthode spéciale __setitem__]] et peut être refusée par l'objet conteneur. <!--ID: 1728239137798--> ENDI
- STARTI [Basic] Comment se déroule l'exécution de `x = 1 + 2` ? Back:  L'expression `1 + 2` est évaluée puis une référence à cette valeur est liée à la variable `x`. <!--ID: 1728239137803--> ENDI
- STARTI [Basic] Comment se déroule l'exécution de `a = b = c = 1 + 2` ? Back: L'expression `1 + 2` est évaluée puis une référence à cette valeur est liée à `a`, à `b`, et à `c`. <!--ID: 1728239137806--> ENDI
- STARTI [Basic] Qu'est-ce qu'une assignation multiple ? Back:  `a = b = c = 0` <!--ID: 1728239137810--> ENDI
- STARTI [Basic] Qu'est-ce qu'une assignation parallèle ? Back:   `x, y = (4, 6)` <!--ID: 1728239137815--> ENDI
- STARTI [Basic] Qu'est-ce qu'une assignation augmentée ? Back:  La combinaison d'une opération binaire et d'une assignation. Par exemple `a += 1`. <!--ID: 1728239137819--> ENDI
- STARTI [Basic] Quelle est la forme d'une assignation augmentée ? Back:  `target <operator>= expression` <!--ID: 1728239137823--> ENDI
- STARTI [Basic] Comment Python résout-il `x += y` ? Back: Python cherche `x.__iadd__(y)`, `x.__add__(y)` en fallback, et sinon lève une `TypeError`. <!--ID: 1728239137827--> ENDI
- STARTI [Basic] Que signifie le "i" dans la méthode spéciale `__iadd__` ? Back:  in-place <!--ID: 1728239137832--> ENDI
