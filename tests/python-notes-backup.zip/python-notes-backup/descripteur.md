MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], [python doc](https://docs.python.org/3/howto/descriptor.html#descriptor-howto-guide) 🌟
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-26
***

Quelques cas d'usages : 
- calculer les valeurs au moment de l'accès ([exemple](https://docs.python.org/fr/3/howto/descriptor.html#dynamic-lookups))
- intercepter les accès en lecture et en écriture pour les logger ([exemple](https://docs.python.org/fr/3/howto/descriptor.html#managed-attributes))

Les descripteurs font souvent appel à la [[méthode spéciale __set_name__]].

***
TARGET DECK: Python
FILE TAGS: descriptors

- STARTI [Basic] qu'est-ce qu'un descripteur ? Back:  un objet qui fournit une ou plusieurs des méthodes spéciales `__get__`, `__set__`, `__delete__`. <!--ID: 1730827064719--> ENDI
- STARTI [Basic] à quoi servent les descripteurs ? Back: Personnaliser l'accès aux attributs. C'est le mécanisme général dont héritent les propriétés <!--ID: 1730827064720--> ENDI
- STARTI [Basic] quelle sont les trois méthodes spéciales du protocole descriptor ? Back:  `__get__`, `__set__`, `__delete__`. <!--ID: 1730827064722--> ENDI
- STARTI [Basic] comment est appelé un descripteur qui fournit `__set__` ou `__delete__` ? Back:  Un *data descriptor* <!--ID: 1730827064724--> ENDI
- STARTI [Basic] qu'est-ce qu'un *data descriptor* ? Back:  un descripteur qui fournit `__set__` ou `__delete__` <!--ID: 1730827064726--> ENDI
- STARTI [Basic] comment est appelé un descripteur qui fournit uniquement `__get__` ? Back:  Un *non-data descriptor* <!--ID: 1730827064727--> ENDI
- STARTI [Basic] qu'est-ce qu'un *non-data descriptor* ? Back:  un descripteur uniquement la méthode `__get__` du protocol descriptor. <!--ID: 1730827064729--> ENDI
- STARTI [Basic] dans quel cas est-ce que la fonction `__get__` d'un descripteur est appelée ? Back: Lorsque l'instance du descripteur est un attribut de classe <u>et</u> que cet attribut est accédé via la notation par point (depuis l'instance ou depuis la classe elle-même) <!--ID: 1730827064730--> ENDI
- STARTI [Basic] Comment accéder au descripteur `c.x` sans déclencher `__get__` ? Back: Accéder En passant par le dictionnaire de la classe : <br>`vars(type(c))['x']`<br>`c.__class__.__dict__['x']` <br><br>(Les descripteurs ne sont invoqués que via l'opérateur "point")  <!--ID: 1730827064732--> ENDI
- STARTI [Basic] est-ce qu'un descripteur est invoqué lorsqu'il est défini comme attribut de classe ? Back: Oui <!--ID: 1730827064734--> ENDI
- STARTI [Basic] est-ce qu'un descripteur est invoqué lorsqu'il est défini comme variable d'instance ? Back:  Non, un descripteur n'est invoqué que lorsqu'il est défini comme **attribut de classe**. <!--ID: 1730827064736--> ENDI
- STARTI [Basic] quels éléments de python utilisent les descripteurs ? Back: <br>1. Les méthodes d'instance (pour la liaison) <br>2. Les méthodes de classes <br>3. Les méthodes statiques <br>4. Les propriétés <br><!--ID: 1730827064738--> ENDI


START
Basic
Qu'affiche `A().x` 
```python
class Ten:
    def __get__(self, obj, objtype=None):
        return 10


class A:
    x = Ten()
```
?
Back:
`10` : dans la recherche `a.x`, l'opérateur « point » trouve une instance de descripteur, reconnue par sa méthode `__get__`.
<!--ID: 1730827064714-->
END


START
Basic
Pourquoi est-ce que `__get__` prends `obj` et `objtype` plutôt que d'utiliser `type(obj)` ?
Back: 
Distinguer l'accès via une classe (`obj=None`, `objtype=classe`) de l'accès via instance (`obj=instance`, `objtype=classe`) 
<!--ID: 1730827064717-->
END
