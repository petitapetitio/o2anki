MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/fr/3/library/string.html#grammar-token-format-spec-format_spec
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[str (chaîne de caractères)]], [[f-string]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: strings

- syntaxe : `[[fill]align][sign][z][#][0][width][grouping_option][.precision][type]`
- alignement
	- https://docs.python.org/fr/3.13/library/string.html#grammar-token-format-spec-align
	- STARTI [Basic]  f-string : les caractères d'alignement ? Back:  `<`, `>`, `^`, = <!--ID: 1734713099700--> ENDI
	- STARTI [Basic]  `f'{'a':5}, f'{10:5}'` ? Back:  `'a    ', '   10'`<br>Les str sont alignées à gauche par défaut. Les entiers à droite. <!--ID: 1734713099701--> ENDI
	- STARTI [Basic]  f-string : aligner `x` sur `10` caractères à gauche ? Back:  `f'{x:<10}'` <!--ID: 1734713099702--> ENDI
	- STARTI [Basic]  f-string : aligner `x` sur `10` caractères à gauche avec des leading zeros ? Back:  `f'{x:0<10}'` <!--ID: 1734713099703--> ENDI
	- STARTI [Basic]  f-string : aligner `x` sur `10` caractères à droite ? Back:  `f'{x:>10}'` <!--ID: 1734713099704--> ENDI
	- STARTI [Basic]  f-string : aligner `x` sur `10` caractères au centre ? Back:  `f'{x:^10}'` <!--ID: 1734713099705--> ENDI
	- STARTI [Basic]  f-string : aligner entre `n` et son signe sur `10` caractères ? Back:  `f'{n:=10}'` <!--ID: 1734713099706--> ENDI
- signe
	- https://docs.python.org/fr/3.13/library/string.html#grammar-token-format-spec-sign
	- STARTI [Basic]  f-string : les caractères de signe ? Back:  `+`, `-`, `' '` <!--ID: 1734713099707--> ENDI
	- STARTI [Basic]  f-string : afficher `n` avec son signe (`+` ou `-`) ? Back:  `f'{n:+}'` (ex : `'+10'`, `'-10'`) <!--ID: 1734713099708--> ENDI
	- STARTI [Basic]  f-string : afficher `n` avec son signe (`+` ou `-`) sur 5 caractères ? Back:  `f'{n:+5}'` (ex : `'  +10')  <!--ID: 1734713099709--> ENDI
	- STARTI [Basic]  f-string : afficher `-` ou un espace pour `+` ? Back:  `f'{n: }'` <br>Ex : `f'{10: }' → ' 10'` <!--ID: 1734713099710--> ENDI
- zero normalisation (z)
	- STARTI [Basic]  `f'{-0.001:.1f}', f'{-0.001:z.1f}'` ? Back:  `('-0.0', '0.0')` <br>`z` normalise les zéros négatifs <!--ID: 1734713099711--> ENDI
- radix indicator (#)
	- STARTI [Basic]  `f'{21:x}', f'{21:#x}'` ? Back:  `('15', '0x15')` <!--ID: 1734713099712--> ENDI
	- STARTI [Basic]  `f'{5:b}', f'{5:#b}'` ? Back:  `('101', '0b101')` <!--ID: 1734713099713--> ENDI
	- STARTI [Basic]  f-string : `21` en hexadécimal avec le préfix ? Back:  `f'{21:#x}'` (donne `'0x15'`) <!--ID: 1734713099714--> ENDI
- leading zero (0)
	- STARTI [Basic]  `f"{1:3}", f"{1:03}"` ? Back:  `('  1', '001')` <!--ID: 1734713099715--> ENDI
	- STARTI [Basic]  f-string : faire précéder `n` de zéros sur 3 caractères ? Back:  `f'{n:03}'` <!--ID: 1734713099716--> ENDI
- field width
	- STARTI [Basic]  f-string : `n` sur `10` caractères ? Back:  `f'{n:10}'` <!--ID: 1734713099717--> ENDI
- grouping
	- STARTI [Basic]  f-string : `1000000 → '1_000_000'` ? Back:  `f'{1000000:_}'` <!--ID: 1734713099718--> ENDI
	- STARTI [Basic]  f-string : `1000000 → '1,000,000'` ? Back:  `f'{1000000:,}'` <!--ID: 1734713099719--> ENDI
- precision
	- STARTI [Basic]  `f'{12.34567:.3f}'` ? Back:  `'12.346'` (arrondit à 3 chiffres après la virgule) <!--ID: 1734713099720--> ENDI
	- STARTI [Basic]  `f'{12.34567:.3g}'` ? Back:  `'12.3'` (arrondit à 3 chiffres siGnificatifs) <!--ID: 1734713099721--> ENDI
	- STARTI [Basic]  `f'{"the story is long":.9}'` ? Back:  `'the story'` <!--ID: 1734713099722--> ENDI
	- STARTI [Basic]  f-string : au plus les 9 premiers caractères de `s` ? Back:  `f'{s:.9}'` <!--ID: 1734713099723--> ENDI
- type
	- https://docs.python.org/fr/3.13/library/string.html#grammar-token-format-spec-precision
	- entier
		- b
		- c
		- d
		- n
		- o
		- x
	- flottant
		- e
		- f
		- g
		- n
		- %
			- STARTI [Basic] 	- `f'{0.99:.0%}'` ? Back:  `'99%'` <!--ID: 1734713099724--> ENDI

