MOC : [[SOFTWARE ENGINEERING]]
Source : [stackoverflow](https://stackoverflow.com/questions/1517582/what-is-the-difference-between-statically-typed-and-dynamically-typed-languages)
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-25
***

Qu'est-ce qu'un langage typé de façon dynamique ? Un langage où le type des variables n'est connu qu'au moment de l'exécution du programme car le type est associé à la valeur d'exécution et non à un identifiant. [[Typage statique]]

Exemples : [[Python]], Perl, Ruby, PHP, JavaScript, Erlang

***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] Qu'est-ce qu'un langage typé de façon dynamique ? Back:  Un langage où le type des variables n'est connu qu'au moment de l'exécution du programme. <!--ID: 1730827063859--> ENDI
- STARTI [Basic] Quelle est la particularité du typage dynamique concernant l'association des types ? Back:  Le type est associé à l'objet et non à la variable (au nom). Ex : dans `x = 42`, le type `int` est lié à `42`, pas à `x`"<!--ID: 1730827063861--> ENDI
- STARTI [Basic]  Comment se manifeste le typage dynamique en Python ? Back:  Une variable peut être liée à des objets de type différents au cours de l'exécution : `x = 1; ...; x = 'texte'`. <!--ID: 1730827063863--> ENDI



START
Basic
Quels sont les avantages du typage dynamique ?
Back:
- Lisibilité : 
	- code plus concis
	- moins de "bruit" syntaxique
- Flexibilité : 
	- prototypage rapide (moins de code à écrire)
	- [[duck typing]] (pas besoin de créer des interfaces)
<!--ID: 1730827063855-->
END


START
Basic
Quels sont les inconvénients du typage dynamique ?
Back:
- Feedback : bugs de type découverts tardivement
- DX : 
	- auto-completion moins efficace
	- refactoring plus risqué
- Maintenabilité : code plus difficile à maintenir sur de grands projets
- Performance : vérification des types à l'exécution
<!--ID: 1730827063857-->
END
