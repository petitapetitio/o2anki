MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/datamodel.html#object.__init__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-28
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] classes : à quoi sert `__init__` ? Back:  Initialiser l'instance nouvellement créé en liant ses attributs. <!--ID: 1730827064148--> ENDI
- STARTI [Basic] Pourquoi est-il recommandé d'initialiser tous les attributs dans `__init__` ? Back: Rend le code + prévisible et + lisible. <!--ID: 1734019137963--> ENDI
- STARTI [Basic] classes : que renvoie `__init__` ? Back:  Rien. <br>Et une `TypeError` est levée si une valeur est renvoyée. <!--ID: 1730827064153--> ENDI
- STARTI [Basic] classes : Est-ce que python effectue un appel implicite au `__init__` de la superclasse ? Back:  Non. <br>Il revient à `C.__init__` de déléguer ou non une partie de l'initialisation à la superclasse. <!--ID: 1730827064159--> ENDI


START
Basic
Est-il possible de lier des attributs à l'instance en dehors du `__init__` ?
Back:
Oui

Ex : depuis une autre méthode
```python
class A:
    def __init__(self):
        self.x = 0
        
    def f(self):
        self.y = 0
```

Ex : depuis l'extérieur de la classe
```python
class A:
    def __init__(self):
        self.x = 0

a = A()
a.y = 0
```
<!--ID: 1730827064151-->
END