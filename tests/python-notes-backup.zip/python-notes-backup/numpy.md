MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-13
***

- https://docs.scipy.org/doc/
- Guide to NumPy: 2nd Edition (2015) (recommandé par Python in a Nutshell et la doc officielle)
- pour calcul scientifique, image processing, multidimensional arrays, algèbre linéaire, big data

- ndarray
	- rank = nombres de dimensions
		- 0 : scalaire
		- 1 : vecteur
		- 2 : matrice
	- shape 
		- scalaire : `np.array(1).shape == ()`
		- vecteur : `np.array([1, 1]).shape == (2,)`
		- matrice : `np.array([[1, 1], [1, 1]]).shape == (2, 2)`
- dtypes
	- le dtype par défaut est float64
	- lorsque le dtype est inféré, le plus large est pris (`np.array([1, 2]).dtype` → `int64`)


- factories
	- un `ndarray` depuis une séquence ? `np.array([1, 2])` (le `dtype` inféré est alors `int64`)
	- un `ndarray` de `int32` depuis une séquence ? `np.array([1, 2], np.dtype(np.int32))`
	- une matrice 10x10 de int8 remplie de zéro ? `np.zeros((10, 10), np.dtype(np.int8))`
	- une matrice 10x10 de int8 remplie de un ? `np.ones((10, 10), np.dtype(np.int8))`
	- le vecteur des entiers allant de 1 à 4 ? `np.arange(1, 5)`
	- un vecteur de 50 flottants entre 0 et 1 ? `np.linspace(0, 1, 50)`
	- une matrice 3x3 de valeurs aléatoires entre 0 et 1 ? `np.random.uniform(size=(3, 3))`
- reshape
	- does not work inplace
	- should match the size (si `a.size == 12`, `a.reshape(3, 4)`, `a.reshape(6, 2)` sont OK)

```python
# Matrix operations
a = np.arange(6).reshape(2, 3)
b = np.arange(3)

a + 1
a + b 
a * b
a @ b
```
