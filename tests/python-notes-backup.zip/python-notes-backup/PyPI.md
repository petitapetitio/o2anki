MOC : [[Python|Python]]
Source : 
Projets : [[$P - leequotes - j'ai publié mon premier paquet python]]
Tags : 
Date : 2024-06-22
***


Ressources : 
- https://pypi.org/
- https://packaging.python.org/en/latest/glossary/#term-Python-Package-Index-PyPI
- https://en.wikipedia.org/wiki/Python_Package_Index
- https://talkpython.fm/episodes/show/377/python-packaging-and-pypi-in-2022 with [[Dustin Ingram]]
- https://twit.tv/shows/floss-weekly/episodes/482


***
TARGET DECK: Python
FILE TAGS: packaging

- que signifie PyPI ? **Py**thon **P**ackage **I**ndex
- qu'est-ce que PyPI ? Le package index par défaut de la communauté Python. Il est ouvert à tous les développeurs pour consommer et distribuer leurs distributions
- en quelle année est-ce que PyPI a été lancé ? en 2003
- à quel problème répond [[PyPI]] ? 
- qui maintient [[PyPI]] ? [[Python Software Foundation (PSF)]]


