MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

- https://docs.python.org/3/library/functions.html#ord

***
TARGET DECK: Python
FILE TAGS: 

- STARTI [Basic] Le codepoint unicode de `'a'` ? Back:  `ord('a')`  <!--ID: 1734678007466--> ENDI
- STARTI [Basic] `ord('a')` ? Back: 97 <!--ID: 1734678007467--> ENDI
- STARTI [Basic] `ord('abc')` ? Back:  `TypeError: ord() expected a character, but string of length 3 found` <!--ID: 1734678007468--> ENDI

