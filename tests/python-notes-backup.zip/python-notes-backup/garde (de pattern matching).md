MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***


***
TARGET DECK: Python
FILE TAGS: match

- STARTI [Basic] pattern-matching : qu'est-ce qu'une garde ? Back:  une condition supplémentaire qui doit être vérifiée pour que la suite soit exécutée lorsqu'un pattern est matché. <!--ID: 1728729591880--> ENDI
- STARTI [Basic] pattern-matching : comment fonctionne une garde `if condition` ? Back: Elle est évaluée après un match du pattern. <br>- si `True` : la suite est exécutée<br>- si `False` : on passe au cas suivant. <!--ID: 1728729591884--> ENDI
- STARTI [Basic] pattern-matching: comment matcher uniquement les entiers pairs ? Back:  `case int(i) if i % 2 == 0:` <!--ID: 1728729591888--> ENDI
