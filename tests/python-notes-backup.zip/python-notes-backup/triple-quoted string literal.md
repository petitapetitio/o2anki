MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python|Python]], [[str (chaîne de caractères)]]
Date : 2024-09-28
***


Exemple
```python
"""Salut
c'est cool"""
```
