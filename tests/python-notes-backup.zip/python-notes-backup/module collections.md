MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/collections.html#
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: 

- ChainMap
- [[collections.Counter]]
- [[OrderedDict]]
- [[defaultdict]]
- [[deque]]
