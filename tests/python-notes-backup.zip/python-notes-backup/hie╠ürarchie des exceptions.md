MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/exceptions.html#exception-hierarchy
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***

***
TARGET DECK: Python
FILE TAGS: exceptions

- STARTI [Basic] Quelles sont les 3 [[exceptions built-in]] que la clause `except Exception` n'attrape pas ? Back:  `KeyboardInterrupt`, `GeneratorExit` et `SystemExit`. <!--ID: 1730972172921--> ENDI
- STARTI [Basic] Pourquoi ces est-ce que les exceptions `KeyboardInterrupt`, `GeneratorExit` et `SystemExit` n'héritent pas d'Exception ? Back:  Ce sont des cas spéciaux de contrôle de flux du programme, pas des erreurs. <!--ID: 1730972172924--> ENDI
- STARTI [Basic] Quelle clause permet d'attraper toutes les exceptions, y compris `KeyboardInterrupt`, `GeneratorExit` et `SystemExit` ? Back:  `except BaseException` <!--ID: 1730972172926--> ENDI