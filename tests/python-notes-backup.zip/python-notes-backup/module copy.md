MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-19
***

***
TARGET DECK: Python
FILE TAGS: 

https://docs.python.org/3/library/copy.html


- STARTI [Basic] quelles sont les deux fonctions du module copy ? Back:  `copy` et `deepcopy` <!--ID: 1734678007424--> ENDI
- STARTI [Basic] comment se traduit `copy.copy(x)` ? Back:  `x.__copy__()` <!--ID: 1734678007425--> ENDI
- STARTI [Basic] comment se traduit `copy.deepcopy(x)` ? Back:  `x.__deepcopy__()` <!--ID: 1734678007426--> ENDI


START
Basic
```python
sub = []  
original = [sub, sub]  
o = copy.copy(original)  
print(o[0] is o[1])
```
Back:
`True`
<!--ID: 1734678007423-->
END