MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[Testing]]
Date : 2025-01-14
***

- https://docs.nose2.io/en/latest/index.html
- 3rd party utility
- étend les fonctionnalités du [[module unittest]]
- "sniff out" test cases
- permet de créer des [[Test paramétré (Parametrised Test)]]
- la doc officielle encourage à utiliser [[pytest|pytest]] 
  ![[Python in a Nutshell-2.png]])
