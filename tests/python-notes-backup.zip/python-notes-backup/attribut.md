MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/glossary.html#term-attribute
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-26
***


***
TARGET DECK: Python
FILE TAGS: attributs

- STARTI [Basic] qu'est-ce qu'un attribut ? Back: Une variable attachée à un objet  <!--ID: 1730827064790--> ENDI
- STARTI [Basic] quelles sont les deux grandes catégories d'attributs ? Back:  Les [[attribut de classe]] et les attributs d'instance <!--ID: 1730827064792--> ENDI
- STARTI [Basic] comment accéder à l'attribut "x" de `obj` (2 façons) ? Back: <br>1. `obj.x` - via son nom en utilisant la notation "point" <br>2. `getattr(obj, "x")` - via la fonction native  <!--ID: 1730827064794--> ENDI
- STARTI [Basic] est-il possible d'ajouter un attribut nommé `"11"` à l'objet `x` ? Back:  Oui, `setattr(x, "11", 11)`. `setattr` permet de donner à un attribut un nom qui ne respecte pas les conventions des identifiants. <!--ID: 1730827064796--> ENDI
- STARTI [Basic] Comment accéder à l'attribut d'un objet de façon dynamique ? Back:  `getattr(obj, attribute_name)`  <!--ID: 1730827064798--> ENDI
