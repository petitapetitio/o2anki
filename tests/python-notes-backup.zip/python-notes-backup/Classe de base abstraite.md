MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3.13/library/abc.html#
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-01
***


- [[Ne pas étendre de classe concrète]]

***
TARGET DECK: Python
FILE TAGS: abc

- STARTI [Basic] Le module `abc` fait-il partie de la bibliothèque standard Python ? Back:  Oui <!--ID: 1730827063987--> ENDI
- STARTI [Basic] Qu'est-ce qu'une classe de base abstraite ? Back: Une classe qui ne peut pas être instanciée directement. Elle définit une interface et contient des méthodes abstraites que les classes filles doivent implémenter.<br><br>RQ : le mot base est redondant d'un point de vue conceptuel. Toutes les classes abstraites ont vocation à servir de base. <!--ID: 1730827063991--> ENDI
- STARTI [Basic] Quelle est la différence entre étendre de `abc.ABC` et utiliser la méta-classe `abc.ABCMeta` ? Back:  Aucune différence fonctionnelle. Hériter de `abc.ABC` est une façon pratique de déclarer `abc.ABCMeta` comme méta-classe. <!--ID: 1730827063993--> ENDI
