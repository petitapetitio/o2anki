MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[HTTP]]
Date : 2025-01-22
***

- https://fastapi.tiangolo.com/
- Dépendances
	- embrasse [[pydantic]] et les [[type annotations]]
	- construit sur [[Starlette]] (un framework [[ASGI]])
	- intègre [[Swagger UI]]
