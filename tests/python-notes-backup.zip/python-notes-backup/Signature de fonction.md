MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://developer.mozilla.org/fr/docs/Glossary/Signature/Function
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-07
***

START
Basic
Que décrit une signature de fonction ?
Back: 
Les caractéristiques de la fonction : 
- son nom
- sa visibilité (publique, privée, protégée)
- son caractère final, static
- ses entrées : le nom, le type, la valeur par défaut des paramètres
- sa sortie : type de retour 
<!--ID: 1730827064112-->
END

START
Basic
Qu'affiche
```python
def f(a: int, *, b: str = "hello") -> bool:
    ...

print(inspect.signature(f))
```
Back:
`(a: int, *, b: str = 'hello') -> bool`
<!--ID: 1733573726397-->
END