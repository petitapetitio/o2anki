MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/expressions.html#slicings
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-04
***

- a slicing is a slice applied to a container
- ex : `x[1:4]` est un slicing


***
TARGET DECK: Python
FILE TAGS: slicing

- STARTI [Basic] À quoi sert un tranchage (slicing) ? Back:  À référencer une sous-séquence d'une [[sequence]] à l'aide d'indices <!--ID: 1728627767460--> ENDI
- STARTI [Basic] À quoi fait référence `x[1:4]` ? Back:  À la sous-séquence qui contient les éléments `x[1]`, `x[2]` et `x[3]`. <!--ID: 1728239137731--> ENDI
- STARTI [Basic] À quel type d'objet s'applique le tranchage (slicing) ? Back:  Aux [[sequence]] et aux objets personnalisés qui implémentent la méthode spéciale `__getitem__` et supportent les slices. <!--ID: 1728627767464--> ENDI
- STARTI [Basic] Quel est le lien entre les tranchage (slicing) et [[sélection (subscription)]] ? Back:  Le tranchage est une forme de sélection qui permet de sélectionner plusieurs éléments à la fois. <!--ID: 1728627767468--> ENDI
- STARTI [Basic] Quel est le lien entre le tranchage et [[sélection (subscription)]] ? Back: Le tranchage est une forme particulière de sélection <!--ID: 1730972172883--> ENDI
- STARTI [Basic] `x = [0, 1, 2, 3]; x[1:3]` ? Back:  `[1, 2]` <!--ID: 1728627767472--> ENDI
- STARTI [Basic] `x = [0, 1, 2, 3]; x[:]` ? Back:  `[0, 1, 2, 3]` — une copie superficielle de la liste <!--ID: 1728627767476--> ENDI
- STARTI [Basic] `x = [0, 1, 2, 3]; x[:2]` ? Back:  `[0, 1]` — l'équivalent de `x[0:2]` <!--ID: 1728627767481--> ENDI
- STARTI [Basic] `x = [0, 1, 2, 3]; x[2:]` ? Back:  `[2, 3]` — l'équivalent de `x[2:len(x)]` <!--ID: 1728627767485--> ENDI
- STARTI [Basic] `x = [0, 1, 2, 3]; x[:100]` ? Back:  `[0, 1, 2, 3]` <!--ID: 1728627767488--> ENDI
- STARTI [Basic] `x = [0, 1, 2, 3]; x[3:0]` ? Back:  `[]` ([[gotcha]]) <!--ID: 1728627767492--> ENDI
- STARTI [Basic] Comment obtenir la queue renversée `[3, 2, 1]` de `x = [0, 1, 2, 3]` ? Back:  `x[3:0:-1]` <!--ID: 1728627767497--> ENDI
- STARTI [Basic] Comment renverser une liste `l` à l'aide du tranchage ? Back:  `l[::-1]`  (the Martian smiley) ([[tricks]]) <!--ID: 1728627767501--> ENDI
- STARTI [Basic] Comment sélectionner les éléments d'indice pair d'une liste `l` par tranchage ? Back:  `l[::2]` ([[tricks]]) <!--ID: 1728627767506--> ENDI
