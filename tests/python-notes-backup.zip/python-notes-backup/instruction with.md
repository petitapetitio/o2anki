MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***

- Est une [[instruction composée (compound statements)]]
- Permet de manipuler des [[Context Manager]]

***
TARGET DECK: Python
FILE TAGS: exceptions

instruction with
- STARTI [Basic] Quelle valeur est affectée à `f` dans `with manager as f` ? Back:  La valeur renvoyée par `manager.__enter__()` <!--ID: 1730827064179--> ENDI
- STARTI [Basic] Quel est l'effet du retour de `__exit__` sur la propagation des exceptions ? Back:  Si `__exit__` renvoie `True` l'exception est supprimée, sinon l'exception est propagée. <!--ID: 1730827064182--> ENDI
- STARTI [Basic] Comment ouvrir deux fichiers `1.txt` et `2.txt` dans une même instruction with ? Back:  `with open("1.txt") as f1, open("2.txt") as f2: ...` <!--ID: 1730827064185--> ENDI
- STARTI [Basic] à quel idiom C++ est-ce que l'instruction `with` est liée ? Back:  [[Resource acquisition is initialization (RAII)]] <!--ID: 1730827064188--> ENDI


START
Basic
Quel est l'équivalent en [[instruction try]] de 
```python
with context_manager() as f:
    do_something(f)
```
?
Back:
```python
cm = context_manager()  # acquisition du manager
f = cm.__enter__()      # acquisition de la ressource
try:
    do_something(f)
except Exception:       # cas avec exception
    if not cm.__exit__(*sys.exc_info()):
        raise
else:                       # cas sans exception
    cm.__exit__(None, None, None)
```
<!--ID: 1730827064176-->
END
