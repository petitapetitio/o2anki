MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***

***
TARGET DECK: Python
FILE TAGS: match

- STARTI [Basic] pattern-matching : à quoi sert le wildcard pattern `_` ? Back: matcher n'importe quelle valeur sans la capturer. <br>Il est souvent utilisé pour créer le cas par défaut (`case _:`).  <br><!--ID: 1728727115367--> ENDI
- STARTI [Basic] pattern-matching : comment matcher n'importe quel valeur de sujet ? Back:  `case _:` <!--ID: 1728727115369--> ENDI
