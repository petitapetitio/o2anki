MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/datamodel.html#type.__name__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: classes

- STARTI [Basic] class : comment accéder au nom de `C` ? Back:  `C.__name__` <!--ID: 1730827064277--> ENDI
