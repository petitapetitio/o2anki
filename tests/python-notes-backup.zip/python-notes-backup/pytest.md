MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

- https://docs.pytest.org/en/stable/reference/reference.html#
- search for `test_*.py` of `*_test.py` files, `test_*` methods and `Test*` classes
- utilise `assert` avec la convention `observed == expected`
-  api
	- approx
	- fail
	- raises (ex : `with pytest.raises(ZeroDivisionError):`)
	- skip("because")
	- warns
	- mark
		- `parametrize` (ex : `@pytest.mark.parametrize("x,y", [(1, 0), (0, 1)]))`)
		- `skipif(condition, reason)`

###### Commandes utiles
```
pytest -v 
pytest <test-folder>
pytest -k <test-name>
```

###### Exemple de fichier `pytest.ini`
```
[pytest]  
testpaths = tests
```

Pytest et [[Python Path]] : https://docs.pytest.org/en/stable/explanation/pythonpath.html#pythonpath