MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/tarfile.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***


- le nom du module lié aux fichiers TAR ? `tarfile`
- comment ouvrir `'archive.tag.gz'` en Python ? `tarfile.open('archive.tag.gz')`
