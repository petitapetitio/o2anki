MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[argument]]
Date : 2024-10-24
***

***
TARGET DECK: Python
FILE TAGS: fonctions

un argument qui est associé de façon explicite à un paramètre dans l'appel de fonction, en utilisant le nom du paramètre.

- STARTI [Basic] qu'est-ce qu'un argument nommé ? Back: un argument associé à un paramètre par son nom (ex : `print(text="hello")`).  <!--ID: 1729754352017--> ENDI
- STARTI [Basic] quelle est la forme d'un argument nommé ? Back:  `nom_du_parametre=expression` <!--ID: 1729754352019--> ENDI
- STARTI [Basic] De quel type est l'argument `1` dans `f(0, y=1)` ? Back:  Nommé (aka keyword) <!--ID: 1729754352021--> ENDI
- STARTI [Basic] quelles sont les deux façons de donner un argument nommé ? Back:  <br> 1) `f(parametre=valeur)` : `f(x=0, y=1)`<br> 2) `f(**mapping)` : `f(**{'x': 0, 'y': 1})`  <!--ID: 1729754352022--> ENDI

