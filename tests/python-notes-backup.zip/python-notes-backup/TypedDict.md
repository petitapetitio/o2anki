MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/library/typing.html#typing.TypedDict
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-03
***

***
TARGET DECK: Python
FILE TAGS: typing collections

- STARTI [Basic] quel est le cas d'usage principal des `TypedDict` ? Back:  Clarifier un code legacy qui utilise des dictionnaire plutôt que des classes <!--ID: 1730827063837--> ENDI
- STARTI [Basic] Quelle est la différence d'annotation entre `TypedDict` et `dict` ? Back: `TypedDict` permet de typer chaque valeur et impose des clés de type `str`. `dict` force les clés et les valeurs à être d'un type homogène (ex : `dict[tuple, int]`). <!--ID: 1730827063839--> ENDI

START
Basic
Comment représenter un dictionnaire qui a une clé `x: int`, une clé `y: int`, et une clé <u>facultative</u> `label: str` ?
Back:
```python
class Point2D(TypedDict):
    x: int
    y: int
    label: NotRequired[str]

# Alternative syntax (dépréciée)
Point2D = TypedDict('Point2D', {'x': int, 'y': int, 'label': NotRequired[str]})
```
<!--ID: 1730827063832-->
END


START
Basic
`type(Point2D())` ?
```python
class Point2D(TypedDict):
    x: int
    y: int
```
Back:
`<class 'dict'>`. Les classes créés avec `TypedDict` renvoient des dictionnaires.
<!--ID: 1730827063835-->
END
