MOC : [[SOFTWARE ENGINEERING]]
Source : https://hatch.pypa.io/
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-15
***

***
TARGET DECK: Python
FILE TAGS: packaging

- qui maintient Hatch ? [[Python Packaging Authority (PyPA)]]

![[hatch-1.png|200]]
