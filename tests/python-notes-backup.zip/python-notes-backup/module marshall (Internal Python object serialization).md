MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/marshal.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[serialization]]
Date : 2025-01-11
***


