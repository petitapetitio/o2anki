MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-25
***

https://docs.python.org/3/reference/expressions.html#generator-expressions
https://docs.python.org/3/glossary.html#term-generator-expression


***
TARGET DECK: Python
FILE TAGS: 

- STARTI [Basic] qu'est-ce qu'une expression génératrice ? Back:  une expression qui renvoie un objet *générateur* (un itérateur) <!--ID: 1730827064680--> ENDI
- STARTI [Basic] quel est l'intérêt des fonctions génératrices ? Back:  elles permettent de produire les valeurs une par une de façon paresseuse ENDI
- STARTI [Basic] Quelle est la syntaxe complète d'une genexp non imbriquée ? Back: `(expression for target in iterable if condition)` <!--ID: 1730827064685--> ENDI
- STARTI [Basic] quel est le surnom d'une expression génératrice ? Back:  genexp <!--ID: 1730827064687--> ENDI
- STARTI [Basic] une expression génératrice peut-elle capturer une valeur comme une fonction génératrice ? Back:  Non, une expression génératrice est conçue uniquement pour produire des valeurs <!--ID: 1730827064689--> ENDI
- STARTI [Basic] Quelle est la différence de syntaxe entre genexp et listcomp ? Back: Les délimiteurs : `()` pour genexp, `[]` pour listcomp <!--ID: 1730827064691--> ENDI
- STARTI [Basic] quelle est la différence entre <br>`sum([x * x for x in range(10)])` <br>et <br>`sum(x * x for x in range(10))` ? Back: La deuxième produit une `genexp`. Elle est plus efficace en terme de mémoire car elle produit les valeurs une par une. <!--ID: 1730827064693--> ENDI


START
Basic
Qu'affiche 
```python
xs = (x for x in range(3)) 
print(list(xs), sum(xs))
```
?
Back:
`[O, 1, 2] 0` ([[gotcha]])

Lorsque l'on passe `squares` dans la fonction somme, il a déjà été consommé. 

Il serait possible de prévenir ce type d'erreur en enveloppant un itérateur dans un classe `StrictGenerator` qui lèverait une exception lorsque l'on atteins la fin de la séquence plus d'une fois.
<!--ID: 1730827064678-->
END
