MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-26
***

***
TARGET DECK: Python
FILE TAGS: paramètres

- qu'est-ce qu'un paramètre positional-or-keyword ? un paramètre qui peut être passé par sa position ou de façon nommée. C'est le type de paramètre ordinaire. Dans `f(x, y=0)`, `x` et `y` sont tous les deux des paramètres positional-or-keyword
- à quelle moment est-ce que la valeur par défaut d'un paramètre est évaluée ? au moment de l'exécution de l'instruction `def`. Cela implique que tous les appels de fonction reçoivent la même variable comme valeur par défaut.
