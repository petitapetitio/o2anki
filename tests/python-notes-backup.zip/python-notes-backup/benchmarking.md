MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2025-01-17
***

- le [[load testing]] est une forme de benchmarking
- outils [[Python]] : [[module timeit]]