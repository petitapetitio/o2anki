MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

Concepts
- [[thread]]
- An action is known as <u>atomic</u> when it’s guaranteed that no thread switching occurs between the start and the end of the action.


Remarks
- Don't rely on atomicity assumptions
- Key design issue : coordonner de multiples threads
- operating system can swap threads at any time, but it generally lets each thread have a reasonable amount of time to run before swapping it out
- [[Stick with single threading as long as you can]]
- [[cooperative vs preemptive]]
