MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/exceptions.html#BaseException
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-05
***

***
TARGET DECK: Python
FILE TAGS: exceptions

- STARTI [Basic] quelle est la classe de base de toutes les exceptions ? Back:  `BaseException` <!--ID: 1730827063573--> ENDI
- STARTI [Basic] exceptions : à quoi sert `e.with_traceback(tb)` ? Back:  Modifier la traceback d'une exception (typiquement pour masquer les détails d'implémentation d'une bibliothèque).  <!--ID: 1730827063575--> ENDI
- STARTI [Basic] exceptions : quelle est la différence entre `from None` et `with_traceback` ? Back:   `with_traceback` permet un contrôle plus fin. <!--ID: 1730827063577--> ENDI
- STARTI [Basic] exceptions : `e.args` ? Back:  Le [[tuple]] des arguments qui ont construit l'exception <!--ID: 1730827063579--> ENDI
- STARTI [Basic] exceptions : `exc.__notes__` ? Back:  La liste des notes ajoutées à l'exception en utilisant `exc.add_note(note)` <!--ID: 1730827063586--> ENDI
- STARTI [Basic] exceptions : quelle est la façon recommandée d'appeler `e.__notes__` ? Back:  `getattr(e, "__notes__", [])` car l'attribut `__notes__` n'est créé que si `add_note` est appelé sur l'exception. <!--ID: 1730827063589--> ENDI

START
Basic
exceptions : `e.__cause__` ?
Back:
L'exception source, chaînée de façon explicite via `raise ... from ...`
```python
try:
    1/0
except ZeroDivisionError as e:
    raise ValueError("nombre invalide") from e
```
([doc](https://docs.python.org/3/library/exceptions.html#BaseException.__cause__))
<!--ID: 1730827063582-->
END

START
Basic
exceptions : `e.__context__` ?
Back:
L'exception qui était en cours de traitement quand `e` est survenue (chaînée de façon implicite).
```python
try:
    1/0
except ZeroDivisionError:
    int('abc')  # ValueError avec ZeroDivisionError comme contexte
```
<!--ID: 1730827063584-->
END

START
Basic
exceptions : à quelles conditions est-ce que `e.__context__` est affiché ?
Back:
Si à la fois <br>1) `e.__cause__` est `None` (pas de chaînage explicite) <br>2) `e.__suppress_context__` est `False`

Exemple où `e.__cause__` et `e.__context__` ont des valeurs différentes : 
```python
try:
    1/0  # ZeroDivisionError
except ZeroDivisionError as e:
    try:
        int('abc')  # ValueError
    except ValueError as ve:
        raise RuntimeError from e  
        # ZeroDivisionError est .__cause__
        # ValueError est .__context__
```
<!--ID: 1732861681425-->
END