MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-03
***


***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] Que fait `ClassVar` ? Back:  Empêche qu'une variable de classe soit redéfinie comme variable d'instance <!--ID: 1730827063845--> ENDI
- STARTI [Basic] Une sous-classe peut-elle redéfinir une variable `stats` marquée `ClassVar` ? Back:  Oui, mais uniquement comme variable de classe : `Concrete.stats = {}` <!--ID: 1730827063847--> ENDI

START
Basic
Comment prévenir qu'une variable de classe soit redéfinie comme variable d'instance ?
Back:
```python
class Base:
	stats: ClassVar[dict[str, int]] = {} 

class Concrete(Base):
    def __init__(self):
        self.stats = {}  # intercepté par l'analyseur statique
```
<!--ID: 1730827063843-->
END
