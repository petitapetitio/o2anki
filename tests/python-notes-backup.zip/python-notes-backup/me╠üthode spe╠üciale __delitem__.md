MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-31
***

***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] par quel appel de méthode spéciale se traduit `del x[key]` ? Back:  `x.__delitem__(key)` <!--ID: 1730827064055--> ENDI
- STARTI [Basic] à quel moment est appelé `x.__delitem__(key)` ? Back:  Lorsqu'on exécute `del x[key]` <!--ID: 1730827064059--> ENDI
