MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-08
***

***
TARGET DECK: Python
FILE TAGS: imports

- STARTI [Basic] où est stocké le [[fichier compilé .pyc]] du programme principal ? Back:  il est gardé en mémoire et n'est pas enregistré sur le disque <!--ID: 1731677487765--> ENDI
- STARTI [Basic] quel est le nom de [[module]] du programme principale ? Back:  `__main__` <!--ID: 1731677487766--> ENDI
- STARTI [Basic] comment n'exécuter du code dans un module que s'il est utilisé comme programme principal ? Back:  `if __name__ == '__main__':` ([[tricks]]) <!--ID: 1731677487768--> ENDI

START
Basic
Que produit l'exécution de `recursive.py` :
```python
print(f"I'm {__name__}")
import recursive
```
Back:
Affiche
```
I'm __main__
I'm recursive
```
<!--ID: 1731677487767-->
END
