MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/glossary.html#term-argument
Projet : [[$P - Mémoriser Python (Mastering Python)]], 
Tags : [[Python]], [[Appel de fonction]]
Date : 2024-10-24
***

- [[Argument positionnel]]
- [[Argument nommé]]


***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] qu'est-ce qu'un argument ? Back:  une valeur passée à une fonction ou à une méthode lors de son appel. <!--ID: 1729754352001--> ENDI
- STARTI [Basic] quels sont les deux types d'arguments ? Back:  Les arguments positionnels et les arguments nommés (aka keywords) qui sont passés sous la forme `name=expression`. <!--ID: 1729754352002--> ENDI
- STARTI [Basic] Que valent les paramètres de la fonction de signature `f(a, b, c=23, d=42, *x)` dans l'appel `f(1,2,3,4,5,6)` ? Back:  `1, 2, 3, 4, (5, 6)` <!--ID: 1729754352004--> ENDI
- STARTI [Basic] Que valent les paramètres de la fonction de signature `f(a, b, *x, c=23, d=42)` dans l'appel `f(1,2,3,4,5,6)` ? Back:  `1, 2, (3, 4, 5, 6), 23, 42` <!--ID: 1729754352006--> ENDI
- STARTI [Basic] à quoi correspond l'appel `f(1, 2, *[3, 4])` ? Back:  `f(1, 2, 3, 4)` <!--ID: 1729754352007--> ENDI
- STARTI [Basic] à quoi correspond l'appel `f(1, 2, **{'c': 3, 'd': 4})` ? Back:  `f(1, 2, c=3, d=4)` <!--ID: 1729754352009--> ENDI
- STARTI [Basic] à quoi correspond l'appel `f(1, 2, *{'c': 3, 'd': 4}, 5)` ? Back:  `f(1, 2, 'c', 'd', 5)` ([[gotcha]]) <!--ID: 1729754352011--> ENDI
- STARTI [Basic] que renvoie l'appel `f(0, x=1)` à la fonction de signature `f(x)` ? Back:  `TypeError: f(x) got multiple values for argument 'x'` <!--ID: 1729754352012--> ENDI
- STARTI [Basic]  que renvoie l'appel `f(x=0, x=1)` à la fonction de signature `f(x)` ? Back:  `SyntaxError: keyword argument repeated: x`. <!--ID: 1729754352014--> ENDI
- STARTI [Basic] comment est-ce que les arguments sont passés en Python ? Back: par copie de référence (la référence à l'objet est copiée mais pas l'objet lui-même) <!--ID: 1729754352015--> ENDI
