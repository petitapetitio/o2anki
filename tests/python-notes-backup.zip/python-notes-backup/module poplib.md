MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-18
***

- https://docs.python.org/3/library/poplib.html
- [[Post Office Protocol (POP3)]]
- classes
	- POP3
	- POP3_SSL (une sous-classe de POP3)
