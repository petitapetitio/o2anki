Date : 2024-01-15
***

- objet qui peut être utilisé dans une expression `await`
- 3 types : [[Task]], [[Coroutine]], [[Future (Object  Function)]]