
- aka cyclic garbage
- quand des objets se référencent entre eux mais qu'ils ne sont plus lié à aucune variable locale ou globale du programme)

![[mutual reference loop (cyclic garbage collections)-1.png]]![[mutual reference loop (cyclic garbage collections)-1.drawio]]