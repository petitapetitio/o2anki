MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-25
***

https://docs.python.org/3/reference/simple_stmts.html#the-yield-statement
https://docs.python.org/3/reference/expressions.html#yield-expressions
https://docs.python.org/3/glossary.html#term-generator
https://docs.python.org/fr/3/glossary.html#term-generator-iterator


Exemple de fonction génératrice
```python
def generator_function():
    yield 123

generator_iterator = generator_function() 

print(next(generator_iterator)) # Affiche 123
print(type(generator_iterator)) # Affiche <class 'generator'>
```

***
TARGET DECK: Python
FILE TAGS: fonctions


- STARTI [Basic] qu'est-ce qu'une *fonction génératrice* ? Back:  Une fonction qui renvoie un [[objet générateur]] <!--ID: 1730827064616--> ENDI
- STARTI [Basic] quel est l'intérêt des *fonctions génératrices* ? Back: produire les valeurs au fur et à mesure, ce qui économise de la mémoire. ([[Juste-à-temps (Just-in-time, JIT)]])  <!--ID: 1730827064634--> ENDI
- STARTI [Basic] à quoi reconnaît-on une *fonction génératrice* ? Back: Son corps contient un `yield` <!--ID: 1730827064619--> ENDI
- STARTI [Basic] `yield` est-il utilisé dans un autre cadre que celui des fonctions génératrices ? Back:  Non <!--ID: 1730827064622--> ENDI
- STARTI [Basic] Est-ce que `yield` est une instruction ou une expression ? Back: Les deux. <br>Comme expression : **capture** une valeur — initialisée dans le générateur ou envoyée dans le générateur via send().  <br>Comme instruction : **renvoie** une valeur (au consommateur du générateur) <!--ID: 1730827064624--> ENDI
- STARTI [Basic] que renvoie l'appel à une *fonction génératrice* ? Back:  Un *objet générateur* (iterator object, parfois appelé generator object en référence à l'implémentation en CPython.) <!--ID: 1730827064627--> ENDI
- STARTI [Basic] que contient l'*objet générateur* renvoyé par un appel de *fonction génératrice* ? Back:  <br>- le corps de la fonction <br>- ses variables locales (paramètres inclus) <br>- le point d'exécution actuel (initialement, le début de la fonction) <!--ID: 1730827064629--> ENDI

**yield from**
- STARTI [Basic] que produit `yield from iterable` ? Back: L’équivalent de `for e in iterable: yield e` <!--ID: 1730827064637--> ENDI
- STARTI [Basic] quelle contrainte doit respecter `expr` dans `yield from expr` ? Back:  `expr` doit être un itérable <!--ID: 1730827064639--> ENDI


START
Basic
Comment simplifier ce code 
```python
for x in expr:
    yield x
```
?
Back:
`yield from expr`
<!--ID: 1730827064614-->
END
