MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-15
***

- widely used in academic environments, particularly in data science and engineering, artificial intelligence, and financial analytics.
