MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/stdtypes.html#bytearray
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***

- séquence mutable et ordonnée d'entiers allant de 0 à 255
- comme un [[bytes]] mais mutable

***
TARGET DECK: Python
FILE TAGS: bytes

- STARTI [Basic] Quelle est la différence entre `bytes` et `bytearray` ? Back: `bytearray` est mutable. <!--ID: 1728024344755--> ENDI
- STARTI [Basic] `isinstance(bytearray(b'a'), bytes)` Back: `False` <!--ID: 1728024344759--> ENDI