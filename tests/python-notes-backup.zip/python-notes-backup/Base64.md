MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-19
***

- permet de transformer des données binaires en chaîne de caractère
- la source est prise 6 digits at a time et est mapé avec un des 64 caractères de l'alphabet
- alphabet : `[A-Za-z0-9+/]` et *=* pour le padding

```python
# ✅ Chaînes base64 valides
"hell"
"AAA="
"AA=="
"ab+/"

# ❌ Chaînes invalides
"abc"  # pas un multiple de 4
"abc?" # caractère en dehors de l'alphabet
"a===" # padding impossible
```


```python
import re

def is_valid_base64(s):
    # Vérifier l'alphabet et la présence d'au + deux carctères '=' à la fin
    # Vérifier que la longueur est un multiple de 4
    return re.match(r'^[A-Za-z0-9+/]*={0,2}$', s.decode()) and len(s) % 4 == 0
```
