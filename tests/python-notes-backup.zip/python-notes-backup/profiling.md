MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-17
***

- instrumenter le programme afin d'identifier les [[contrainte (bottleneck)]]
- pourquoi ?
	- measure, don't try to guess
	- [[Identifie le bottlneck avant d'optimiser (Premature optimization)]]
- tools
	- [[modules profile et cProfile (The Python Profilers)]]
	- pyinstrument - https://github.com/joerick/pyinstrument
	- Eliot
