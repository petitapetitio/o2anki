MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***

"Regarder avant de sauter"

Analogies : 
- [[Ceinture et bretelles]]
- Tremper le petit doigt de pieds dans l'eau avant de se mouiller

***
TARGET DECK: Python
FILE TAGS: exceptions


- STARTI [Basic] Que signifie LBYL ? Back:  Look Before You Leap <!--ID: 1730972172950--> ENDI
- STARTI [Basic] Que signifie LBYL (Look Before You Leap) en Python ? Back: Vérifier les pré-conditions avant d'effectuer une opération (plutôt que de gérer les erreurs après coup). <!--ID: 1730972172953--> ENDI
- STARTI [Basic] Quel est les problèmes du style LBYL ? Back:  <br>1) **performance** : Les vérifications peuvent dupliquer une part significative du travail de l'opération elle-même. <br>2) **fiabilité** : la situation peut changer entre la vérification et l'exécution de l'opération (Race condition) <!--ID: 1730972172955--> ENDI
- Analogie : ne pas attendre de s'être tapé le mur pour réagir

START
Basic
Comment accéder à la clé `'key'` d'un dictionnaire `d` en style LBYL ?
Back:
```python
if "key" in d:
    value = d["key"]
```
<!--ID: 1730972172948-->
END
