MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-18
***

- https://docs.python.org/3/library/ssl.html
- https://docs.python.org/3/library/ssl.html#ssl-security (important)
- stick with the default TLS context (unless you really know what you're doing)
- `SSLContext`
	- contient les informations sur la config TLS (certificats, clés privées, ...)
	- utilise `ssl.create_default_context` si tu ne sais pas trop ce que tu fais

###### Le minimum vital

Côté client
```python
ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
sock = socket.socket(socket.AF_INET)
sock = ctx.wrap_socket(sock, server_hostname='www.example.com'))
sock.connect(('www.example.com', 443))
```

Côté serveur
```python
sock = socket.socket(socket.AF_INET)
sock.bind(('www.example.com', 443))
sock.listen(5)
while True:
    connected_socket, address = sock.accept()
    connected_socket = ctx.wrap_socket(sock, server_side=True)
    # handle `connected_socket` as usual
```

Certaines serveurs demande que le client soit authentifié. Pour cela : 
```python
ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
ctx.load_cert_chain(certfile='mycert.pem', keyfile='mykey.key')
```
