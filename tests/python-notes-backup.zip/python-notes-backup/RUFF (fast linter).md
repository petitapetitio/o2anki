MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.astral.sh/ruff/
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-29
***

https://docs.astral.sh/ruff/
https://si-confluence.edf.fr/display/dsepdrs/Ruff

Utilisé par [[Timothy Crosley]]