MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-19
***

- parsing, generation et manipulation de fichiers [[MIME]]
- pour envoyer / recevoir des e-mails : [[module smtplib]], [[module imaplib]]
- classes
	- `Message`
		- classe utilisée par les modules Generator, ...
		- structure
			- headers (see [[common internet message headers]])
			- payload (string / another Message, a multipart message)
	- Helpers : `MIMEAudio`, `MIMEBase`, `MIMEImage`, `MIMEMessage`, `MIMEText` 
	- Encoders
		- prend un message *nonmultipart*, encode son payload, et définit ses headers
		- `encode_base64` (usually optimal), `encode_noop` (does nothing), `encode_quopri`, `encode_7or8bit`
	- Utils
		- `formataddr` pour mettre dans `To`, `Cc`
		- `formatdate` (format de la RFC 2822) / `parsedate`
		- `quote` (`"`→ `\"` et `\` → `\\`)
