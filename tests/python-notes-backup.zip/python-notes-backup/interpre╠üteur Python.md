MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/using/cmdline.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

- Le programme que tu lances quand tu tapes `python` dans ton terminal
- L'interpreter python compile automatiquement les modules en bytecode et les enregistre dans un sous-dossier `__pycache__` du dossier du module source.
- Syntaxe : `[path]python {options} [-c command | -m module | file | -] {args}`
- Variables d'environnements
	- `PYTHONHOME` :
		- chemin vers la bibliothèque standard
		- doit contenir un dossier `lib/python3.x` pour Python 3.x
	- `PYTHONPATH` :
		- la liste des répertoires depuis lesquels python peut importer des modules
		- étend la liste de valeurs initiales de `sys.path`
	- `PYTHONSTARTUP` : 
		- fichier python à exécuter par défaut lorsque tu lances une session interactive
- Command line options
	- `-B`
	- `-c` : donne des instructions dans la ligne de commande (ex: `$ python -c "import time; print(time.asctime())"`
	- `-m` : donne un module comme script principal et regarde en priorité `__main__.py` (ex : `python -m timeit`)
	- `-E` : ignore toutes les variables d'environnement
	- `-i` : consomme le fichier ou la commande puis lance une session interactive
	- `-O` : optimize le bytecode
	- `-OO` : optimise le bytecode et supprime les docstrings du bytecode
	- `-V` : affiche la version de python
	- `-P` : https://docs.python.org/3/using/cmdline.html#cmdoption-P ([[sys.path]])
- [[Console Python interactive (REPL)]]




***
TARGET DECK: Python
FILE TAGS: interpreter

- STARTI [Basic] Quelle est la syntaxe de l'interpréteur python Back: `[path]python {options} [-c command | -m module | file | -] {args}` <!--ID: 1727542890106--> ENDI
- STARTI [Basic] Interpreter : comment exécuter l'instruction `print('hello')` ? Back:  `python -c "print('hello')"` <!--ID: 1729447957708--> ENDI
- STARTI [Basic] Interpreter : comment exécuter le module http.server pour lancer un serveur local simple ? Back:  `python -m http.server` <!--ID: 1729447957713--> ENDI
- STARTI [Basic] Interpreter : comment exécuter le fichier `script.py` ? Back:  `python script.py` <!--ID: 1729447957717--> ENDI
- STARTI [Basic] Interpreter : comment exécuter le texte produit par la sortie standard `echo "print('hello')"` ? Back:  `echo "print('hello')" | python -` <!--ID: 1729447957720--> ENDI
- STARTI [Basic] Interpreter : comment exécuter le script `script.py` et continuer sur une session interactive ? Back:  `python -i script.py` <!--ID: 1729447957725--> ENDI
- STARTI [Basic] Interpreter : comment exécuter le script `script.py` en mode verbeux ? Back:  `python -v script.py` <!--ID: 1729447957727--> ENDI
- STARTI [Basic] Interpreter : comment afficher la version de python ? Back:  `python -V` (majuscule) ou `python --version` <!--ID: 1729447957730--> ENDI
- STARTI [Basic] Interpreter : comment exécuter le script `script.py` en supprimant les asserts ? Back:  `python -O script.py`<!--ID: 1729447957733--> ENDI
- STARTI [Basic] Interpreter : comment exécuter le script `script.py` en supprimant les docstrings (et les asserts) ? Back:  `python -OO script.py` <!--ID: 1732689948971--> ENDI
- STARTI [Basic] Que contiennent les dossiers `__pycache__` Back: Le bytecode des modules qui sont situés dans le même dossier. <!--ID: 1727542890108--> ENDI
- STARTI [Basic] À quoi sert la variable d'environnement `PYTHONHOME` ? Back: Elle indiquer le chemin vers la bibliothèque standard python <!--ID: 1727542890110--> ENDI
- STARTI [Basic] À quoi sert la variable d'environnement `PYTHONPATH` ? Back: Elle lister des répertoires depuis lesquels python peut importer des modules. Elle étend la valeur de `sys.path`. (mémo : PYTHON**PATH**, sys.**path**) <!--ID: 1727542890112--> ENDI
- STARTI [Basic] À quoi sert la variable d'environnement `PYTHONSTARTUP` ? Back: Elle indique le chemin vers un script python à exécuter par défaut lorsque tu lances `python` <!--ID: 1727542890114--> ENDI

Post : 
- [[$A - L'interpréteur python]]