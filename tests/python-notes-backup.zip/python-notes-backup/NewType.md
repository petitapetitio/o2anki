MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/fr/3.13/library/typing.html#newtype
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-03
***

***
TARGET DECK: Python
FILE TAGS: 

START
Basic
Quel est le principal intérêt de `NewType` ?
Back: 
Créer des types distincts à partir d'un même type de base pour éviter les confusions dans le passage des paramètres.
```python
from typing import NewType

UserId = NewType('UserId', int)
GroupId = NewType('GroupId', int)

def add_to_group(user: UserId, group: GroupId): ...

add_to_group(GroupId(1), UserId(2))  # Erreur de type !
```

RQ : les [[Value Object]] sont une solution plus complète à ce problème, qui répond en + à des principes comme [[Parse, don't validate]].
<!--ID: 1730827063823-->
END


Poke [[Ayoub El Khallioui]] avec le curr_ts et prev_ts.
