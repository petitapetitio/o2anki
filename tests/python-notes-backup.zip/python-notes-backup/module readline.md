MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-10
***

- https://docs.python.org/3/library/readline.html
- wrapping de GNU readline
- utile pour faire 
	- un programme en lignes de commandes et proposer de l'auto-complétion
	- un shell personnalisé
