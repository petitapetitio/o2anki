MOC : [[SOFTWARE ENGINEERING]], [[Python|Python]]
Source : 
Projets : [[_Publier 10 screencast de Kata]]
Tags : 
Date : 2024-02-01
***


```python
from functools import wraps


def factory_method(fn):
    @wraps(fn)
    def _factory_method(cls, *args, **kwargs):
        factory_key = getattr(cls, "__call_from_factory_method_flag", None)
        if not factory_key:
            factory_key = object()
            setattr(cls, "__call_from_factory_method_flag", factory_key)
        value = fn(cls, *args, **kwargs)
        setattr(cls, "__call_from_factory_method_flag", None)
        return value

    return _factory_method


def instantiable_by_factory_methods_only(cls):

    original_init = getattr(cls, "__init__")

    def patch_init(self, *_args, **_kwargs):
        stored_key = getattr(self, "__call_from_factory_method_flag", None)
        if not stored_key:
            raise RuntimeError("Direct instantiation not allowed")
        original_init(self, *_args, **_kwargs)

    setattr(cls, "__init__", patch_init)
    return cls
```

```python
from dataclasses import dataclass

from pgcd import pgcd
from factory_utils import factory_method, instantiable_by_factory_methods_only


@dataclass(frozen=True, init=False)
@instantiable_by_factory_methods_only
class Fraction:
    _numerator: int
    _denominator: int

    def __init__(self, num: int, den: int):
        # self._numerator: int = num
        # self._denominator: int = den
        object.__setattr__(self, '_numerator', num)
        object.__setattr__(self, '_denominator', den)

    @classmethod
    @factory_method
    def of(cls, numerator: int, denominator: int):
        if denominator == 0:
            raise Exception
        d = pgcd(numerator, denominator)
        return Fraction(numerator // d, denominator // d)

    def __add__(self, other):
        if isinstance(other, Fraction):
            num = self._numerator * other._denominator + other._numerator * self._denominator
            den = self._denominator * other._denominator
            return Fraction.of(num, den)

    def numerator(self) -> int:
        return self._numerator

    def denominator(self) -> int:
        return self._denominator
```
