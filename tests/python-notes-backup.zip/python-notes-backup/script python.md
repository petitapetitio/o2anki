MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***

Un script python est fichier que tu peux exécuter directement

Par exemple le fichier `hello.py` avec le contenu suivant : 
```python
print("hello")
```
