MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://docs.python.org/3/reference/simple_stmts.html#the-assert-statement
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***

- est une [[instruction simple (simple statement)]]

***
TARGET DECK: Python
FILE TAGS: exceptions

- STARTI [Basic] À quoi sert l'instruction assert ? Back:  Vérifier une condition pendant le développement. Désactivée avec `-O` <!--ID: 1730972172906--> ENDI
- STARTI [Basic] Quand utiliser assert ? Back: Documenter un invariant <!--ID: 1730972172908--> ENDI
- STARTI [Basic] Quand l'usage d'assert est-il contre-indiqué ? Back: Pour valider des données (entrées, arguments) <!--ID: 1730972172911--> ENDI
- STARTI [Basic] Pourquoi est-ce que les `assert` ne doivent pas être utilisées pour la validation ? Back:  Elles sont ignorées quand Python est exécuté avec l'option d'optimisation `-O`. <!--ID: 1730972172913--> ENDI
- STARTI [Basic] Que produit `assert False, "not good"` ? Back: lève `AssertionError("not good")` <!--ID: 1730972172916--> ENDI
- STARTI [Basic] Comment faire pour qu'une fonction utilisée uniquement dans un `assert` ne soit pas incluse avec l'option `-O` ? Back:  Placer la fonction dans un `if __debug__:` <!--ID: 1730972172919--> ENDI

