MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/datamodel.html#object.__del__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] que permet la méthode spéciale  `__del__` ? Back: Définir les actions à exécuter avant que l'instance soit libérée. <!--ID: 1730827064478--> ENDI
- STARTI [Basic] quand appelé `x.__del__()` ? Back:  Juste avant que `x` soit libérée par le garbage collector. <!--ID: 1730827064479--> ENDI
- STARTI [Basic] est-ce que `del x` exécute `x.__del__` ? Back:  Non. <br>Les deux instructions ne sont pas directement liées. L'instruction `__del__` n'est exécutée que au moment de la libération de l'object par le garbage collector. <!--ID: 1730827064481--> ENDI
- STARTI [Basic] Comment gérer la finalisation de façon plus prédictible que `__del__` ? Back: Utiliser un gestionnaire de contexte `with` ([[instruction with]]) ou `try/finally` ([[instruction try]]) <!--ID: 1730827064483--> ENDI
