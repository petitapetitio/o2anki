MOC : 
Source : 
Projet : 
Tags : 
Date : 2024-09-26
***


- +4K posts on python on  SO : https://stackoverflow.com/users/95810/alex-martelli
- autheur de [[Python in a Nutshell]]
- recommandé par [[Luciano Ramalho]]

