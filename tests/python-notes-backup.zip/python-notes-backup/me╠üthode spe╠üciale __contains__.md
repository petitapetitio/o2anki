MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[test de présence (opérateur in)]]
Date : 2024-10-31
***

***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] que renvoie `elts.__contains__(x)` lorsque `elts` est une [[sequence]] ? Back: Vrai si un élément de `elts` est égal à `x`. <!--ID: 1730827064065--> ENDI
- STARTI [Basic] que renvoie `elts.__contains__(x)` lorsque `elts` est un [[mapping]] ? Back:  Vrai si une clé de `elts` est égale à `x`. <!--ID: 1730827064068--> ENDI
- STARTI [Basic] par quel appel de méthode spéciale se traduit le test de présence `x in elts` ? Back:  `elts.__contains__(x)` <!--ID: 1730827064070--> ENDI
