- Guide de style pour [[Python]] promu par le langage
- https://peps.python.org/pep-0008/




