MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***

- Discuté en détails + loin mais je peux déjà créer la note ici.
- Quelles sont les clauses que peut inclure une instruction try ? try, except, finally, else
