MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/pathlib.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-14
***

Méthodes
- créer un fichier `testfile.txt` ? `Path('testfile.txt').touch()`
- le chemin absolu de `p = Path('~/dev/python-demo/a/../b/')` ? `p.expanduser().resolve()` (`/Users/lxnd/test/b`)
- le chemin absolu du dossier courant ? `pathlib.Path.cwd()` ou `pathlib.Path().resolve()` ![[2024-09-28 Python in a nutshell-18.png]]
- la liste des fichiers `.txt` du dossier `data` (et sous-dossiers) ? `pathlib.Path('data').glob('**/*.txt')`

Attributs
- le chemin parent de `p = Path('data/chr.zip')` ? `p.parent` (`'data'`)
- le nom du fichier `p = Path('data/archive.tar.gz')` ? `p.name` (`'archive.tat.gz'`)
- stem
	- le nom de fichier de `p = Path('data/chr.zip')` sans le suffixe ? `p.stem` (`'chr'`)
	- `Path('data/archive.tar.gz').stem`  ? `'archive.tar'` ([[gotcha]])
- `Path('data/archive.tar.gz').suffix` ? `'.gz'`
- `Path('data/archive.tar.gz').suffixes` ? `['.tar', '.gz']`
