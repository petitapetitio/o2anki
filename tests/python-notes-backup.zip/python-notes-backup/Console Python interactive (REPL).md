MOC : [[SOFTWARE ENGINEERING]]
Source : 
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[read-eval-print-loop (REPL)]]
Date : 2024-09-28
***

- idéales pour explorer et expérimenter
- me font penser à la console [[JavaScript]] dans le navigateur
- capture le dernier résultat affiché dans la variable "\_"
- help(obj)
- help() : démarre le mode aide about python's keywords and operators
- pour quitter : 
	- [[EOF]]
	- `exit()` ou `quit()`
	- `sys.exit()`, `raise SystemExit`


***
TARGET DECK: Python
FILE TAGS: interpreter


- STARTI [Basic] Quel est le cas d'usage le plus courant de la console interactive ? Back: Explorer et expérimenter <!--ID: 1727542890146--> ENDI
- STARTI [Basic] Comment sortir de la console interactive ? Back: Taper un `EOF`, entrer `exit()`, `quit()`, `sys.exit()` ou `raise SystemExit`. <!--ID: 1727542890148--> ENDI
- STARTI [Basic] Après avoir entré `1 + 1` dans la console interactive, comment référencer le résultat ?  Back: `_` <!--ID: 1727542890150--> ENDI
- STARTI [Basic] REPL : À quel objet fait référence la variable `_` dans la console interactive ?  Back: Au résultat de la dernière expression qui a été évaluée sans être assignée <!--ID: 1730827064740--> ENDI
- STARTI [Basic] REPL - Comment afficher la doc d'un objet ? Back: `help(obj)` <!--ID: 1727542890151--> ENDI
- STARTI [Basic] REPL - qu'affiche `help(5)` ? Back: la doc du type `int` <!--ID: 1727542890154--> ENDI
- STARTI [Basic] REPL - qu'affiche `help(int)` ? Back: la doc du type `int` <!--ID: 1727542890156--> ENDI
- STARTI [Basic] Que signifie REPL ? Back: read-eval-print-loop <!--ID: 1727542890158--> ENDI
