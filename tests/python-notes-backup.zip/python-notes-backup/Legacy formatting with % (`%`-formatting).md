MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-20
***

***
TARGET DECK: Python
FILE TAGS: 

- quand ? lazy formatting dans la console avec le [[module logging]]
