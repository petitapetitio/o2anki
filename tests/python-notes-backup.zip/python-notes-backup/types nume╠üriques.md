MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/stdtypes.html#numeric-types-int-float-complex
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-16
***


***
TARGET DECK: Python
FILE TAGS: stdtypes

- STARTI [Basic] Quels sont les 3 types numériques built-int ? Back: <br>[[entier (int)]] <br>[[Nombres à virgules flottantes (floats)]] <br>[[nombres complexes (complex)]] <br><!--ID: 1727939491440--> ENDI
- STARTI [Basic] Que signifie "built-in" ? Back: "intégré", "natif" <!--ID: 1727939491444--> ENDI
- STARTI [Basic] Comment améliorer la lisibilité du littéral entier `1000000000` ? Back: Placer des `_` :  `1_000_000_000` <!--ID: 1727939491448--> ENDI
- STARTI [Basic] Que vaut `0_0` ? Back: `0`. Les underscores peuvent être placés n'importe dans les littéraux numériques - sauf aux extrémités <!--ID: 1727939491452--> ENDI
