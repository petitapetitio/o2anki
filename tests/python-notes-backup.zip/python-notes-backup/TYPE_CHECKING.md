MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/typing.html#typing.TYPE_CHECKING
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-04
***

Ressources : 
- https://mypy.readthedocs.io/en/stable/runtime_troubles.html#typing-type-checking

***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] que vaut `TYPE_CHECKING` au runtime ? Back:  `False` <!--ID: 1730827063734--> ENDI
- STARTI [Basic] que vaut `TYPE_CHECKING` lorsqu'un type checker statique inspecte le code ? Back:  `True` <!--ID: 1730827063736--> ENDI
- STARTI [Basic] que permet `TYPE_CHECKING` ? Back:  <br>1) éviter au runtime les imports lents nécessaires uniquement pour la validation des types <br>2) gérer les références circulaires introduites par les annotations <br> <!--ID: 1730827063738--> ENDI
START
Basic
Quelles sont les 3 façons d'accéder aux annotations d'un objet au runtime ?
Back:
`typing.get_type_hints(obj)`
`obj.__annotations__`
`inspect.get_annotations(obj)`

```python
class A:  
	a: int  
	b: float  

print(typing.get_type_hints(A))  
print(A.__annotations__)  
print(inspect.get_annotations(A))
# Ces trois lignes affichent
# {'a': <class 'int'>, 'b': <class 'float'>}

```
<!--ID: 1730827063741-->
END
