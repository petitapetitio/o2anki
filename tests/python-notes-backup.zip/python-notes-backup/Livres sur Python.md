MOC : [[SOFTWARE ENGINEERING]]
Source : 
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-12-09
***

- https://pythonbooks.org/
- https://wiki.python.org/moin/BeginnersGuide
- [[Fluent Python]]
- [[Head First Python]]
- [[Beginning Python]]
- [[Publishing Python Packages - Test, Share, and Automate Your Projects]]
- Effective Python 
- Think python
- Learning Python
- [[CPython Internals]]
- [[Design Patterns in Python]]
- [[Python - Manuel de référence]]
- [[Automate the Boring Stuff with Python 3rd Edition]]
- [[Python Crash Course 3rd Edition]]
- [[Beyond the Basic Stuff with Python]]
- [[full-speed-python.pdf]]
- Beginning Python: From Novice to Professional
- Think Python - (just a quick introduction - 66 pages)


Regarder l'éditeur
- PAKT : disapointed
- O'Reilly (usually great books)