MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/library/stdtypes.html#mapping-types-dict
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-10-03
***

- le type dict est le seul [[mapping]] built-in
- les dictionnaires ne sont pas nécessairement ordonnés
- la clé d'un dictionnaire doit être hachable
- les valeurs d'un dictionnaire peuvent être de n'importe quel type


***
TARGET DECK: Python
FILE TAGS: dict

Qu'est-ce qu'un objet de type `dict` aka mapping ? 
- Un objet qui fait correspondre des clés hashables à des valeurs arbitraires.
- Un objet qui associe des valeurs arbitraires à des clés hashables 
- Un objet qui associe des clés hashables à des valeurs arbitraires.

- STARTI [Basic] Qu'est-ce qu'un objet de type `dict` aka mapping ? Back: Un objet qui associe des valeurs arbitraires à des clés hashables. <!--ID: 1728024344594--> ENDI
- STARTI [Basic] Quelles sont les deux façons de créer un dictionnaire vide ? Back:  `dict()`, ou `{}` de façon littérale <!--ID: 1728024344598--> ENDI
- STARTI [Basic] Quelle contrainte doit valider la clé d'un dictionnaire ? Back:  Elle doit être hashable. <!--ID: 1728024344600--> ENDI
- STARTI [Basic] `type({})` ? Back:  `<class 'dict'>` <!--ID: 1728024344603--> ENDI
- STARTI [Basic] À quel littéral correspond `dict([(1, 2), (3, 4)])` ? Back:  `{1: 2, 3: 4}` <!--ID: 1728024344606--> ENDI
- STARTI [Basic] À quel littéral correspond `dict(x=42, y=3.14)` ? Back:  `{'x': 42, 'y': 3.14}` <!--ID: 1728024344610--> ENDI
- STARTI [Basic] Qu'est-ce qu'un item de dictionnaire ? Back: un couple (clé, valeur) <!--ID: 1728024344614--> ENDI 
- STARTI [Basic] `{1: 'a', 2: 'b'} == {2: 'b', 1: 'a'}` ? Back:  Vrai. La comparaison ne tient pas compte de l'ordre d'insertion. <!--ID: 1728024344618--> ENDI
- STARTI [Basic] `list({1: 'a', 2: 'b'}) == list({2: 'b', 1: 'a'})` ? Back:  False. L'ordre d'insertion est garanti depuis Python 3.7 <!--ID: 1728024344621--> ENDI
- STARTI [Basic] `list({1: 'a', 2: 'b'})` ? Back: `[1, 2]` - cela permet d'itérer sur les clés. <!--ID: 1728024344623--> ENDI
- STARTI [Basic] `dict([('x', 1), ('y', 2)], x=3)` ? Back:  `{'x': 3, 'y': 2}`. L'argument nommé "gagne". <!--ID: 1728024344625--> ENDI
- STARTI [Basic] Comment fusionner deux dictionnaires par copie (2 façons) ? Back:  `{**d1, **d2}` ou `d1 | d2` (Python 3.9+) ([[tricks]]). Note : contrairement aux `set`, les dictionnaires n'implémentent pas `union`. <!--ID: 1728024344627--> ENDI
- STARTI [Basic] Dans quelle version de python a été introduit `d1 | d2` ? Back: `3.9` <!--ID: 1730827064244--> ENDI
- STARTI [Basic] `{'a': 1, 'b': 2} | {'b': 4, 'c': 3}` Back: `{'a': 1, 'b': 4, 'c': 3}` <!--ID: 1728024344629--> ENDI
- STARTI [Basic] `dict.fromkeys('ball', 2)` ? Back:  `{'b': 2, 'a': 2, 'l': 2}` <!--ID: 1728024344631--> ENDI
- STARTI [Basic] `dict.fromkeys('ball')` ? Back:  `{'b': None, 'a': None, 'l': None}` <!--ID: 1728024344634--> ENDI
- STARTI [Basic] Comment créer le dictionnaire `{'a': 0, 'b': 0, 'c': 0}` ? Back:  `dict.fromkeys('abc', 0)`, `{k: 0 for k in 'abc'}` <!--ID: 1728024344636--> ENDI


opérations sur les dictionnaires
- STARTI [Basic] dict : sur quoi se fait l'itération sur les dictionnaires ? Back:  sur les clés (et pas sur les valeurs, ni les items) <!--ID: 1728627767756--> ENDI
- STARTI [Basic] Dict: que teste `x in d` ? Back:  la présence de `x` dans les clés de `d` <!--ID: 1728627767760--> ENDI
- STARTI [Basic] `d = {'a': 0}; d['b']` ? Back:  `KeyError: 'b'` <!--ID: 1728627767764--> ENDI
- STARTI [Basic] `d = {'a': 0}; d['a']` ? Back:  `0` <!--ID: 1728627767768--> ENDI
- STARTI [Basic] `d = {}; d['a'] = 1; d` ? Back:   `{'a': 1}` - assigner à une clé qui n'est pas encore dans le dictionnaire est une valide <!--ID: 1728627767772--> ENDI
- STARTI [Basic] Comment supprimer un élément d'un dictionnaire `d` ? Back:  <br>1) `del d[key]` <br>2) `d.pop(key)` <br>RQ : il n'existe pas de méthode native pour supprimer par valeur. <!--ID: 1728627767777--> ENDI
- STARTI [Basic] `d = {'a': 0, 'b': 0}; del d['a']; d` ? Back:  `{'b': 0}` - l'instruction `del` supprime l'élément associé à la clé <!--ID: 1728627767781--> ENDI
- STARTI [Basic] `d = {'a': 0}; del d['b']; d` ? Back:  `KeyError: 'b'`  <!--ID: 1728627767785--> ENDI

opérations non mutatives
- STARTI [Basic] Quelles sont les 5 méthodes non mutatives de `dict` ? Back:  `copy`, `get`, `items`, `keys`, `values` <!--ID: 1728627767789--> ENDI
- STARTI [Basic] Comment obtenir une copie superficielle d'un dictionnaire ? Back:  `d.copy()` ou `dict(d)` <!--ID: 1728627767793--> ENDI
- STARTI [Basic] dict : comment accéder à la valeur associée à la clé `k` ou récupérer `0` si la clé n'existe pas ? Back:  <br>`d.get(k, 0)`. <br>`d.get(k)` renvoie `None` si `d[k]` n'existe pas. <!--ID: 1728627767797--> ENDI
- STARTI [Basic] dict : `d = {'a': 0}; d.get('b')` ? Back:  `None` <!--ID: 1728627767800--> ENDI
- STARTI [Basic] dict : `d = {'a': 0}; d.get('b', 0)` ? Back:  `0` <!--ID: 1728627767804--> ENDI
- STARTI [Basic] dict : comment itérer sur les couples (clé, valeur) de `d` ? Back:  `for k, v in d.items():` <!--ID: 1728627767808--> ENDI
- STARTI [Basic] dict : `d = {'a': 0, 'b': 5}; list(d.items())` ? Back:  `[('a', 0), ('b', 5)]` - les éléments dans l'ordre d'insertion <!--ID: 1728627767812--> ENDI
- STARTI [Basic] dict : comment itérer sur les clés de `d` ? Back:  <br>`for k in d:` <br>`for k in d.keys():` <!--ID: 1728627767815--> ENDI
- STARTI [Basic] dict : `d = {'a': 0, 'b': 5}; list(d.keys())` ? Back:  `['a', 'b']` - les clés dans l'ordre d'insertion <!--ID: 1728627767820--> ENDI
- STARTI [Basic] dict : comment itérer sur les valeurs de `d` ? Back:  `for v in d.values():` <!--ID: 1728627767823--> ENDI
- STARTI [Basic] dict : `d = {'a': 0, 'b': 5}; list(d.values())` ? Back:  `[0, 5]` - les valeurs dans l'ordre d'insertion <!--ID: 1728627767828--> ENDI

opérations mutatives
- STARTI [Basic] Quelles sont les 5 méthodes mutatives de `dict` ? Back:  `clear`, `pop`, `popitem`, `setdefault`, `update` <!--ID: 1728627767831--> ENDI
- STARTI [Basic] Comment vider le dictionnaire `d` ? Back:  `d.clear()` <!--ID: 1728627767835--> ENDI
- STARTI [Basic] dict : comment supprimer un élément par clé et récupérer sa valeur ? Back:  `d.pop(k)` <!--ID: 1728627767839--> ENDI
- STARTI [Basic] dict : `d = {'a': 0}; x = d.pop('b'); d, x` ? Back:  `KeyError` <!--ID: 1728627767843--> ENDI
- STARTI [Basic] dict : `d = {'a': 0}; x = d.pop('b', 0); d, x` ? Back:  `({'a': 0}, 0)` <!--ID: 1728627767848--> ENDI
- STARTI [Basic] dict : `d = {'a': 0}; x = d.pop('a', 1); d, x` ? Back:  `({}, 0)` (`1` précise une valeur par défaut dans le cas où `a` n'existerait pas, pas un filtre sur les valeurs). <!--ID: 1728627767851--> ENDI
- STARTI [Basic] dict : `d = {'a': 0}; x = d.pop('a'); d, x` ? Back:  `({}, 0)` <!--ID: 1728627767856--> ENDI
- STARTI [Basic] dict : comment supprimer le dernier élément inséré ? Back:  `d.popitem()` <!--ID: 1728627767860--> ENDI
- STARTI [Basic] dict : `d = {'a': 0, 'b': 5}; x = d.popitem(); d, x` ? Back:  `({'a': 0}, ('b', 5))` <!--ID: 1728627767865--> ENDI
- STARTI [Basic] dict : `d = {}; x = d.popitem(); d, x` ? Back:  `KeyError: 'popitem(): dictionary is empty'` <!--ID: 1728627767869--> ENDI
- STARTI [Basic] dict : comment s'assurer que l'élément a été initialisé avant de le récupérer ? Back:  `d.setdefault(k, x)` ou `d.setdefault(k)` pour initialiser à `None`. <!--ID: 1728627767873--> ENDI
- STARTI [Basic] dict : quelle structure est aujourd'hui préférée à l'utilisation de `d.setdefault(k, x)` ? Back: `defaultdict` <!--ID: 1728627767877--> ENDI
- STARTI [Basic] dict : `d = {}; x = d.setdefault('a', 0); d, x` ? Back:  `({'a': 0}, 0)` <!--ID: 1728627767881--> ENDI
- STARTI [Basic] dict : `d = {'a': 1}; x = d.setdefault('a', 0); d, x` ? Back:  `({'a': 1}, 1)` <!--ID: 1728627767885--> ENDI
- STARTI [Basic] dict : comment ajouter les éléments de `d2` à `d1` ? Back:  `d1.update(d2)` ou `d1 |= d2` avec l'assignation augmentée <!--ID: 1728627767889--> ENDI
- STARTI [Basic] dict : `d1 = {'a': 1, 'b': 2}; d2 = {'b': 3, 'c': 4}; d1.update(d2); d1` ? Back:  `{'a': 1, 'b': 3, 'c': 4}` <!--ID: 1728627767893--> ENDI
- STARTI [Basic] dict : `d = {'a': 0}; d |= ((1, 2), (3, 4)); d` ? Back:  `{'a': 0, 1: 2, 3: 4}` <!--ID: 1728627767897--> ENDI
- STARTI [Basic] dict : `d = {'a': 0}; d.update(1=2, 3=4); d` ? Back:  `{'a': 0, 1: 2, 3: 4}` - un dictionnaire qui associe `'a'` à `0`, `1` à `2` et `3` à `4`. <!--ID: 1728627767901--> ENDI
- STARTI [Basic] dict : `d = {'a': 0}; d.update(b=2, c=4); d` ? Back:  `{'a': 0, 'b': 2, 'c': 4}` - un dictionnaire qui associe `'a'` à `0`, `'b'` à `2` et `'c'` à `4`. <!--ID: 1728627767905--> ENDI
- STARTI [Basic] dict : comment itérer sur un `d` lorsque l'on souhaite en même temps modifier ses clés ? Back:  `for k in list(d):` crée une copier des clés de `d` au début de la boucle et évite de passer par un *view object*. Alors ajouter ou supprimer des éléments à `d` en cours d'itération ne pose pas de problème.  <!--ID: 1728627767909--> ENDI

START
Basic  
```python
d = {'a': 1}  
i = d.items()  
d["z"] = 26
```
Que vaut `list(i)` ?
Back:  
`[('a', 1), ('z', 26)]`. Les méthodes `items`, `key` et `values` renvoient des *view objects*. Ces objets reflètent les changements qui sont opérés sur l'objet cible. 
END

START
Basic  
```python
d = {'a': 1}
for v in d.values():
	if v == 1:
		d["z"] = 26
print(d)
```
Qu'affiche le code ci-dessus ?
Back:  
`RuntimeError: dictionary changed size during iteration`. Python n'autorise pas la modification de l'ensemble des clés d'un dictionnaire pendant que l'on itère sur un de ses *view object*.
END

START
Basic  
```python
d = {'a': 1, 'b': 2}
for v in d.values():
	if v == 2:
		d["a"] = 100
print(d)
```
Qu'affiche le code ci-dessus ?
Back:  
`{'a': 100, 'b': 2}`. Il n'est pas possible d'ajouter ou de supprimer des clés pendant que tu boucles sur un *view object* de dictionnaire mais il est possible de modifier les valeurs associées aux clés.
END
