MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/pickle.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[serialization]]
Date : 2025-01-11
***

- sérialisation d'objets spécifiques à python : instance, [[fonction]], [[classe]]
- https://pypi.org/project/dill/ étend les fonctionnalités de pickle
