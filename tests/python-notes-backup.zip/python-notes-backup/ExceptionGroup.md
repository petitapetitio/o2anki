MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***


***
TARGET DECK: Python
FILE TAGS: exceptions


- STARTI [Basic] Quel est le cas d'usage principal des ExceptionGroup ? Back:  Lever plusieurs exceptions à la fois, typiquement lors de la validation de données d'entrée.  <!--ID: 1730972172967--> ENDI
- STARTI [Basic] Dans quelle version de Python les ExceptionGroup ont-ils été introduits ? Back:  3.11 <!--ID: 1730972172970--> ENDI
- STARTI [Basic] Quelle est la particularité du traitement des `except*` comparé aux `except` classiques ? Back: Python continue d'évaluer les autres clauses `except*` après un match <!--ID: 1730972172975--> ENDI
- STARTI [Basic] Quelle clause pour gérer les exceptions de type `E1` d'un groupe d'exceptions ? Back:  `except* E1:` <!--ID: 1730972172978--> ENDI

START
Basic
Peut-on mélanger `except` et `except*` dans une même instruction `try` ?
Back:
Non. 
Si besoin, la solution est d'imbriquer deux [[instruction try]] : 
```python
try:
    try:
        ...
    except* ExceptionGroup:
        ...
except ValueError:
    ...
```
<!--ID: 1730972172973-->
END


START
Basic
Que vaut `e` ?
```python
try:
    raise ExceptionGroup(
        "Entrée invalide", 
        [E1("e1"), E1("e2"), E2()],
    )
except* E1 as e:
    print("E1 from group", e)
```
Back:
Un `ExceptionGroup` constitué des erreurs de type `E1` ("e1" et "e2").
<!--ID: 1730972172965-->
END
