MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-12
***

***
TARGET DECK: Python
FILE TAGS: loop

- STARTI [Basic] Quelles sont les deux instructions de boucle ? Back:  `while` et `for` <!--ID: 1728749077244--> ENDI

