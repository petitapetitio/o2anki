MOC : [[SOFTWARE ENGINEERING]]
Source : https://docs.python.org/3/library/csv.html
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[serialization]], [[CSV]]
Date : 2025-01-11
***

```python

csv.list_dialects()  # ['excel', 'excel-tab', 'unix']
csv.get_dialect('excel').delimiter  # ','


with open('eggs.csv') as f:
    for r in csv.reader(f, delimiter=','):
        print(r)

# ['nom', 'email']
# ['derek', 'd@siv.rs']
# ['alex', 'a@pet.it']


with open('eggs.csv') as f:
    for r in csv.DictReader(f):
        print(r)

# {'nom': 'derek', 'email': 'd@siv.rs'}
# {'nom': 'alex', 'email': 'a@pet.it'}


for r in csv.reader(["a, b", "c, d"]):
    print(r)

# ['a', ' b']
# ['c', ' d']
```

`eggs.csv` : 
```csv
nom,email  
derek,d@siv.rs  
alex,a@pet.it
```
