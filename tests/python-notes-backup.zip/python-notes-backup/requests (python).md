MOC : [[SOFTWARE ENGINEERING]]
Source : https://requests.readthedocs.io/en/latest/
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-18
***

- claim to be : an elegant and simple HTTP library for Python, built for human beings.
- construit sur [[urllib3]] - et d'après [cet article](https://medium.com/@technige/what-does-requests-offer-over-urllib3-in-2022-e6a38d9273d9), n'apporte plus grand chose à [[urllib3]]