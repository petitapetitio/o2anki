MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-25
***

***
TARGET DECK: Python
FILE TAGS: fonctions

- STARTI [Basic] Qu'est-ce qu'une fonction imbriquée (nested, enclosed) ? Back:  Une fonction définie dans une autre fonction <!--ID: 1730827064242--> ENDI


START
Basic
Comment appelle-t-on la fonction `inner` 
```python
def outer():
    def inner():
        pass
    ...
```
?
Back: 
Fonction interne (englobée, imbriquée)
<!--ID: 1730827064237-->
END


START
Basic
Comment appelle-t-on la fonction `outer` 
```python
def outer():
    def inner():
        pass
    ...
```
?
Back: 
Fonction externe (englobante)
<!--ID: 1730827064239-->
END


START
Basic
Quelle est la différence d'exécution entre 
```python
def percent1(a, b, c):  
    def pc(x, total=a+b+c):
        return (x*100.0) / total 
    print(pc(a), pc(b), pc(c))
```
et
```python
def percent2(a, b, c):  
    def pc(x):
        return (x*100.0) / (a+b+c)
    print(pc(a), pc(b), pc(c))
```
?
Back:
`a+b+c` n'est exécuté qu'une fois dans `percent1` (au moment de la définition de la fonction) vs 3 fois dans `percent2`
<!--ID: 1730827064240-->
END