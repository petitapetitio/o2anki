MOC : [[SOFTWARE ENGINEERING]]
Source : 
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[COMPUTER NETWORKS]]
Date : 2025-01-18
***

- top CA authorities : IdenTrust, DigiCert, Sectigo (est un point faible car corruptible)
- format des keystores and trust stores : [.pem](https://en.wikipedia.org/wiki/Privacy-Enhanced_Mail), .crt, [.pfx](https://en.wikipedia.org/wiki/PKCS_12 "PKCS 12"), and [.jks](https://en.wikipedia.org/wiki/Java_KeyStore "Java KeyStore").
