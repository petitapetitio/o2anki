MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3.13/library/abc.html#abc.ABCMeta.register
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-01
***

- Que doit hériter `SuperClass` pour fournir la méthode `register` ? Non. Les ABC
- Qu'implique l'enregistrement d'une classe `C` comme sous-classe virtuelle via `SuperClass.register(C)` ? `issubclass(C, SuperClass)` renvoie `True` mais `C` n'hérite pas des méthodes de `SuperClass` et `SuperClass` n'apparaît pas dans `C.__mro__`
- `SuperClass.register(C); issubclass(C, SuperClass)` ? Yes
- `SuperClass.register(C); isinstance(C(), SuperClass)` ? Yes
- Dans quel cas utiliser `C.register(X)` plutôt qu'un héritage classique ? Dans deux cas principaux. <br>1) Quand on ne peut pas modifier la classe X (bibliothèque tierce) <br>2) Quand on veut déclarer qu'une classe respecte une interface sans hériter de l'implémentation
