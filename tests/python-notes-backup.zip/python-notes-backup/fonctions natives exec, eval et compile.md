MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-12
***

- https://docs.python.org/3/library/functions.html#exec
- https://docs.python.org/3/library/functions.html#eval
- https://docs.python.org/3/library/functions.html#compile
- `exec(code, globals=None, locals=None, /)`
- éviter d'utiliser `exec` de façon générale (sécurité, maintenabilité, lisibilité)
- security tip : 
	- passer à minima globals afin de ne pas exécuter `exec` dans l'espace de nom courant. Cela permet d'isoler l'exécution du code et limiter les risques.
	- avoid running untrusted code (et si vraiment, l'exécuter dans un environnement le + isolé possible, monitorer sa consommation)
- `eval` est comme `exec` mais capture la valeur de retour
- le code à exécuter / évalué peut être pré-compilé via `compile`. `compile`est sans risque et permet ensuite d'inspecter le code compilé 

```python

# exec ne récupère pas la valeur de retour. eval oui
print(exec("0 + 0"))  # None
print(eval("0 + 0"))  # 0

```
