MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2025-01-13
***

- https://docs.python.org/fr/3.13/library/secrets.html
- [[module random (Generate pseudo-random numbers)]] mais pour la sécurité
- nombres aléatoires
	- un entier aléatoire avec 32 bits ? `secrets.randbits(32)` (ex : `1329203053`)
	- un élément aléatoire d'une séquence `s` ? `secrets.choice(s)`
- jetons
	- pour la réinitialisation de mot de passe et la génération d'urls difficiles à deviner
	- un jeton adapté au format url ? `secrets.token_urlsafe()` (ex `'17OpIGTiuaU0ywFHulfJ6GMnTUHdpX8WcspkEk8_P2k'`)
- recettes
	- un mot de passe alphanumérique à 8 caractères ? `''.join(secrets.choice(string.ascii_letters + string.digits) for i in range(8))`
	- https://docs.python.org/fr/3.13/library/secrets.html#recipes-and-best-practices
