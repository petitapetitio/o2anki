MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-06
***

***
TARGET DECK: Python
FILE TAGS: typing

- STARTI [Basic] comment indiquer que la variable `a = 1` est de type int ? Back:  `a: int = 1` <!--ID: 1730827064768--> ENDI
- STARTI [Basic] comment indiquer que le paramètre de `f(a = 0)` est de type int ? Back:  `f(a: int = 0)` <!--ID: 1730827064770--> ENDI
- STARTI [Basic] comment indiquer que `f(a, b)` renvoie un entier ? Back:  `f(a, b) -> int` <!--ID: 1730827064772--> ENDI
- STARTI [Basic] comment typer "entier ou flottant" (2 façons) ? Back: <br>`Union[int, float]` <br>`int | float` à partir de `3.10` <!--ID: 1730827064773--> ENDI
- STARTI [Basic] à quoi correspond l'annotation `int | None` ? Back:  `Optional[int]` <!--ID: 1730827064776--> ENDI

START
Basic
Comment éviter une `NameError` lorsqu'on annote une méthode qui renvoie sa propre classe ?
Back: 
Utiliser des quotes pour l'annotation permet de faire une référence anticipée : 
```python
class A:
    @classmethod
    def factory_method(cls) -> 'A':
        ...
```
<!--ID: 1730827064744-->
END
