MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]] - https://pypi.org/project/setuptools/
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-11-14
***

***
TARGET DECK: Python
FILE TAGS: packaging

- STARTI [Basic] Qu'est-ce que `setuptools` ? Back: un module qui permet de packager des projets [[Python]] (en vue de les publier sur [[PyPI]]). <!--ID: 1731677487754--> ENDI
- STARTI [Basic] Quand est apparu `setuptools` ? Back: 2004-2005 <!--ID: 1731677487755--> ENDI
- STARTI [Basic] Pourquoi `setuptools` a-t-il été créé ? Back: Étendre les fonctionnalités de [[distutils]]. <!--ID: 1731677487756--> ENDI
- STARTI [Basic] Qui est l'auteur original de `setuptools` ? Back:  [[Phillip J. Eby]] <!--ID: 1731677487757--> ENDI
- STARTI [Basic] Qui pilote les développements de `setuptools` ? Back:  [[Python Packaging Authority (PyPA)]] <!--ID: 1731677487758--> ENDI
- STARTI [Basic] Pourquoi `setuptools` a-t-il remplacé `distutils` ? Back:  1) Développement plus rapide car indépendant des releases Python et 2) Meilleure maintenance <!--ID: 1731677487759--> ENDI
- STARTI [Basic] Quels sont les apports historiques notables de setuptools ? Back:  Le format [[python eggs]] et la commande `easy_install` (aujourd'hui dépréciés) <!--ID: 1731677487760--> ENDI

D'après [[Python in a Nutshell]]
- a longtemps été construit on top of [[distutils]]
- the preferred way to distribute new projects
- the primary mechanism for packaging and distribution for the past decade
- ==is migrating toward standards of PEP 517 and PEP 518==
- automatically installed as a part of any virtual environment created with the python -m venv path


Structure ==legacy== :
- source tree in the souce root
- un [[script setup.py]]
- un README
- un requirements.txt
- un MANIFEST.in
- un setup.cfg

[Contexte historique d'après Perplexity](https://www.perplexity.ai/search/quelles-etaient-les-grandes-li-pjlYp8r.TfuWThxr9QUF_Q#2) : 
```
Setuptools began gaining popularity in the mid-2000s, shortly after its initial creation. Here's a brief timeline of its rise to prominence:

## Initial Development

Setuptools was originally created by Phillip J. Eby around 2004-2005 as an enhancement to Python's distutils[4](https://pypi.org/project/setuptools/4.0/).

## Early Adoption

By 2006-2007, setuptools was already gaining traction in the Python community. It addressed many limitations of distutils and provided more advanced packaging features that developers needed.

## Widespread Use

By the late 2000s and early 2010s, setuptools had become a de facto standard for Python package management. Its popularity grew due to several factors:

1. It introduced the egg format, which was an improvement over simple source distributions.
2. It provided better dependency management capabilities.
3. It offered the easy_install tool, which simplified package installation.

## Integration with pip

The rise of pip (around 2008-2009) as the preferred installation tool further cemented setuptools' position. Pip used setuptools for many of its core functionalities, making setuptools an essential part of the Python packaging ecosystem.

## Modern Era

Despite the introduction of newer tools, setuptools has maintained its popularity. As of 2024, it remains the most widely used build backend for Python packages. According to a recent analysis, setuptools is used by about 50,000 packages on PyPI, making it the most popular build backend[2](https://chriswarrick.com/blog/2024/01/15/python-packaging-one-year-later/). 

In summary, setuptools started becoming popular shortly after its introduction in the mid-2000s, and its usage grew steadily throughout the late 2000s and 2010s. Its integration with other tools and continuous development have helped maintain its popularity to this day, despite the emergence of newer alternatives.
```
