MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/datamodel.html#object.__format__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: dunders strings

- STARTI [Basic] comment se traduit `format(x)` ? Back:  `x.__format__()` <!--ID: 1730827064421--> ENDI
- STARTI [Basic] quelle est la signature de `__format__` ? Back:  `__format__(self, format_string='')` <!--ID: 1730827064424--> ENDI
- STARTI [Basic] quel est le comportement par défaut de `__format__` ? Back: Délègue à `__str__` et seule une chaîne vide est acceptée comme `format_string`. <!--ID: 1730827064426--> ENDI


Matching des arguments : 
- STARTI [Basic] format : comment interpoler par nom `'My name is XXX'` ? Back:  `'My name is {name}'.format(name='Alex')` <!--ID: 1734713099778--> ENDI
- STARTI [Basic] format : comment interpoler par position `'My name is XXX YYY'` ? Back:  `'My name is {} {}'.format('Alexandre', 'Petit')` <!--ID: 1734713099779--> ENDI
- STARTI [Basic] format : comment utiliser un argument positionnel à plusieurs endroits dans `'When I say XXX, it's XXX, YYY'` ? Back:  `"When I say {0}, it's {0}, {1}".format("go", "dude")` <!--ID: 1734713099780--> ENDI
- STARTI [Basic] `'{[1]} {[0]}'.format(('zero', 'one'), ('two', 'three'))` ? Back:  `'one two'` <!--ID: 1734713099781--> ENDI
- STARTI [Basic] `'{1[1]} {0[0]}'.format(('zero', 'one'), ('two', 'three'))` ? Back:  `'three zero'` <!--ID: 1734713099782--> ENDI
- STARTI [Basic] `'{} {} {a[2]}'.format(1, 2, a=(3, 4, 5))` ? Back:  `1 2 5` <!--ID: 1734713099783--> ENDI
- STARTI [Basic] `"({0.x}, {0.y})".format(Point(10, 99))` ? Back:  `(10, 99)` <!--ID: 1734713099784--> ENDI
- STARTI [Basic] format : l'attribut `'attr'` du deuxième argument positionnel ? Back:  `'{1.attr}'` <!--ID: 1734713099785--> ENDI