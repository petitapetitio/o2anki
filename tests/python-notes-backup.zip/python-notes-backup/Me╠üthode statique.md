MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-28
***

***
TARGET DECK: Python
FILE TAGS: classes

STARTI [Basic] quelles sont les différences entre une méthode statique et une méthode ordinaire ? Back: Une méthode statique peut s'appeler directement sur la classe et ne reçoit pas `self` en premier paramètre (elle n'a pas accès aux données de l'instance). <!--ID: 1730827064388--> ENDI

START
Basic
Comment créer une méthode statique sans le décorateur @staticmethod ?
Back:
```python
class A:
    def f(): ...
    f = staticmethod(f)
```
<!--ID: 1730827064384-->
END


START
Basic
Comment créer une méthode statique avec le décorateur @staticmethod ?
Back:
```python
class A:
    @staticmethod
    def f(): ...
```
<!--ID: 1730827064386-->
END
