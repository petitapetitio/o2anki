MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/datamodel.html#object.__getattribute__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***


***
TARGET DECK: Python
FILE TAGS: classes dunders

- STARTI [Basic] quelle expression d'accès déclenche `x.__getattribute__('attr')` ? Back:  `x.attr` <!--ID: 1730827064401--> ENDI
- STARTI [Basic] que renvoie  `__getattribute__` ? Back:  La valeur de l'attribut ou une `AttributeError` si l'attribut n'existe pas. <!--ID: 1730827064403--> ENDI
- STARTI [Basic] quelle contrainte garder en tête lorsque tu surcharge `__getattribute__` ? Back:  Le code sera exécuté à chaque accès à un attribut, ce qui peut impacter les performances. <!--ID: 1730827064405--> ENDI


START
Basic
Est-ce que `A().cx` passe par `__getattribute__` 
```python
class A:
    cx = 1  
    def __getattribute__(self, item):  
        print(item)
```
?
Back:
Oui
`A().cx`  affiche `cx`
<!--ID: 1730827064391-->
END


START
Basic
Est-ce que `A.cx` passe par `__getattribute__` 
```python
class A:
    cx = 1  
    def __getattribute__(self, item):  
        print(item)
```
?
Back:
Non.
<!--ID: 1730827064394-->
END


START
Basic
Est-ce que `A().x` passe par `__getattribute__` 
```python
class A:
    def __init__(self):
        self.x = 1
        
    def __getattribute__(self, item):  
        print(item)
```
?
Back:
Oui
`A().x`  affiche `x`
<!--ID: 1730827064396-->
END


START
Basic
Est-ce que `A().f` passe par `__getattribute__` 
```python
class A:
    def f(self):
        ...
        
    def __getattribute__(self, item):  
        print(item)
```
?
Back:
Oui
`A().f()`  affiche `f`
<!--ID: 1730827064399-->
END
