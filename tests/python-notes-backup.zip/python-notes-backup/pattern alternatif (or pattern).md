MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-11
***


***
TARGET DECK: Python
FILE TAGS: match

- STARTI [Basic] Comment appelle-t-on un pattern `p1 | p2` composé des patterns `p1` et `p2` ? Back:  un "OR pattern" (aka pattern alternatif) <!--ID: 1728727115358--> ENDI
- STARTI [Basic] Comment matcher un sujet qui vaut 0 ou 1 ? Back:  `case 0 | 1:` <!--ID: 1728727115360--> ENDI
