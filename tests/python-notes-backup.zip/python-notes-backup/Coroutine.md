Date : 2024-01-15
***

- Généralisation des subroutines
- Une fonction coroutine est définie avec `async def`  
- Pour exécuter une coroutine : 
	- appeler une fonction coroutine renvoie une coroutine (sans planifier son exécution) 
	- pour planifier l'exécution
		- utiliser `asyncio.run` (au niveau du programme principal)
		- utiliser `await coroutine` 
```python
import asyncio
import time

async def say_after(delay, what):
    await asyncio.sleep(delay)
    print(what)
    
async def main():
    print(f"started at {time.strftime('%X')}")

    await say_after(1, 'hello')
    await say_after(2, 'world')

    print(f"finished at {time.strftime('%X')}")

asyncio.run(main())

# Sortie attendue
# started at 17:13:52
# hello
# world
# finished at 17:13:55

main()
# <coroutine object main at 0x000001B85AEF0540>
```