MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/3/reference/datamodel.html#object.__bool__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]]
Date : 2024-10-29
***

***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] quand est appelé `__bool__` ? Back:  Dans les *contextes booléens* et dans `bool(x)` <!--ID: 1730827064495--> ENDI
- STARTI [Basic] comment procède la fonction native `bool(x)` ? Back: Python utilise `x.__bool__()` si disponible, sinon teste `len(x) > 0`, sinon renvoie `True` (car `x is not None`). <!--ID: 1730827064498--> ENDI
