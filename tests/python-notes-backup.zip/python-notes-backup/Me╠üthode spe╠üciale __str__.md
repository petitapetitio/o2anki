MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]], https://docs.python.org/fr/3/reference/datamodel.html#object.__str__
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[str (chaîne de caractères)]]
Date : 2024-10-05
***

***
TARGET DECK: Python
FILE TAGS: dunders

- STARTI [Basic] comment se traduit `str(x)` ? Back:  `x.__str__()` <!--ID: 1730827064443--> ENDI
- STARTI [Basic] quelle est le comportement par défaut de `__str__` ? Back: délègue à `__repr__` ([[Méthode spéciale __repr__]])  <!--ID: 1730827064444--> ENDI
- STARTI [Basic] quelle est la sortie attendu de  `__str__` ? Back:  Une chaîne de caractère pratique à lire pour l'homme (human-readable) (make it as human readable as possible) <!--ID: 1730827064446--> ENDI

