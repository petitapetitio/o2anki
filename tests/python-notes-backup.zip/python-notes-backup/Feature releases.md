MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : 
Date : 2024-09-28
***



***
TARGET DECK: Python

STARTI [Basic] Quel est la feature release qui vient après 3.10 ? Back: 3.11 <!--ID: 1727542890129--> ENDI
STARTI [Basic] Quel est l'autre nom des feature releases Back: Minor releases <!--ID: 1727542890131--> ENDI
STARTI [Basic] À quelle fréquence sont publiées les sorties mineures ? Back: 1 fois par an en octobre (depuis 3.8) <!--ID: 1727542890135--> ENDI
STARTI [Basic] Quelle est la rétro-compatibilité des feature-releases ? Back: 3.x avec 3.0 <!--ID: 1727542890137--> ENDI