MOC : [[SOFTWARE ENGINEERING]]
Source : [[Python in a Nutshell]]
Projet : [[$P - Mémoriser Python (Mastering Python)]]
Tags : [[Python]], [[module os]]
Date : 2025-01-14
***


- `os.path.abspath('../data/chr.zip')` ? `'/users/lxnd/dev/python-demo/data/chr.zip'`
- `os.path.abspath(os.path.expanduser('~/dev'))` ? `'/Users/lxnd/dev'`
- `os.path.abspath('~/dev')` ? `'/Users/lxnd/dev/python-demo/~/dev'` ([[gotcha]]) 
- `os.path.basename('../data/chr.zip')` ? `'chr.zip'`
- `os.path.dirname('../data/chr.zip')` ? `'../data'`
- `os.path.expandvars('$HOME/dev')` ? `'/Users/lxnd/dev'`
- `os.path.normpath('a/c/../b')` ? `'a/b'`
- `os.path.split('tests/unit/a.py')`  ? `('tests/unit', 'a.py')`
- `os.path.splitext('data/archive.tar.gz')` ? `('data/archive.tar', '.gz')`


- le chemin absolu de `'../data/chr.zip'` ? `os.path.abspath('../data/chr.zip')` ![[2024-09-28 Python in a nutshell-12.png]]
- le fichier dans `'../data/chr.zip'` ? `os.path.basename('../data/chr.zip')` ![[2024-09-28 Python in a nutshell-13.png]]
- le dossier dans `'../data/chr.zip'` ? `os.path.dirname('../data/chr.zip')` ![[2024-09-28 Python in a nutshell-14.png]]
- le chemin absolu de `'~/dev/python-demo')` ? `os.path.abspath(os.path.expanduser('~/dev/python-demo'))` ![[2024-09-28 Python in a nutshell-15.png]] (`abspath` ne suffit pas) ![[2024-09-28 Python in a nutshell-16.png]]
- interpréter `'$HOME/dev'` ? `os.path.expandvars('$HOME/dev')`  ![[2024-09-28 Python in a nutshell-17.png]]
- le chemin `'a/c/../b'` mais normalisé ? `os.path.normpath('a/c/../b')` (`'a/b'`)
- `dir, base` à partir de `'tests/unit/a.py'`  ? `os.path.split('tests/unit/a.py')`  (`('tests/unit', 'a.py')`)
- `root, ext` à partir de `'data/archive.tar.gz'` ? `os.path.splitext('data/archive.tar.gz')` (`('data/archive.tar', '.gz')`)
